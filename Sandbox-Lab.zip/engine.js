(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('matter-js'), require('./items.js'));
  else root.Sandbox = factory(root.Matter, root.Items);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (M, Items) {
  'use strict';
  const { Engine, Bodies, Body, Composite, Constraint, Events, Query, Vector } = M;
  // Items and materials are data (items.js). defs is the item row by id, with its material's properties folded in as .mat; CATALOG is what the library shows.
  const {MATERIALS,ITEMS,CATEGORIES}=Items,defs=Object.fromEntries(ITEMS.map(item=>[item.id,{...item,mat:MATERIALS[item.material]||MATERIALS.flesh}])),CATALOG=ITEMS;
  const matOf=p=>MATERIALS[p.material]||MATERIALS.metal;
  // Every random choice in the simulation goes through here, so a test (or a replay) can seed it: sim.seed(n). Unseeded, it is Math.random.
  let random=Math.random;
  const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
  const rnd=(a,b)=>a+random()*(b-a);
  // Dimensions are shared by the physics bodies and the renderer, in world pixels.
  const ANATOMY=[
    ['head',0,-105,23,30],['neck',0,-84,11,14],['chest',0,-60,35,36],['abdomen',0,-32,26,23],['pelvis',0,-11,30,23],
    ['upper arm',-24,-56,12,35],['forearm',-25,-23,10,31],['hand',-25,-1,10,15],
    ['upper arm',24,-56,12,35],['forearm',25,-23,10,31],['hand',25,-1,10,15],
    ['thigh',-10,22,16,45],['shin',-10,64,12,41],['foot',-10,88,22,12],
    ['thigh',10,22,16,45],['shin',10,64,12,41],['foot',10,88,22,12]
  ];
  const wrap=a=>Math.atan2(Math.sin(a),Math.cos(a));
  // Every tunable lives in this one table: the engine reads the values, the settings page is generated from it, and saved values are validated against it.
  // Names and ranges follow People Playground's Environment, Gore and General menus where it has the option; the rest are this sandbox's own.
  const SETTINGS=[
    {id:'gravity',section:'World',label:'Gravity',help:'Strength of gravity. Negative values make everything fall upward.',type:'range',min:-40,max:40,step:.01,def:9.81,unit:' m/s²'},
    {id:'ambient',section:'World',label:'Ambient temperature',help:'Everything drifts toward this temperature. Above 170° wood and flesh catch fire; below zero flesh turns brittle.',type:'range',min:-100,max:1000,step:1,def:20,unit:'°'},
    {id:'lightning',section:'World',label:'Lightning chance',help:'How often the sky strikes. A bolt shocks, burns and ignites what it hits, and jumps through conductors.',type:'range',min:0,max:100,step:1,def:0,unit:'%'},
    {id:'rain',section:'World',label:'Rain',help:'Rain puts out fires and cools hot objects.',type:'toggle',def:false},
    {id:'snow',section:'World',label:'Snow',help:'Snow makes the floor slippery.',type:'toggle',def:false},
    {id:'fog',section:'World',label:'Fog',help:'A low mist over the chamber.',type:'toggle',def:false},
    {id:'floodlights',section:'World',label:'Floodlights',help:'Ceiling lights. Switched off, the chamber goes dark and fire, explosions and lightning become the light.',type:'toggle',def:true},
    {id:'autoBalance',section:'Ragdolls',label:'Auto-balance',help:'Living ragdolls stand, keep their balance and get back up. Off, they are limp.',type:'toggle',def:true},
    {id:'legStrength',section:'Ragdolls',label:'Leg strength',help:'How hard the legs can push, in multiples of body weight.',type:'range',min:.5,max:4,step:.1,def:2,unit:'×'},
    {id:'getUpTime',section:'Ragdolls',label:'Get-up time',help:'Seconds for strength to return after a knockdown. Lower is snappier.',type:'range',min:.3,max:5,step:.1,def:1.2,unit:' s'},
    {id:'stunScale',section:'Ragdolls',label:'Knockdown length',help:'Multiplier on how long a hard hit leaves a ragdoll stunned. Zero means hits never knock anyone down.',type:'range',min:0,max:4,step:.1,def:1,unit:'×'},
    {id:'painReactions',section:'Ragdolls',label:'Pain reactions',help:'Flinching, clutching wounds, guarding, limping, hunching, trembling, writhing, panic when burning. Off, a hurt ragdoll just stands or falls.',type:'toggle',def:true},
    {id:'reactionIntensity',section:'Ragdolls',label:'Reaction intensity',help:'How big the movements of a reaction are.',type:'range',min:.25,max:2,step:.05,def:1,unit:'×'},
    {id:'painSensitivity',section:'Ragdolls',label:'Pain sensitivity',help:'How much pain a given injury causes.',type:'range',min:0,max:3,step:.1,def:1,unit:'×'},
    {id:'breathing',section:'Ragdolls',label:'Breathing',help:'Living humans breathe: faster and deeper in pain, shallow near death.',type:'toggle',def:true},
    {id:'awareness',section:'Ragdolls',label:'Awareness',help:'Conscious humans look at what threatens them, throw their arms up at something coming at their head, pull away from heat, and start when someone nearby is hurt.',type:'toggle',def:true},
    {id:'faces',section:'Ragdolls',label:'Faces',help:'Eyes and mouth follow pain, consciousness and where the ragdoll is looking. Off, every face is neutral.',type:'toggle',def:true},
    {id:'grunts',section:'Ragdolls',label:'Grunts',help:'A soft synthesized grunt when a conscious human is hit. Needs sound on.',type:'toggle',def:false},
    {id:'brainDamage',section:'Ragdolls',label:'Brain damage',help:'A damaged head causes blackouts: the ragdoll collapses now and then.',type:'toggle',def:false},
    {id:'slowHealing',section:'Ragdolls',label:'Slow injury healing',help:'Wounds of the living slowly close, bones knit and blood is replaced.',type:'toggle',def:false},
    {id:'fragility',section:'Gore',label:'Fragility multiplier',help:'Multiplies all damage to ragdolls. Higher is more fragile.',type:'range',min:.1,max:10,step:.1,def:1,unit:'×'},
    {id:'jointStrength',section:'Gore',label:'Joint strength',help:'How much force or damage it takes to tear a limb off.',type:'range',min:.25,max:5,step:.05,def:1,unit:'×'},
    {id:'bleedRate',section:'Gore',label:'Bleeding rate',help:'How fast wounds drain blood. Zero means nobody bleeds out.',type:'range',min:0,max:5,step:.1,def:1,unit:'×'},
    {id:'limbCrush',section:'Gore',label:'Limb crushing',help:'A destroyed limb that takes another heavy blow is crushed out of existence.',type:'toggle',def:false},
    {id:'crushSensitivity',section:'Gore',label:'Limb crush sensitivity',help:'How little force it takes to crush a destroyed limb.',type:'range',min:25,max:400,step:5,def:100,unit:'%'},
    {id:'fragments',section:'Gore',label:'Procedural fragments',help:'Crushed limbs leave physical fragments behind.',type:'toggle',def:true},
    {id:'gibCount',section:'Gore',label:'Gib count',help:'Flesh chunks thrown by a crushed or blasted limb, plus half as many bone fragments. Needs procedural fragments on.',type:'range',min:0,max:8,step:1,def:3,unit:''},
    {id:'extraGunshot',section:'Gore',label:'Extra gunshot particles',help:'Bullet hits throw out more debris.',type:'toggle',def:false},
    {id:'bloodAmount',section:'Gore',label:'Blood amount',help:'How much blood sprays and drips. Visual only; bleeding rate decides how fast anyone bleeds out.',type:'range',min:0,max:3,step:.1,def:1,unit:'×'},
    {id:'arterialSpurts',section:'Gore',label:'Arterial spurts',help:'Deep wounds to the neck, upper arms, thighs and heart pump blood out in time with the pulse, and drain far faster.',type:'toggle',def:true},
    {id:'maxStains',section:'Gore',label:'Maximum stains',help:'Oldest stains and pools are removed beyond this many.',type:'range',min:50,max:600,step:10,def:300,unit:''},
    {id:'stainLifetime',section:'Gore',label:'Stain lifetime',help:'Seconds before a dried stain fades away. Zero keeps them until the limit is reached.',type:'range',min:0,max:600,step:10,def:180,unit:' s'},
    {id:'organDamage',section:'Gore',label:'Organ damage',help:'Deep wounds can find the brain, heart, lungs or gut: instant death, blackouts, internal bleeding, suffocation.',type:'toggle',def:true},
    {id:'noGore',section:'Gore',label:'No gore',help:'Hides blood, stains and wounds. Injuries still happen, they are just not drawn.',type:'toggle',def:false},
    {id:'bulletDamage',section:'Weapons',label:'Bullet damage',help:'Damage of one bullet, from the shoot tool or a pistol.',type:'range',min:5,max:300,step:5,def:55,unit:''},
    {id:'bulletForce',section:'Weapons',label:'Bullet knockback',help:'How hard a bullet shoves what it hits.',type:'range',min:0,max:6,step:.1,def:1,unit:'×'},
    {id:'explosionPower',section:'Weapons',label:'Explosion power',help:'Multiplies the blast force and damage of every explosion.',type:'range',min:.25,max:4,step:.05,def:1,unit:'×'},
    {id:'pierceSpeed',section:'Weapons',label:'Piercing speed',help:'How fast a blade must travel point-first to run a body through. Lower pierces more easily.',type:'range',min:1,max:20,step:.5,def:5,unit:''},
    {id:'bladeGrip',section:'Weapons',label:'Blade grip',help:'How firmly flesh holds a lodged blade. Low values let it slide out with a light pull, or under the body\'s own weight.',type:'range',min:1,max:30,step:1,def:5,unit:''},
    {id:'iterations',section:'Physics',label:'Physics iterations',help:'Solver passes per step. Higher is more accurate and slower.',type:'range',min:4,max:64,step:1,def:10,unit:''},
    {id:'airDrag',section:'Physics',label:'Air resistance',help:'Multiplier on air drag. Zero is a vacuum.',type:'range',min:0,max:5,step:.1,def:1,unit:'×'},
    {id:'grabStrength',section:'Physics',label:'Grab strength',help:'How firmly the cursor holds what it drags. Higher also throws harder.',type:'range',min:.04,max:.6,step:.01,def:.16,unit:''},
    {id:'maxObjects',section:'Physics',label:'Object limit',help:'Spawning stops at this many bodies. A ragdoll is 17.',type:'range',min:100,max:1000,step:50,def:500,unit:''},
    {id:'slowMotion',section:'Physics',label:'Slow-motion speed',help:'How fast time runs while slow motion (G) is on.',type:'range',min:5,max:90,step:5,def:20,unit:'%'},
    {id:'decals',section:'Visuals',label:'Decals',help:'Blood stains and scorch marks on the floor.',type:'toggle',def:true},
    {id:'tracers',section:'Visuals',label:'Bullet tracers',help:'Draws the path of each shot.',type:'toggle',def:true},
    {id:'particles',section:'Visuals',label:'Particle effects',help:'Sparks, smoke, fire and spray.',type:'select',options:['Off','Low','High'],def:'High'},
    {id:'shake',section:'Visuals',label:'Screen shake intensity',help:'Camera shake from explosions and thunder.',type:'range',min:0,max:3,step:.1,def:1,unit:'×'},
    {id:'grid',section:'Visuals',label:'Background grid',help:'The measurement grid on the chamber wall.',type:'toggle',def:true},
    {id:'shadows',section:'Visuals',label:'Contact shadows',help:'Soft shadows where objects are near the floor.',type:'toggle',def:true},
    {id:'vignette',section:'Visuals',label:'Vignette',help:'Darkened screen edges.',type:'toggle',def:true},
    {id:'tempUnit',section:'Interface',label:'Temperature unit',help:'Unit used in the detail view.',type:'select',options:['Celsius','Fahrenheit','Kelvin'],def:'Celsius'},
    {id:'showFps',section:'Interface',label:'Show framerate',help:'Frames per second, top right of the chamber.',type:'toggle',def:true},
    {id:'hints',section:'Interface',label:'Tool hints',help:'The caption describing the active tool.',type:'toggle',def:true},
    {id:'zoomSensitivity',section:'Interface',label:'Zoom scroll sensitivity',help:'How fast the scroll wheel zooms.',type:'range',min:.25,max:3,step:.05,def:1,unit:'×'},
    {id:'panSpeed',section:'Interface',label:'Camera pan speed',help:'How fast the arrow keys move the camera.',type:'range',min:.25,max:3,step:.05,def:1,unit:'×'},
    {id:'sound',section:'Audio',label:'Sound',help:'Synthesized impacts, shots, explosions and thunder.',type:'toggle',def:false},
    {id:'volume',section:'Audio',label:'Volume',help:'Master volume.',type:'range',min:0,max:100,step:5,def:60,unit:'%'}
  ];
  // Damage profiles: one row per damage type. hp is always the full amount; the rest say what kind of injury it is.
  //   bone: bone damage per point · bleed: bleeding added per point · pain per point · stun multiplier · deep: reaches organs · wound: what it leaves (null = nothing)
  // Knockback is not here on purpose: bullets, blades, falls and blasts already push through the physics.
  const PROFILES={
    impact:{bone:1,  bleed:1/150,pain:.55,stun:1,  deep:false,wound:'bruise'},  // blunt: breaks bones, barely bleeds
    cut:   {bone:.3, bleed:1/60, pain:.7, stun:.6, deep:false,wound:'cut'},     // long and shallow
    stab:  {bone:.55,bleed:1/45, pain:.9, stun:.8, deep:true, wound:'stab'},    // deep and narrow
    bullet:{bone:.55,bleed:1/45, pain:.8, stun:1,  deep:true, wound:'bullet'},
    exit:  {bone:.2, bleed:1/30, pain:.5, stun:0,  deep:false,wound:'exit'},    // the far side of a through-shot: bigger, wetter
    blast: {bone:1,  bleed:1/70, pain:1,  stun:1.3,deep:true, wound:'blast'},
    burn:  {bone:.1, bleed:0,    pain:1.2,stun:.5, deep:false,wound:'burn'},    // cauterises: see damage()
    shock: {bone:0,  bleed:0,    pain:.22,stun:0,  deep:false,wound:null}       // current cooks; it does not cut
  };
  const PAIN_PART={head:1.4,pelvis:1.4,neck:1.2,hand:1.1,foot:1.1}; // where it hurts more than elsewhere
  // Organs by body part: [organ, region in the part's own frame as x0,y0,x1,y1 fractions of its half-size, damage multiplier].
  const ORGANS={head:[['brain',-1,-1,1,.35,1.5]],chest:[['heart',-.55,-.6,.2,.25,2],['lungs',-1,-1,1,.45,1]],abdomen:[['gut',-1,-1,1,1,.8]],pelvis:[['gut',-1,-1,1,.2,.6]]};
  const ARTERIAL=new Set(['neck','upper arm','thigh']),ARTERY_RATE=2.5; // deep wounds here hit an artery: they bleed this much faster, in spurts
  const CLOT=.012,DRY_TIME=30,POOL_MAX=46,BODY_STAINS=5,BLOOD='#922c33',OIL='#2f4a4f'; // clotting per second at rest; seconds for blood to dry; biggest pool; stains kept per body
  const GIB_LIFE=14,GIB_MAX=36; // seconds a gib lasts, and how many may exist at once
  const FRACTURE=50,FRACTURE_SLACK=.7; // bone at or below this is fractured; a fractured limb's joints bend this much further
  // ---- Muscles. A pose is a table of joint targets, keyed by the slot of the joint's outer part: [angle relative to the parent part, strength multiplier].
  // Angles are for a right-facing body and are mirrored for a left-facing one. Anything a pose does not mention is [0, 1]: straight, full strength.
  // Arms are mirror images of each other (the left elbow bends negative, the right positive), so arm entries come in pairs.
  const POSES={
    stand:{5:[.05,1],8:[-.05,1]},
    kneel:{11:[.15,1.3],14:[.15,1.3],12:[1.9,1.3],15:[1.9,1.3],13:[.4,.6],16:[.4,.6]},                                  // on the knees, shins folded back
    crouch:{11:[-1.05,1.5],14:[-1.05,1.5],12:[2.0,1.5],15:[2.0,1.5],3:[.15,1],5:[-.5,1.5],8:[.5,1.5]},               // knees under the body, ready to rise
    gather:{11:[-.7,1.2],14:[-.7,1.2],12:[1.4,1.2],15:[1.4,1.2],5:[-.9,2],8:[.9,2],6:[-1.3,2],9:[1.3,2]},            // lying: limbs drawn in, hands under the shoulders
    pushup:{11:[-.5,1.2],14:[-.5,1.2],12:[1.2,1.2],15:[1.2,1.2],5:[-1.4,5],8:[1.4,5],6:[-.15,5],9:[.15,5]},          // arms straighten against the floor
    crawl:{11:[-.35,.8],14:[-.35,.8],12:[.9,.8],15:[.9,.8],0:[0,1.5]},                                               // belly down; the arm cycle is added on top
    curl:{11:[-1.25,1],14:[-1.25,1],12:[2.2,1],15:[2.2,1],3:[.35,1],4:[.35,1],1:[.3,1],0:[.3,1],5:[-.7,1.5],8:[.7,1.5],6:[-2.1,1.5],9:[2.1,1.5]},
    limp:Object.fromEntries(Array.from({length:17},(_,slot)=>[slot,[0,0]]))        // every muscle off: unconscious or dead
  };
  // How strong each joint's muscles are next to each other, and how hard any of them can pull: the error a muscle "sees" is capped, which caps its torque.
  const MUSCLE={atlas:.5,neck:.8,spine:1.6,waist:1.6,shoulder:.32,elbow:.26,wrist:.16,hip:1.7,knee:1.7,ankle:1.3},MUSCLE_KP=.0034,MUSCLE_KD=.0042,MUSCLE_REACH=.45,MUSCLE_MAX=2,POSE_BLEND=.25; // MUSCLE_MAX: the chest carries five joints, so their stiffnesses add up on it; much above 2 each and a rigid pose rings, then explodes
  // Reactions. FLINCH: seconds a flinch lasts. STEP: seconds per recovery step, and how far a stagger shifts the balance point (px per point of damage, capped).
  const GETUP_STAGES=[['gather',.35],['pushup',.5],['crouch',.45]],KNEEL_HEIGHT=96,CRAWL_PULL=.34,CRAWL_PRESS=.45,CRAWL_LIFT=.05,CRAWL_SPEED=.9,CRAWL_PERIOD=.9,FLEE_TIME=5; // get-up stages [pose, seconds]; crawl forces are fractions of body weight
  const CLUTCH_PAIN=14,GUARD_HP=75,SPARE_LEG_HP=40,SHOCK_LOCK=.6,SHOCK_LIMP=.8,ARM_UPPER=34,ARM_FORE=38; // pain at which a hand goes to the wound; part hp below which an arm is guarded / a leg is kept off the floor; shock timings; arm lengths for the reach
  const BRACED=.6; // px per step: faster than this downward and a part is not planted, it is falling
  const LIMB_SPEED=45,LIMB_SPIN=.5; // px and radians per step
  const KNEEL_BLOOD=50,SLUMP_BLOOD=44,TWITCH_WINDOW=3.5; // blood levels at which a body can no longer stand, then no longer kneel; seconds after death in which a nerve may still fire
  const AWARE_EVERY=.1,SEE_FAST=5,SEE_RANGE=300,INCOMING=.45,HEAT_NEAR=70,WITNESS_RANGE=340; // awareness runs ten times a second; px/step that counts as fast; how far it notices; seconds ahead it anticipates a hit; how close heat has to be; how far away a neighbour's injury startles
  const KNOCKDOWN=32; // damage in one blow that puts a body on the floor; anything less is a flinch or a stagger
  const FLINCH_TIME=.22,STEP_TIME=.3,STAGGER_PUSH=.9,STAGGER_MAX=26,BRACE_TILT=.6,BRACE_FALL=5;
  const STUN_PART={'upper arm':0,forearm:0,hand:0,foot:.3,shin:.6,thigh:.7}; // how much a hit there knocks the whole body down; unlisted parts count fully
  const MIRROR={5:8,6:9,7:10,8:5,9:6,10:7,11:14,12:15,13:16,14:11,15:12,16:13}; // left limb slots to right and back
  const defaults=()=>Object.fromEntries(SETTINGS.map(s=>[s.id,s.def]));
  // Saved settings come from localStorage or an imported file, so every value is checked against the table before it is used.
  const sanitize=(input={})=>{const out={};for(const s of SETTINGS){const v=input?.[s.id];
    if(s.type==='toggle'&&typeof v==='boolean')out[s.id]=v;else if(s.type==='select'&&s.options.includes(v))out[s.id]=v;else if(s.type==='range'&&typeof v==='number'&&Number.isFinite(v))out[s.id]=clamp(v,s.min,s.max);}return out;};
  // Joint template: [parent slot, child slot, anchor on parent, anchor on child, min, max, name]. Slots index ANATOMY. Regeneration regrows from the same table.
  const JOINTS=[
    [1,0,{x:0,y:-7},{x:0,y:14},-.6,.6,'atlas'],[2,1,{x:0,y:-18},{x:0,y:6},-.35,.35,'neck'],[2,3,{x:0,y:17},{x:0,y:-11},-.4,.4,'spine'],[3,4,{x:0,y:10},{x:0,y:-11},-.4,.4,'waist'],
    [2,5,{x:-21,y:-12},{x:3,y:-16},-2.6,1.4,'shoulder'],[5,6,{x:-1,y:17},{x:0,y:-16},-2.5,.08,'elbow'],[6,7,{x:0,y:15},{x:0,y:-7},-.65,.65,'wrist'],
    [2,8,{x:21,y:-12},{x:-3,y:-16},-1.4,2.6,'shoulder'],[8,9,{x:1,y:17},{x:0,y:-16},-.08,2.5,'elbow'],[9,10,{x:0,y:15},{x:0,y:-7},-.65,.65,'wrist'],
    [4,11,{x:-10,y:11},{x:0,y:-22},-1.3,1.3,'hip'],[11,12,{x:0,y:22},{x:0,y:-20},-.06,2.4,'knee'],[12,13,{x:0,y:20},{x:0,y:-4},-.5,.7,'ankle'],
    [4,14,{x:10,y:11},{x:0,y:-22},-1.3,1.3,'hip'],[14,15,{x:0,y:22},{x:0,y:-20},-.06,2.4,'knee'],[15,16,{x:0,y:20},{x:0,y:-4},-.5,.7,'ankle']
  ];
  const LOCK_STIFFNESS=1.25,SLOT_MUSCLE=Array.from({length:17},(_,slot)=>{const t=JOINTS.find(j=>j[1]===slot);return t?MUSCLE[t[6]]:1;}); // each slot's usual muscle strength, so a pose can ask for one absolute stiffness everywhere
  const LIMIT_GAIN=.4,LIMIT_SPEED=.3,REST_SPEED=.8,REST_DELAY=1,AIR_TONE=.1,AIR_LIMP=.35,HAND_REACH=30,AIM_STRENGTH=.0022,REGROW_BEAT=.42,REGROW_SWELL=.5,STAND_HEIGHT=148,GETUP_TORQUE=3,EARTH=9.81; // calibration knobs: limit stiffness, and rest thresholds just above the solver's idle jitter
  class Simulation {
    constructor() {
      this.engine=Engine.create({positionIterations:10,velocityIterations:10,constraintIterations:10,enableSleeping:false});
      this.world=this.engine.world;this.entities=[];this.particles=[];this.flashes=[];this.traces=[];this.stains=[];
      this.nextId=1;this.time=0;this.gravity=1;this.onEffect=()=>{};this.drag=null;this.damageQueue=[];this.touching=new Set();this.piercing=new Map();this.regrowing=[];this.spare=[];this.tick=0;this.poseWant={angle:new Array(17).fill(0),power:new Array(17).fill(1)};this.support=[];this.shares=[];this.aimSet=new Set();this.random=Math.random;this.smears=new WeakMap();this.settings=defaults();
      this.groundY=650;this.width=2600;this.height=1000;this.scene='workshop';
      this.boundaries=[Bodies.rectangle(1300,720,3000,140,{isStatic:true,label:'Ground'}),Bodies.rectangle(-50,100,100,1300,{isStatic:true}),Bodies.rectangle(2650,100,100,1300,{isStatic:true}),Bodies.rectangle(1300,-420,3000,100,{isStatic:true})];
      this.boundaries.forEach(b=>{b.plugin={boundary:true};b.friction=.85;b.frictionStatic=1;});Composite.add(this.world,this.boundaries);
      Events.on(this.engine,'collisionStart',e=>this.collisions(e.pairs));Events.on(this.engine,'collisionActive',e=>this.disturb(e.pairs));
    }
    seed(n){let a=n>>>0;this.random=random=()=>{a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};return this;} // mulberry32
    // Change settings. Values are validated against the table; things that live on the engine or on bodies are pushed out here.
    configure(values){
      Object.assign(this.settings,sanitize(values));const s=this.settings;this.gravity=s.gravity/EARTH;
      this.engine.positionIterations=this.engine.velocityIterations=this.engine.constraintIterations=s.iterations;
      this.boundaries[0].friction=s.snow?.12:.85;this.boundaries[0].frictionStatic=s.snow?.2:1;
      for(const b of this.bodies)b.frictionAir=this.drag_(b);for(const e of this.entities)e.restTime=0;return s;
    }
    drag_(body){return (body.plugin.part?.015:.006)*this.settings.airDrag;}
    get bodies(){return Composite.allBodies(this.world).filter(b=>!b.plugin.boundary);}
    get joints(){return Composite.allConstraints(this.world).filter(c=>c!==this.drag);}
    meta(body,kind,extra={}) {
      const d=defs[kind]||{};body.plugin={kind,material:d.material||'flesh',hp:d.hp||100,maxHp:d.hp||100,heat:this.settings.ambient,burning:false,charge:0,active:false,w:d.w,h:d.h,r:d.r,...extra};
      return body;
    }
    entity(kind,bodies,joints=[]) {
      const entity={id:this.nextId++,kind,bodies,joints};
      for(const b of bodies)b.plugin.entityId=entity.id;
      this.entities.push(entity);Composite.add(this.world,[...bodies,...joints]);return entity;
    }
    spawn(kind,x,y,flip=false) {
      if(this.bodies.length>=this.settings.maxObjects)return null;
      if(kind==='human'||kind==='android')return this.ragdoll(kind,x,y,flip);
      const d=defs[kind];if(!d)return null;
      const opts={density:d.density??d.mat.density,friction:d.mat.friction,frictionStatic:.9,restitution:d.restitution??d.mat.restitution,frictionAir:.006*this.settings.airDrag,isStatic:!!d.static,label:kind};
      const b=d.r?Bodies.circle(x,y,d.r,opts):Bodies.rectangle(x,y,d.w,d.h,{...opts,chamfer:{radius:d.sharp?1:3}});
      this.meta(b,kind,flip?{flip:true}:{});return this.entity(kind,[b]);
    }
    makePart(kind,slot,x,y,angle,group,flip) {
      const robot=kind==='android',[name,,,w,h]=ANATOMY[slot],density=(robot?.0036:.0018)*(name==='head'?1.15:name==='chest'?1.3:1);
      const b=Bodies.rectangle(x,y,w,h,{collisionFilter:{group},density,friction:.8,frictionStatic:1,restitution:0,frictionAir:.015*this.settings.airDrag,chamfer:{radius:Math.min(w/2-1,name==='head'?8:4)}});
      this.meta(b,kind,{part:name,slot,w,h,r:0,material:robot?'metal':'flesh',hp:robot?230:100,maxHp:robot?230:100,wounds:[],severed:[],bleed:0,bone:100,...(flip?{flip:true}:{})});
      if(angle)Body.setAngle(b,angle);return b;
    }
    makeJoint(kind,flip,a,b,[,,pa,pb,min,max,name]) {
      // Anchors are stored unrotated; a regrown limb hangs off a body that may be at any angle.
      const c=Constraint.create({bodyA:a,bodyB:b,pointA:Vector.rotate(pa,a.angle),pointB:Vector.rotate(pb,b.angle),length:0,stiffness:.97,damping:.2});
      c.plugin={joint:true,breakForce:kind==='android'?45:29,min:flip?-max:min,max:flip?-min:max,name};return c;
    }
    ragdoll(kind,x,y,flip=false) {
      const group=Body.nextGroup(true),parts=ANATOMY.map(([,dx,dy],slot)=>this.makePart(kind,slot,x+dx,y+dy,0,group,flip));
      const joints=JOINTS.map(t=>this.makeJoint(kind,flip,parts[t[0]],parts[t[1]],t));
      const e=this.entity(kind,parts,joints);e.upright=true;e.blood=100;e.alive=true;return e;
    }
    getEntity(body){return body&&this.entities.find(e=>e.id===body.plugin.entityId);}
    // Every part still joined to this one, through living joints.
    connected(body,links=this.joints.filter(c=>c.plugin.joint)){
      const whole=new Set([body]),queue=[body];
      while(queue.length){const current=queue.shift();for(const c of links){const other=c.bodyA===current?c.bodyB:c.bodyB===current?c.bodyA:null;if(other&&!whole.has(other)){whole.add(other);queue.push(other);}}}
      return whole;
    }
    // Join a loose piece to a body wherever the anatomy allows: find a template joint with one end on each, swing the piece to the stump's angle, slide the anchors together, pin it.
    seat(main,owner,piece,links,prefer) {
      const slotOf=set=>new Map([...set].map(b=>[b.plugin.slot,b])),have=slotOf(main),bring=slotOf(piece);if([...bring.keys()].some(slot=>have.has(slot)))return false; // that place is already taken
      const fits=([pa,pb])=>(have.has(pa)&&bring.has(pb))||(have.has(pb)&&bring.has(pa)),t=JOINTS.find(j=>fits(j)&&(!prefer||j[0]===prefer.plugin.slot||j[1]===prefer.plugin.slot))||JOINTS.find(fits);if(!t)return false;
      const a=have.get(t[0])||bring.get(t[0]),b=have.get(t[1])||bring.get(t[1]),stump=main.has(a)?a:b,limb=stump===a?b:a,flip=!!stump.plugin.flip,anchor=x=>Vector.add(x.position,Vector.rotate(x===a?t[2]:t[3],x.angle));
      const turn=stump.angle-limb.angle,pivot=anchor(limb);for(const x of piece){if(x.isStatic)Body.setStatic(x,false);Body.rotate(x,turn,pivot);}
      const to=anchor(stump),move=Vector.sub(to,anchor(limb));for(const x of piece){Body.translate(x,move);Body.setVelocity(x,stump.velocity);Body.setAngularVelocity(x,0);}
      const joint=this.makeJoint(owner.kind,flip,a,b,t);if(a.plugin.kind==='android'||b.plugin.kind==='android')joint.plugin.breakForce=45;Composite.add(this.world,joint);links.push(joint);
      for(const x of [a,b]){x.plugin.severed=[];this.bleedOf(x.plugin);}
      for(const x of piece){const old=this.getEntity(x);if(old&&old!==owner){old.bodies=old.bodies.filter(o=>o!==x);old.joints=old.joints.filter(c=>c.bodyA!==x&&c.bodyB!==x);}if(!owner.bodies.includes(x))owner.bodies.push(x);
        x.plugin.entityId=owner.id;x.collisionFilter.group=stump.collisionFilter.group;if(flip)x.plugin.flip=true;else delete x.plugin.flip;main.add(x);}
      owner.bodies.sort((x,y)=>x.plugin.slot-y.plugin.slot);owner.joints=links.filter(c=>main.has(c.bodyA));this.entities=this.entities.filter(e=>e.bodies.length);owner.restTime=0;this.burst(to.x,to.y,8,'#9fcbb1',2);return to;
    }
    // Hands: an empty hand takes the nearest loose object within reach. The object is welded to the hand by two pins and joins the body's no-collide group, so it cannot fight the arm holding it.
    held(hand){return this.joints.find(c=>c.plugin.hold&&c.bodyA===hand)?.bodyB||null;}
    equip(hand) {
      if(hand?.plugin.part!=='hand')return '';const e=this.getEntity(hand);if(!e||this.held(hand))return '';
      const reach=b=>{const dx=Math.max(b.bounds.min.x-hand.position.x,0,hand.position.x-b.bounds.max.x),dy=Math.max(b.bounds.min.y-hand.position.y,0,hand.position.y-b.bounds.max.y);return Math.hypot(dx,dy);};
      const item=this.bodies.filter(b=>!b.plugin.part&&!b.isStatic&&!b.plugin.debris&&b.plugin.heldBy===undefined&&b.plugin.stuck===undefined&&reach(b)<=HAND_REACH).sort((a,b)=>reach(a)-reach(b))[0];if(!item)return '';
      // Where and how each thing is held, in the item's own frame: grip point, and its angle relative to the hand.
      const flip=!!hand.plugin.flip,side=flip?-1:1,def=defs[item.plugin.kind]||{},grip=def.grip||(def.firearm?{x:-14,y:9}:def.sharp?{x:0,y:item.plugin.h*.37}:{x:0,y:0}),tilt=def.firearm?side*Math.PI/2:def.sharp?side*1.15:0; // a pistol lies along the forearm, so raising the arm levels it
      if(flip)item.plugin.flip=true;else delete item.plugin.flip;Body.setAngle(item,hand.angle+tilt);const local=Vector.rotate({x:grip.x*side,y:grip.y},item.angle);
      Body.setPosition(item,Vector.sub(hand.position,local));Body.setVelocity(item,hand.velocity);Body.setAngularVelocity(item,0);item.collisionFilter.group=hand.collisionFilter.group;item.plugin.heldBy=e.id;
      // The second pin sits at the item's centre of mass: a long lever, so the weight of a pistol cannot twist it in the hand.
      const toCentre=Vector.sub(item.position,hand.position),axis=Vector.magnitude(toCentre)>6?toCentre:Vector.rotate({x:0,y:-12},item.angle);for(const offset of [{x:0,y:0},axis]){const point=Vector.add(hand.position,offset);const c=Constraint.create({bodyA:hand,bodyB:item,pointA:offset,pointB:Vector.sub(point,item.position),length:0,stiffness:.9,damping:.2});c.plugin={hold:true};Composite.add(this.world,c);}
      e.restTime=0;this.onEffect('impact',.2);return `Picked up the ${(CATALOG.find(c=>c.id===item.plugin.kind)?.name||'object').toLowerCase()}`;
    }
    release(item){for(const c of this.joints.filter(c=>c.plugin.hold&&c.bodyB===item))Composite.remove(this.world,c);item.collisionFilter.group=0;delete item.plugin.heldBy;}
    // Things leave a hand when the cursor takes them (see beginDrag), when the holder dies, or when the hand is gone. A tug cannot be the test: pulling a held pistol just drags its owner along.
    hands(){for(const item of this.bodies){if(item.plugin.heldBy===undefined)continue;const pins=this.joints.filter(c=>c.plugin.hold&&c.bodyB===item),e=pins[0]&&this.getEntity(pins[0].bodyA);if(!pins.length||!e||!e.alive)this.release(item);}}
    // Dismember: cut the clicked part off at the joint that ties it to the rest of the body (the side nearer the chest). The chest has no such joint, so it loses everything attached to it.
    dismember(body) {
      if(body?.plugin.slot===undefined)return '';const joints=this.joints.filter(c=>c.plugin.joint&&(c.bodyA===body||c.bodyB===body)),inward=joints.filter(c=>c.bodyB===body),cut=inward.length?inward:joints;
      for(const c of cut)this.sever(c);const e=this.getEntity(body);if(e&&cut.length)e.stun=Math.max(e.stun||0,1.2*this.settings.stunScale);return cut.map(c=>c.plugin.name).join(', ');
    }
    // Graft: put any ragdoll's loose limb on any ragdoll's stump, human or android, left or right. A limb from the other side is mirrored to fit.
    graft(stump,limb) {
      if(stump?.plugin.slot===undefined||limb?.plugin.slot===undefined)return 'Pick a ragdoll part, then a loose limb.';
      const links=this.joints.filter(c=>c.plugin.joint),main=this.connected(stump,links),piece=this.connected(limb,links),owner=this.getEntity(stump);
      if(main.has(limb))return 'That limb is already part of this body.';if(!owner)return 'That body is gone.';if(piece.size>main.size)return 'Graft the smaller piece onto the larger one.';
      let at=this.seat(main,owner,piece,links,stump);
      if(!at){const original=[...piece].map(b=>b.plugin.slot);for(const b of piece)b.plugin.slot=MIRROR[b.plugin.slot]??b.plugin.slot;at=this.seat(main,owner,piece,links,stump);if(!at)[...piece].forEach((b,i)=>b.plugin.slot=original[i]);}
      if(!at)return 'It does not fit there: that place is taken, or the two do not join.';
      // The surge: a jolt of power through the whole body, which also gets it back on its feet.
      for(const b of owner.bodies)b.plugin.surge=piece.has(b)?1:.55;owner.surge=3;owner.stun=0;owner.effort=1;if(owner.alive===false&&owner.bodies.some(b=>b.plugin.slot===2)&&owner.bodies.some(b=>b.plugin.slot===0)){owner.alive=true;owner.upright=true;owner.blood=Math.max(owner.blood||0,60);}
      this.flashes.push({x:at.x,y:at.y,radius:150,life:.7,maxLife:.7,surge:true});this.burst(at.x,at.y,40,'#8fe9ff',9);this.burst(at.x,at.y,18,'#ffffff',5);
      for(let i=0;i<7;i++){const angle=i/7*Math.PI*2+rnd(-.3,.3),reach=rnd(60,130);this.traces.push({from:{...at},to:{x:at.x+Math.cos(angle)*reach,y:at.y+Math.sin(angle)*reach},life:rnd(.25,.5),maxLife:.5,electric:true});}
      this.onEffect('surge',1);return '';
    }
    // Put torn-off pieces back where they came from. Parts of one ragdoll share a collision group, which is how a loose limb finds its owner.
    // Click the loose piece to reattach just that; click the body to collect everything that still fits.
    reattach(body) {
      if(body?.plugin.slot===undefined)return 0;const group=body.collisionFilter.group,parts=this.bodies.filter(b=>b.collisionFilter.group===group&&b.plugin.slot!==undefined);
      const links=this.joints.filter(c=>c.plugin.joint),clicked=this.connected(body,links),chest=parts.find(b=>b.plugin.slot===2&&this.getEntity(b)?.blood!==undefined&&this.getEntity(b).blood>0)||parts.find(b=>b.plugin.slot===2);
      const main=chest&&!clicked.has(chest)?this.connected(chest,links):clicked,owner=this.getEntity([...main][0]);if(!owner)return 0;
      const loose=[];for(const b of parts)if(!main.has(b)&&!loose.some(set=>set.has(b)))loose.push(this.connected(b,links));
      let attached=0;for(let progress=true;progress;){progress=false;for(const piece of main===clicked?loose:loose.filter(set=>set.has(body))){
        if(piece.done||!this.seat(main,owner,piece,links))continue;piece.done=true;attached++;progress=true;}}
      this.entities=this.entities.filter(e=>e.bodies.length);owner.restTime=0;return attached;
    }
    // Regrow whatever is missing from the body the clicked part belongs to. Torn-off pieces stay where they fell, as remains.
    // Growth is staged: one part at a time, spreading outward from the clicked part, so a lone head grows a neck, then a chest, then the rest.
    regenerate(body) {
      const e=this.getEntity(body);if(!e||e.blood===undefined||body.plugin.slot===undefined)return 0;
      const links=this.joints.filter(c=>c.plugin.joint),whole=this.connected(body,links),missing=ANATOMY.length-whole.size;if(!missing)return 0;
      if(this.regrowing.some(job=>whole.has(job.root)))return missing;
      // The clicked body keeps the identity only if it still has its chest; a regrowing stray limb becomes a new person, and what is left behind is remains.
      const remains=e.bodies.filter(b=>!whole.has(b)),keeps=[...whole].some(b=>b.plugin.slot===2),owner=keeps?e:{id:this.nextId++,kind:e.kind,bodies:[],joints:[],upright:true,blood:100,alive:true};
      if(!keeps){this.entities.push(owner);e.bodies=remains;e.joints=e.joints.filter(c=>remains.includes(c.bodyA));e.alive=false;e.upright=false;}
      else if(remains.length){const left={id:this.nextId++,kind:e.kind,bodies:remains,joints:e.joints.filter(c=>remains.includes(c.bodyA)),upright:false,blood:0,alive:false};this.entities.push(left);for(const b of remains)b.plugin.entityId=left.id;}
      owner.bodies=[...whole].sort((a,b)=>a.plugin.slot-b.plugin.slot);owner.joints=links.filter(c=>whole.has(c.bodyA));for(const b of owner.bodies)b.plugin.entityId=owner.id;
      this.entities=this.entities.filter(x=>x.bodies.length);for(const b of whole){b.plugin.severed=[];this.bleedOf(b.plugin);}
      this.regrowing.push({root:body,wait:0});owner.restTime=0;return missing;
    }
    // One part per beat. The new part is full size to the physics at once; plugin.grow (0..1) lets the renderer swell it out of the stump.
    growNext(job) {
      const owner=this.getEntity(job.root);if(!owner||!this.bodies.includes(job.root))return false;
      const whole=this.connected(job.root),slots=new Map([...whole].map(b=>[b.plugin.slot,b]));
      for(const stump of whole)for(const t of JOINTS){const [pa,pb]=t,have=stump.plugin.slot;if((pa!==have&&pb!==have)||slots.has(pa)===slots.has(pb))continue;
        const need=have===pa?pb:pa,flip=!!stump.plugin.flip,offset=Vector.rotate({x:ANATOMY[need][1]-ANATOMY[have][1],y:ANATOMY[need][2]-ANATOMY[have][2]},stump.angle);
        const part=this.makePart(owner.kind,need,stump.position.x+offset.x,stump.position.y+offset.y,stump.angle,stump.collisionFilter.group,flip);Body.setVelocity(part,stump.velocity);
        part.plugin.grow=0;part.plugin.growFrom={...(need===pb?t[3]:t[2])};part.plugin.entityId=owner.id;slots.set(need,part);
        const joint=this.makeJoint(owner.kind,flip,slots.get(pa),slots.get(pb),t);Composite.add(this.world,[part,joint]);
        owner.bodies.push(part);owner.bodies.sort((a,b)=>a.plugin.slot-b.plugin.slot);owner.joints.push(joint);owner.restTime=0;owner.effort=Math.min(owner.effort??1,.4);
        const at=Vector.add(stump.position,Vector.rotate(need===pb?t[2]:t[3],stump.angle));this.burst(at.x,at.y,14,'#9fe0c0',3.5);this.burst(part.position.x,part.position.y,8,owner.kind==='human'?'#c9545a':'#9fd8e8',2.5);
        this.flashes.push({x:part.position.x,y:part.position.y,radius:34,life:.4,maxLife:.4,grow:true});this.onEffect('grow',.25+.5*(1-whole.size/ANATOMY.length));return true;}
      return false;
    }
    // upright = wants to stand. Whether it can is derived from what is left of the body, so losing an arm never drops it but losing the spine does.
    canStand(e){
      if(!e.alive||!e.upright)return false;const part=n=>e.bodies.filter(b=>b.plugin.part===n),chest=part('chest')[0],head=part('head')[0];
      if(!chest||!head||chest.plugin.hp<35||head.plugin.hp<35)return false;
      const live=this.joints.filter(c=>c.plugin.joint&&c.bodyA.plugin.entityId===e.id),has=n=>live.filter(c=>c.plugin.name===n).length;
      if(!has('atlas')||!has('neck')||!has('spine')||!has('waist'))return false;
      if(live.some(c=>c.bodyB.plugin.slot>=11&&this.fractured(c.bodyB)))return false; // a broken leg that is still attached cannot be stood around: it goes down and crawls. A missing one can: that is hopping.
      return part('foot').some(foot=>{const ankle=live.find(c=>c.bodyB===foot),knee=ankle&&live.find(c=>c.bodyB===ankle.bodyA),hip=knee&&live.find(c=>c.bodyB===knee.bodyA);return !!hip&&foot.plugin.hp>0&&this.bears(foot,live);});
    }
    // A leg carries weight only if none of its bones is fractured.
    fractured(b){return b.plugin.material==='flesh'&&b.plugin.slot>=5&&(b.plugin.bone??100)<=FRACTURE;} // limbs only: cracked ribs or a cracked skull hurt, but the trunk still holds itself up
    bears(foot,live=this.joints.filter(c=>c.plugin.joint)){for(let b=foot;b&&b.plugin.part!=='pelvis';b=live.find(c=>c.bodyB===b)?.bodyA)if(this.fractured(b))return false;return true;}
    balancing(e){return this.active(e)&&this.canStand(e);}
    active(e){return !!e.alive&&!!e.upright&&this.settings.autoBalance&&!(e.stun>0)&&e.consciousness!=='unconscious';}
    // stand -> kneel -> crawl -> drag -> curl. Legs that bear weight stand; knees without feet kneel; two good arms crawl, one drags; nothing left, or too much pain, curls up.
    capability(e) {
      if(e.kind==='human'&&((e.pain||0)>=88||e.blood<SLUMP_BLOOD))return 'curl';if(this.canStand(e))return e.kind==='human'&&e.blood<KNEEL_BLOOD?'kneel':'stand'; // bleeding out: first the legs go, then it slumps, then it is unconscious
      const live=this.joints.filter(c=>c.plugin.joint&&c.bodyA.plugin.entityId===e.id),joint=(slot)=>live.find(c=>c.bodyB.plugin.slot===slot),ok=slot=>{const c=joint(slot);return !!c&&!this.fractured(c.bodyB)&&c.bodyB.plugin.hp>0;};
      const chest=e.bodies.find(b=>b.plugin.slot===2),head=e.bodies.find(b=>b.plugin.slot===0);if(!chest||!head||chest.plugin.hp<35||head.plugin.hp<35||!joint(0)||!joint(1))return 'curl';
      const trunk=!!joint(3)&&!!joint(4),brokenLeg=live.some(c=>c.bodyB.plugin.slot>=11&&this.fractured(c.bodyB));if(trunk&&!brokenLeg&&((ok(11)&&ok(12))||(ok(14)&&ok(15))))return 'kneel'; // kneeling is for missing feet, not for broken legs
      const arms=(ok(5)&&ok(6)?1:0)+(ok(8)&&ok(9)?1:0);return arms===2?'crawl':arms===1?'drag':'curl';
    }
    revive(body){const e=this.getEntity(body);if(!e||e.blood===undefined)return false;this.heal(body);e.alive=true;e.upright=true;delete e.causeOfDeath;e.consciousness='awake';e.stun=0;e.stunNext=0;e.stunIn=0;e.stagN=0;e.flinch=0;e.effort=0;e.restTime=0;return true;}
    // After death a nerve may still fire once or twice: a limb jerks at one joint, equal and opposite on its two parts, and that is the end of it. Then the body is left to come to rest.
    twitch(e,seconds) {
      e.deadFor+=seconds;if(e.deadFor<e.twitchAt[0])return;e.twitchAt.shift();if(e.twitchAt[0]>TWITCH_WINDOW)e.twitchAt.length=0;
      const joints=this.joints.filter(c=>c.plugin.joint&&c.bodyA.plugin.entityId===e.id&&c.bodyB.plugin.slot>=5);if(!joints.length)return;const c=joints[(random()*joints.length)|0],a=c.bodyA,b=c.bodyB,total=a.inverseInertia+b.inverseInertia;if(!total)return;
      const kick=(random()<.5?-1:1)*.16;Body.setAngularVelocity(a,a.angularVelocity-kick*a.inverseInertia/total);Body.setAngularVelocity(b,b.angularVelocity+kick*b.inverseInertia/total);e.restTime=0;e.pin=null;e.lastTwitch=this.time;
    }
    // Once per step for every living ragdoll: what the injuries are doing to it. Humans only for blood, organs, oxygen and pain; androids have none of those.
    vitals(e,seconds) {
      const set=this.settings,head=e.bodies.find(b=>b.plugin.part==='head'),human=e.kind==='human';
      if(human){
        let open=0,inside=0;for(const b of e.bodies){const p=b.plugin;open+=p.bleed||0;if(p.internal){inside+=p.internal;p.bruise=Math.min(1,(p.bruise||0)+p.internal*seconds*.12);p.internal=Math.max(0,p.internal-seconds*.012);}} // internal bleeding shows as a spreading bruise, and clots slowly
        e.blood=Math.max(0,(e.blood??100)-(open*.5+inside)*seconds*set.bleedRate);
        const organs=e.organs,lungs=organs?organs.lungs:100;e.oxygen=clamp((e.oxygen??100)+seconds*(lungs<60?-(60-lungs)/60*5:8),0,100);
        e.pain=Math.max(0,(e.pain||0)-seconds*(open>.3?1.5:4)); // pain ebbs, slower while wounds are open
        e.hurtScore=Math.max(0,(e.hurtScore||0)-seconds*1.2);let burning=0;for(const b of e.bodies)if(b.plugin.burning)burning++;if(burning)e.pain=Math.min(100,e.pain+seconds*(12+burning*3)*set.painSensitivity); // being on fire keeps hurting
        e.burningParts=burning;e.breath=((e.breath||0)+seconds*(12+e.pain*.28+(e.rise||e.stagN>0?8:0))/60)%1;
        // The heart races with pain and with the first of the blood loss, then fails as the blood runs out. pulse is 0..1, the beat that arterial wounds spurt on.
        e.heartRate=clamp(70+(e.pain||0)*.7+Math.min(45,(100-e.blood)*1.1)-Math.max(0,50-e.blood)*2.6,20,190);e.beat=((e.beat||0)+seconds*e.heartRate/60)%1;e.pulse=Math.max(0,Math.sin(e.beat*Math.PI*2));
        const brain=organs?organs.brain:100;
        if(e.blood<25)this.kill(e,'blood loss');else if(e.oxygen<=0)this.kill(e,'suffocation');
        else e.consciousness=e.blood<40||e.oxygen<30||brain<35||e.pain>=97?'unconscious':e.blood<55||e.oxygen<55||brain<70||e.pain>70?'dazed':'awake';
        if(!e.alive)return;
      }else e.consciousness='awake';
      // Brain damage setting: the worse the head, the more often it blacks out.
      if(set.brainDamage&&head&&head.plugin.hp<60&&!(e.stun>0)&&random()<seconds*.25*(1-head.plugin.hp/60))e.stun=rnd(1,3.5);
      if(set.slowHealing){if(human){e.blood=Math.min(100,e.blood+seconds*.8);if(e.organs)for(const k in e.organs)e.organs[k]=Math.min(100,e.organs[k]+seconds*.4);}
        for(const b of e.bodies){const p=b.plugin;p.hp=Math.min(p.maxHp,p.hp+seconds*1.5);p.bone=Math.min(100,(p.bone??100)+seconds);for(const w of p.wounds||[])w.bleed=Math.max(0,(w.bleed||0)-seconds*.05);p.bruise=Math.max(0,(p.bruise||0)-seconds*.02);if(p.wounds?.length&&random()<seconds*.06)p.wounds.shift();}}
    }
    // A part's muscles work as well as the part does: nothing through a fracture, less as it is destroyed.
    strengthOf(b){return this.fractured(b)?0:clamp((b.plugin.hp??100)/50,.2,1);}
    // What a blow does to a living body before anything else: a flinch always, a stagger if it was standing, and only then, for the big ones, the knockdown.
    react(e,body,amount,direction,stun) {
      const slot=body.plugin.slot??2,dir=direction&&Math.abs(direction.x)>1e-6?Math.sign(direction.x):(e.bodies[2]&&body.position.x>e.bodies[2].position.x?-1:1);
      e.shoutT=amount>38?.5:0;if(e.kind==='human'&&this.settings.grunts&&amount>12&&e.consciousness!=='unconscious')this.onEffect('grunt',clamp(amount/60,.2,1));
      // Someone being hurt startles the conscious people near them: a small flinch, and they look.
      if(this.settings.awareness&&amount>15)for(const other of this.entities){if(other===e||other.kind!=='human'||!this.active(other)||other.flinch>0)continue;const oc=other.bodies[0];if(!oc||Math.abs(oc.position.x-body.position.x)>WITNESS_RANGE)continue;other.flinch=FLINCH_TIME*.7;other.flinchMag=.22;other.flinchSlot=2;other.flinchDir=Math.sign(oc.position.x-body.position.x)||1;other.startleX=body.position.x;other.startleAt=this.time;}
      e.fleeT=FLEE_TIME;e.flinch=FLINCH_TIME*clamp(amount/25,.8,1.6);e.flinchMag=clamp(amount/28,.12,1)*(e.consciousness==='dazed'?.55:1);e.flinchSlot=slot;e.flinchDir=dir;
      const standing=this.balancing(e)&&!(e.stagN>0)&&Math.abs(wrap(e.bodies[2]?.angle||0))<.4,torso=slot<=4;
      if(standing&&amount>10&&(torso||amount>25)){e.stagN=clamp(Math.round(amount/16),1,3);e.stagDir=dir;e.stagT=0;e.stagLeg=dir>0?0:1;e.stagPush=Math.min(STAGGER_MAX,amount*STAGGER_PUSH);}
      // A knockdown arrives through the stagger: the legs get a moment to try before they go.
      if(stun>0){if(standing){e.stunNext=Math.max(e.stunNext||0,stun);e.stunIn=.28;}else e.stun=Math.max(e.stun||0,stun);}
    }
    // Pose overlays for the moment: flinch, recovery steps, bracing. They write into the wanted pose; nothing is allocated.
    reactions(e,want,chest,down,seconds) {
      const A=want.angle,P=want.power,awake=e.consciousness!=='unconscious';
      if(e.flinch>0){e.flinch-=seconds;const m=e.flinchMag*clamp(e.flinch/FLINCH_TIME,0,1),d=e.flinchDir,s=e.flinchSlot;
        A[0]+=-d*.55*m;A[1]+=-d*.2*m;A[3]+=-d*.22*m;A[4]+=-d*.15*m;P[0]=P[1]=2;                       // head snaps back, torso twists away from the blow
        if(s>=5&&s<=7){A[5]+=.5*m;A[6]+=-1.4*m;P[5]=4;P[6]=9;}else if(s>=8&&s<=10){A[8]+=-.5*m;A[9]+=1.4*m;P[8]=4;P[9]=9;}       // the struck limb pulls in
        else if(s>=11&&s<=13){A[11]+=-.45*m;A[12]+=.9*m;P[12]=2;}else if(s>=14){A[14]+=-.45*m;A[15]+=.9*m;P[15]=2;}
        else{A[5]+=-.35*m;A[6]+=-.7*m;A[8]+=.35*m;A[9]+=.7*m;}}                                         // a blow to the trunk: both arms come in
      if(e.stagN>0){if(down||!awake){e.stagN=0;}else{e.stagT+=seconds;const swing=e.stagT<STEP_TIME*.5,hip=e.stagLeg?14:11,d=e.stagDir;
          A[hip]+=-d*(swing?.42:.2);A[hip+1]+=swing?.7:.1;P[hip]=1.5;P[hip+1]=1.5;                                             // pick a leg up and swing it the way the body is going, then set it down ahead
          if(e.stagT>=STEP_TIME){e.stagT=0;e.stagLeg^=1;e.stagN--;e.stagPush*=.45;}}}
      // Bracing: tipping over, or dropping fast, and awake. Arms go out toward the ground on the side it is falling to; the head turns away from it.
      const tilt=wrap(chest.angle),falling=chest.velocity.y>BRACE_FALL,moving=chest.speed>1.2&&!this.touching.has(chest);if(awake&&moving&&(Math.abs(tilt)>BRACE_TILT||falling)&&!(e.stun>0)){ /* only on the way down: a body already on the ground gets up instead */ const f=Math.abs(tilt)>.15?Math.sign(tilt):Math.sign(chest.velocity.x)||1;e.bracing=.4;e.braceDir=f;}
      if(e.bracing>0){e.bracing-=seconds;const f=e.braceDir;A[5]=-f*1.25-tilt*.5;A[8]=-f*1.25-tilt*.5;A[6]=-.35;A[9]=.35;A[7]=A[10]=0;A[0]=-f*.45;P[5]=P[8]=6;P[6]=P[9]=4;P[0]=2;want.armsFree=true;}else want.armsFree=false;
    }
    // The weight the muscles are working against: only what is still attached to the chest. Severed limbs stay in the entity but are no longer carried. Refreshed ten times a second.
    carried(e,chest){if(!(this.time-(e.massAt??-1)<.1)){e.massAt=this.time;let m=0;for(const b of this.connected(chest))m+=b.mass;e.liveMass=m;}return e.liveMass;}
    // Blend toward the wanted pose. Layers are applied in order, later ones overriding the joints they mention; an armed hand's arm is aimed last of all.
    pose(e,base,aiming,chest,down,seconds,rung) {
      const now=e.poseNow??={angle:new Array(17).fill(0),power:new Array(17).fill(1)},want=this.poseWant,k=1-Math.exp(-seconds/(e.flinch>0?.05:POSE_BLEND));want.angle.fill(0);want.power.fill(1); // a flinch is quick: the blend tightens while it lasts
      for(const slot in base){want.angle[slot]=base[slot][0];want.power[slot]=base[slot][1];}
      const crawlDir=(rung==='crawl'||rung==='drag')?this.crawl(e,want,chest,rung,seconds):0;
      this.sustain(e,want,chest,down,seconds,rung);this.reactions(e,want,chest,down,seconds);
      if(!down)for(const b of aiming){const slot=b.plugin.slot,shoulder=slot===5||slot===8;want.angle[slot]=shoulder?-1.45-chest.angle*(b.plugin.flip?-1:1):0;want.power[slot]=shoulder?7:4;} // point the armed arm forward, whatever the chest is doing
      for(let i=0;i<17;i++){now.angle[i]+=(want.angle[i]-now.angle[i])*k;now.power[i]+=(want.power[i]-now.power[i])*k;}return crawlDir;
    }
    // What a hurt body does for as long as it hurts. Everything here is a change to the wanted pose: the muscles do the rest.
    sustain(e,want,chest,down,seconds,rung) {
      const A=want.angle,P=want.power,set=this.settings,human=e.kind==='human',k=set.reactionIntensity,pain=human&&set.painReactions?(e.pain||0)/100:0,flip=chest.plugin.flip?-1:1;
      // Electric shock: every muscle locks where it was, at full strength, shaking. When the current stops the body goes slack for a moment (an android reboots).
      if(e.shockT>0){e.shockT-=seconds;const lock=e.lockPose??=[...e.poseNow.angle];for(let i=0;i<17;i++){A[i]=lock[i]+Math.sin(this.time*55+i*2.4)*.025*k;P[i]=LOCK_STIFFNESS/SLOT_MUSCLE[i];} // the same stiffness at every joint, whatever its usual strength: rigid, but not so rigid that the whole body rings
        if(e.shockT<=0){e.lockPose=null;e.poseNow.power.fill(1);e.stun=Math.max(e.stun||0,SHOCK_LIMP);}return;}
      e.lockPose=null;
      if(human&&set.breathing){const b=Math.sin(e.breath*Math.PI*2),weak=e.blood<45,depth=(.035+pain*.05)*(weak?.45:1)*(weak?1+.5*Math.sin(this.time*5.3):1);A[5]+=b*depth;A[8]-=b*depth;A[3]+=b*depth*.35;A[1]-=b*depth*.3;} // shoulders rise and fall, the spine with them
      if(!human){ // androids feel nothing, but damaged actuators glitch: jerky, more so the worse off it is
        let hp=0;for(const b of e.bodies)hp+=b.plugin.hp/b.plugin.maxHp;hp/=e.bodies.length||1;if(hp<.6){const g=(.6-hp)*1.2*k;for(let i=5;i<17;i++)A[i]+=(Math.floor(this.time*9+i*3.7)%5-2)*.06*g*((i*7+Math.floor(this.time*9))%3);if(random()<seconds*g*4){const b=e.bodies[(random()*e.bodies.length)|0];this.burst(b.position.x,b.position.y,3,'#ffe7a0',4);}}return;}
      if(set.awareness){const head=e.bodies.find(b=>b.plugin.slot===0);e.awareT=(e.awareT||0)+seconds;if(head&&e.awareT>=AWARE_EVERY){e.awareT=0;this.aware(e,chest,head,this.bodiesNow);}
        if(head&&e.lookX!=null){const d=Math.sign(e.lookX-head.position.x);e.gaze=d;A[0]+=d*.11*k*flip;A[1]+=d*.04*k*flip;}else e.gaze=0;                       // head and eyes to the threat
        if(e.heatDir){A[3]+=-e.heatDir*.2*flip;for(const [sh,side] of [[5,-1],[8,1]])if(side===-e.heatDir||true){A[sh]+=-e.heatDir*.55*flip;P[sh]=2.5;}e.leanAway=e.heatDir*14;}else e.leanAway=0; // shrink from heat: torso and arms bend away, and the balance point shifts
        if(e.guardT>0&&head){e.guardT-=seconds;const bodyAt=slot=>e.bodies.find(b=>b.plugin.slot===slot);for(const [sh,side] of [[5,-1],[8,1]]){const upper=bodyAt(sh),fore=bodyAt(sh+1);if(!upper||!fore||this.fractured(upper)||this.fractured(fore))continue;
            this.reach(want,chest,{sh,side,sx:upper.position.x+Math.sin(upper.angle)*upper.plugin.h/2,sy:upper.position.y-Math.cos(upper.angle)*upper.plugin.h/2},head.position.x-e.guardDir*6,head.position.y-4,flip,6);}
          A[3]+=e.guardDir*.18*flip;e.leanAway=e.guardDir*18;}}                                                                                                   // arms over the head, and duck away from it
      else{e.gaze=0;e.leanAway=0;}
      if(!set.painReactions)return; // from here on it is behaviour, not reflex. Most of it scales with pain; guarding a damaged limb does not need it to still hurt.
      // Trembling: slow noise on every limb joint (a random walk pulled back to zero, so it never jumps), worse with pain and with blood loss.
      const shake=e.tremor??=new Array(17).fill(0),amp=(pain*.9+Math.max(0,60-e.blood)/60)*.09*k;for(let i=0;i<17;i++){shake[i]+=(random()-.5)*seconds*26-shake[i]*seconds*9;A[i]+=shake[i]*amp;}
      // Hunching over the pain; the head sinks as the blood goes.
      A[3]+=.32*pain*k;A[4]+=.22*pain*k;A[1]+=.18*pain*k;A[0]+=Math.max(0,70-e.blood)/70*.45;
      // Writhing: down and in a lot of pain, it draws its legs up and lets them go, rocks, and now and then spasms. Calms as the pain ebbs.
      if((down||rung==='curl')&&pain>.55){const w=(pain-.4)*k,t=this.time,draw=.5+.5*Math.sin(t*1.7),curl=POSES.curl;for(const slot of [11,12,14,15]){const leg=slot<14?0:1.3;A[slot]=curl[slot][0]*(.35+.65*(.5+.5*Math.sin(t*1.7+leg)));P[slot]=1.2;}
        A[3]+=Math.sin(t*1.1)*.3*w;A[4]+=Math.sin(t*.9+1)*.25*w;A[5]+=Math.sin(t*2.3)*.6*w;A[8]-=Math.sin(t*2.1+.7)*.6*w;if(random()<seconds*.7*w){e.flinch=FLINCH_TIME;e.flinchMag=.7;e.flinchSlot=2;}void draw;}
      // On fire: arms beat at the flames, and if it is on its feet it staggers about, away from the heat.
      if(e.burningParts>0){const t=this.time;A[5]=-1.2+Math.sin(t*17)*.9;A[6]=-1.0-Math.sin(t*19)*.8;A[8]=1.2-Math.sin(t*16+1)*.9;A[9]=1.0+Math.sin(t*18+2)*.8;P[5]=P[6]=P[8]=P[9]=5;want.armsFree=true;
        if(rung==='stand'&&!down&&!(e.stagN>0)){e.stagN=2;e.stagDir=e.panicDir=(random()<.2?-(e.panicDir||1):(e.panicDir||(random()<.5?-1:1)));e.stagT=0;e.stagLeg=e.stagDir>0?0:1;e.stagPush=STAGGER_MAX*1.4;}return;}
      // Guarding: a hurt arm is held in against the body; a badly hurt leg is kept off the floor if the other one can take the weight.
      const bodyAt=slot=>e.bodies.find(b=>b.plugin.slot===slot),hurt=(from,to)=>{let worst=1;for(let sl=from;sl<=to;sl++){const b=bodyAt(sl);if(b)worst=Math.min(worst,b.plugin.hp/b.plugin.maxHp);}return worst;};
      for(const [sh,side] of [[5,-1],[8,1]])if(hurt(sh,sh+2)*100<GUARD_HP&&rung!=='crawl'&&rung!=='drag'){A[sh]=side*.35*k;A[sh+1]=side*1.5;P[sh]=P[sh+1]=2.5;}
      if(e.spareLeg&&!down){A[e.spareLeg]+=-.4;A[e.spareLeg+1]+=1.1;P[e.spareLeg]=P[e.spareLeg+1]=1.6;}
      // Clutching: the nearest hand that still works goes to the wound that hurts most and stays there; both hands for the head and trunk. Not while the arms are needed to crawl or to break a fall.
      if(e.pain>CLUTCH_PAIN&&e.hurtScore>0&&rung!=='crawl'&&rung!=='drag'&&!(e.bracing>0)){const part=bodyAt(e.hurtSlot);if(part){const local=Vector.rotate({x:e.hurtX,y:e.hurtY},part.angle),tx=part.position.x+local.x,ty=part.position.y+local.y,both=e.hurtSlot<=4;let done=0;
        const arms=[[5,-1],[8,1]].map(([sh,side])=>{const upper=bodyAt(sh),fore=bodyAt(sh+1);if(!upper||!fore||this.fractured(upper)||this.fractured(fore)||(e.hurtSlot>=sh&&e.hurtSlot<=sh+2)||upper.plugin.hp<=0)return null;const sx=upper.position.x+Math.sin(upper.angle)*upper.plugin.h/2,sy=upper.position.y-Math.cos(upper.angle)*upper.plugin.h/2;return {sh,side,sx,sy,far:Math.hypot(tx-sx,ty-sy)};}).filter(Boolean).sort((a,b)=>a.far-b.far);
        for(const arm of arms){if(done&&!both)break;this.reach(want,chest,arm,tx,ty,flip,4.5);done++;}
        e.clutching=done;}else e.clutching=0;}else e.clutching=0;
    }
    // Two-link reach: the upper arm points short of the target by alpha and the elbow makes up the rest. The elbow only bends its own way, which picks the solution.
    reach(want,chest,arm,tx,ty,flip,power) {
      const d=clamp(Math.hypot(tx-arm.sx,ty-arm.sy),Math.abs(ARM_UPPER-ARM_FORE)+2,ARM_UPPER+ARM_FORE-2),bend=arm.side*flip,beta=bend*(Math.PI-Math.acos(clamp((ARM_UPPER**2+ARM_FORE**2-d*d)/(2*ARM_UPPER*ARM_FORE),-1,1)));
      const alpha=Math.atan2(ARM_FORE*Math.sin(beta),ARM_UPPER+ARM_FORE*Math.cos(beta)),aim=Math.atan2(-(tx-arm.sx),ty-arm.sy)-alpha,A=want.angle,P=want.power;
      A[arm.sh]=wrap(aim-chest.angle)*flip;A[arm.sh+1]=beta*flip;A[arm.sh+2]=0;P[arm.sh]=P[arm.sh+1]=power;want.armsFree=true;
    }
    // Awareness, ten times a second: what is the most pressing thing near this ragdoll? Something about to hit its head, heat close to it, something fast, a fire or blast, the thing that last hurt it.
    // The result is three numbers the pose reads: where to look, whether to guard, which way to shrink from heat. No pathfinding, no memory beyond a second or two.
    aware(e,chest,head,bodies) {
      e.lookX=null;e.heatDir=0;let best=0;const hx=head.position.x,hy=head.position.y,note=(score,x)=>{if(score>best){best=score;e.lookX=x;}};
      if(this.time-(e.hitTime??-9)<2.5)note(3,hx-(e.flinchDir||1)*200);                                    // whatever hit it came from the other way
      for(let i=0;i<bodies.length;i++){const b=bodies[i],p=b.plugin;if(p.entityId===e.id)continue;const dx=b.position.x-hx,dy=b.position.y-hy,far=Math.hypot(dx,dy);if(far>SEE_RANGE)continue;
        if(p.burning||p.heat>250){note(2+(SEE_RANGE-far)/SEE_RANGE,b.position.x);if(Math.abs(b.position.x-chest.position.x)<HEAT_NEAR+Math.max(p.w||0,p.r||0)/2&&b.position.y>hy-30&&b.position.y<chest.position.y+170)e.heatDir=Math.sign(chest.position.x-b.position.x)||1;} // close beside any part of it, from head to feet
        if(b.speed>SEE_FAST&&!p.part){note(2.5+b.speed/10,b.position.x);
          // on a course for the head within INCOMING seconds?
          const vx=b.velocity.x,vy=b.velocity.y,t=-(dx*vx+dy*vy)/(vx*vx+vy*vy);if(t>0&&t<INCOMING*60){const miss=Math.hypot(dx+vx*t,dy+vy*t);if(miss<38+Math.max(p.w||0,p.h||0,p.r||0)/2){e.guardT=.6;e.guardDir=Math.sign(-dx)||1;note(9,b.position.x);}}}
        if(this.drag?.bodyB===b&&(defs[p.kind]?.firearm||defs[p.kind]?.sharp)&&far<220)note(4,b.position.x);}       // a weapon held near it by the cursor
      for(const f of this.flashes)if(!f.grow&&Math.hypot(f.x-hx,f.y-hy)<SEE_RANGE*1.4)note(6,f.x);
      if(e.startleX!==undefined&&this.time-e.startleAt<1.5)note(3.5,e.startleX);
    }
    // Crawling: belly down, head the way it is going. Each good arm reaches past the head, plants, and pulls; the pull on the body is reacted on the planted hand,
    // which is pressed into the floor for grip, so it is all internal. It crawls away from what last hurt it for a few seconds, then lies still.
    crawl(e,want,chest,rung,seconds) {
      e.fleeT=Math.max(0,(e.fleeT||0)-seconds);const d=e.flinchDir||(chest.plugin.flip?-1:1);if(!(e.fleeT>0)){e.idle=true;want.power.fill(.12);return 0;}e.idle=false; // nothing to flee: it lies there slack, and the rest logic can let it sleep
      const A=want.angle,P=want.power,period=rung==='drag'?CRAWL_PERIOD*1.4:CRAWL_PERIOD,mass=this.carried(e,chest),weight=mass*.001*Math.max(this.gravity,.2)*e.effort;
      for(let k=0;k<2;k++){const upper=e.bodies.find(b=>b.plugin.slot===(k?8:5)),fore=upper&&e.bodies.find(b=>b.plugin.slot===(k?9:6));if(!upper||!fore||this.fractured(upper)||this.fractured(fore)||!this.joints.some(c=>c.plugin.joint&&c.bodyB===fore))continue;
        // Arm targets are world directions (forward-and-down to reach, back-and-down to finish the pull), turned into shoulder angles against the chest. The rig is a front view laid on its side,
        // so one arm is on the floor side and its shoulder limit stops it short of a full reach; it still paddles, and the far arm does the long strokes.
        const side=k?1:-1,phase=((this.time/period)+(k?.5:0))%1,sh=k?8:5,mirror=upper.plugin.flip?-1:1,shoulder=world=>wrap(world-chest.angle)*mirror;
        const hand=e.bodies.find(b=>b.plugin.slot===sh+2);
        if(phase<.45){A[sh]=shoulder(-d*1.15);A[sh+1]=side*.15;P[sh]=P[sh+1]=4;const tip=hand||fore;if(!tip.isStatic&&!chest.isStatic){tip.force.y-=CRAWL_LIFT*weight;chest.force.y+=CRAWL_LIFT*weight;}} // reach out past the head, hand lifted clear so it does not scrape the body backwards
        else{const pull=(phase-.45)/.55;A[sh]=shoulder(-d*1.15+d*1.9*pull);A[sh+1]=side*(.15+.6*pull);P[sh]=6;P[sh+1]=4;         // plant and drag the body up to the hand
          const grip=hand&&this.touching.has(hand)?hand:this.touching.has(fore)?fore:null;
          if(grip&&!grip.isStatic&&!chest.isStatic&&chest.velocity.x*d<CRAWL_SPEED){ /* no faster than a crawl, however light the body has become */ grip.force.y+=CRAWL_PRESS*weight;chest.force.y-=CRAWL_PRESS*weight;grip.force.x-=d*CRAWL_PULL*weight;chest.force.x+=d*CRAWL_PULL*weight;}}}
      return d;
    }
    // Standing is posture torques plus a leg push: the lift on the torso is reacted on the planted feet, so it is an internal force.
    // Feet that are not on something produce no lift, so a ragdoll can never fly or hover its way upright.
    balance(e,rung='stand'){
      const part=n=>e.bodies.filter(b=>b.plugin.part===n),chest=part('chest')[0],pelvis=part('pelvis')[0];if(!chest)return;
      const free=b=>!b.isStatic&&this.drag?.bodyB!==b,tilt=wrap(chest.angle),human=e.kind==='human',seconds=1/120;
      // Muscles need something to push against. Off the ground (carried, thrown, falling) the body only keeps a little tone, so it dangles from the hand that holds it;
      // after a moment in the air its strength is gone too, so it crumples on landing and then gets up.
      const supported=e.bodies.some(b=>this.touching.has(b)&&this.drag?.bodyB!==b);e.airTime=supported?0:(e.airTime||0)+seconds;if(e.airTime>AIR_LIMP)e.effort=0;const tone=supported?1:AIR_TONE;
      // What is holding the body up on this rung, how high it should hold the chest, and whether it is down and has to get up first.
      let support=this.support,height=0,uprightness=1,liftScale=1,base=POSES[rung]||POSES.stand;support.length=0;
      // A badly hurt leg is spared if the other can take the weight: it is drawn up, and its foot is not stood on.
      let legL=1,legR=1;for(const b of e.bodies){const sl=b.plugin.slot;if(sl>=11&&sl<=13)legL=Math.min(legL,b.plugin.hp/b.plugin.maxHp);else if(sl>=14)legR=Math.min(legR,b.plugin.hp/b.plugin.maxHp);}
      e.spareLeg=human&&this.settings.painReactions&&rung==='stand'&&!(e.stagN>0)?(legL*100<SPARE_LEG_HP&&legR>.7?11:legR*100<SPARE_LEG_HP&&legL>.7?14:0):0;
      if(rung==='stand'){for(const f of e.bodies)if(f.plugin.part==='foot'&&f.plugin.slot!==e.spareLeg+2&&this.touching.has(f)&&this.bears(f))support.push(f);height=STAND_HEIGHT;}
      else if(rung==='kneel'){for(const b of e.bodies)if((b.plugin.part==='shin'||b.plugin.part==='thigh')&&this.touching.has(b)&&!this.fractured(b))support.push(b);height=KNEEL_HEIGHT;}
      else{uprightness=0;liftScale=0;}
      const down=rung==='stand'&&(Math.abs(tilt)>.6||!support.length);
      // Getting up is staged: gather the limbs, push up on the arms, get the knees under, and only then stand. Pain and blood loss slow every stage.
      // If it is still down a while after the last stage, the attempt has failed: it sags, rests, and tries again.
      if(rung==='stand'){const slow=human?1+(e.pain||0)/70+Math.max(0,75-e.blood)/60:1;
        if(down&&!e.rise&&supported&&!(e.stagN>0))e.rise={stage:0,t:0,tries:(e.rise?.tries||0)};
        if(e.rise){e.rise.t+=seconds;if(e.rise.stage<GETUP_STAGES.length){const [name,time]=GETUP_STAGES[e.rise.stage];base=POSES[name];uprightness=e.rise.stage===0?0:e.rise.stage===1?.5*GETUP_TORQUE:GETUP_TORQUE;liftScale=e.rise.stage===2?1:0;height=STAND_HEIGHT*.62;
            if(e.rise.stage===2)for(const f of e.bodies)if((f.plugin.part==='shin'||f.plugin.part==='foot')&&this.touching.has(f)&&!support.includes(f))support.push(f);
            if(e.rise.t>time*slow){e.rise.stage++;e.rise.t=0;}}
          else{uprightness=down?GETUP_TORQUE:1;if(!down&&e.rise.t>.4)e.rise=null;else if(e.rise.t>1.6*slow){e.effort=0;e.stun=Math.max(e.stun||0,.8+(e.pain||0)/50);e.rise=null;}}}}
      else e.rise=null;
      // The pistol is levelled directly as well: a hand is far too light to hold a pistol's weight level by its own torque.
      const aiming=this.aimSet;aiming.clear();if(rung==='stand'&&!down)for(const hand of e.bodies){if(hand.plugin.part!=='hand')continue;const item=this.held(hand);if(!item||!defs[item.plugin.kind]?.firearm)continue;for(const b of e.bodies)if(b.plugin.slot>=hand.plugin.slot-2&&b.plugin.slot<=hand.plugin.slot)aiming.add(b);
        if(free(item))item.torque+=(clamp(wrap(-item.angle),-.6,.6)*AIM_STRENGTH*1.5-item.angularVelocity*.004)*item.inertia*e.effort;}
      // Which pose, and how strong the body is as a whole. Pain, blood loss and a dazed head all take strength away; so does being off the ground.
      const vigour=e.effort*tone*(human?clamp((e.blood-20)/45,.4,1)*(1-Math.min(.5,(e.pain||0)/200))*(e.consciousness==='dazed'?.85:1):1);
      const crawlDir=this.pose(e,base,aiming,chest,down,seconds,rung);
      // Joints: a PD muscle across each one, pulling the two parts toward the pose's relative angle. Equal and opposite, so muscles alone can never turn or move the body as a whole.
      const live=this.joints;for(let i=0;i<live.length;i++){const c=live[i];if(!c.plugin.joint||c.bodyA.plugin.entityId!==e.id)continue;const a=c.bodyA,b=c.bodyB,slot=b.plugin.slot;if(slot===undefined)continue;
        if(c.plugin.name==='ankle'&&this.touching.has(b)&&rung==='stand')continue; // a planted foot lies flat on the ground whatever the shin does; the ankle gives. Holding it to the shin makes the foot rock on its edge and walk.
        const arm=slot>=5&&slot<=10,limb=Math.min(this.strengthOf(a),this.strengthOf(b));let power=e.poseNow.power[slot]*limb*(arm&&this.poseWant.armsFree?vigour/tone:vigour)*(MUSCLE[c.plugin.name]||1);if(power<=0)continue;if(power>MUSCLE_MAX)power=MUSCLE_MAX; // arms need no ground to reach out; and no muscle, however it is driven, is stiffer than the step can integrate
        const target=e.poseNow.angle[slot]*(b.plugin.flip?-1:1),error=clamp(wrap(target-(b.angle-a.angle)),-MUSCLE_REACH,MUSCLE_REACH),ia=free(a)?a.inverseInertia:0,ib=free(b)?b.inverseInertia:0;if(!ia&&!ib)continue;
        // Damping grows with the root of the strength: scaled linearly, the strong leg joints end up over-damped for a 120 Hz explicit step and chatter.
        const torque=(MUSCLE_KP*error*power-MUSCLE_KD*(b.angularVelocity-a.angularVelocity)*Math.sqrt(power))/(ia+ib);if(ib)b.torque+=torque;if(ia)a.torque-=torque;}
      // Two parts answer to the world rather than to a parent: the chest holds itself upright (or, crawling, level with the ground), and planted feet hold themselves flat. Both push against the ground through the limbs.
      const lean=crawlDir?crawlDir*1.35:0;if(free(chest)&&(uprightness>0||crawlDir))chest.torque+=(clamp(wrap(lean-chest.angle),-.5,.5)*.0011*(crawlDir?1.5:uprightness)-chest.angularVelocity*.0022)*chest.inertia*vigour;
      if(rung==='stand')for(const f of support)if(f.plugin.part==='foot'&&free(f))f.torque+=(clamp(wrap(-f.angle),-.5,.5)*.0024-f.angularVelocity*.003)*f.inertia*vigour;
      // Only what is really braced against something may take the body's weight. A light shin that is merely brushing the floor would be shot downward by it; a part already moving down is not holding anything up.
      for(let i=support.length-1;i>=0;i--)if(support[i].velocity.y>BRACED||support[i].speed>BRACED*3)support.splice(i,1);
      if(!support.length||!pelvis||!free(chest)||!liftScale)return;
      // The leg push: lift on the torso, reacted on whatever is planted, so it is an internal force. Nothing planted, no lift: a ragdoll can never fly or hover its way upright.
      // A hurt leg takes less of the load, so the body shifts over the good one: that is a limp. Shares are by the health of each supporting leg, from its foot up to the hip.
      let mass=this.carried(e,chest),footX=0,footY=-1e9,total=0;const shares=this.shares;shares.length=support.length;
      for(let i=0;i<support.length;i++){const f=support[i],slot=f.plugin.slot,from=slot>=14?14:11;let health=1;for(const b of e.bodies)if(b.plugin.slot>=from&&b.plugin.slot<=from+2)health=Math.min(health,b.plugin.hp/b.plugin.maxHp);shares[i]=clamp(health*health,.12,1);total+=shares[i];}
      for(let i=0;i<support.length;i++){shares[i]/=total;footX+=support[i].position.x*shares[i];footY=Math.max(footY,support[i].bounds.max.y-6);if(support[i].plugin.slot===13||support[i].plugin.slot===11||support[i].plugin.slot===12)e.loadLeft=shares[i];}if(support.length===1)e.loadLeft=support[0].plugin.slot<14?1:0;
      const weight=mass*.001*Math.max(this.gravity,.2),lift=clamp((height-(footY-chest.position.y))*.035+chest.velocity.y*.25,0,this.settings.legStrength*(e.surge>0?1.5:1))*weight*e.effort*liftScale;
      const daze=e.consciousness==='dazed'?Math.sin(this.time*1.3)*9+Math.sin(this.time*.7+1)*6:0; // dazed: the point it balances over wanders
      const sway=clamp((footX+daze+(e.leanAway||0)+(e.stagN>0?e.stagDir*e.stagPush:0)-chest.position.x)*.012-chest.velocity.x*.12,-.8,.8)*weight*e.effort; // a stagger moves the point the body balances over
      chest.force.x+=sway*.6;chest.force.y-=lift*.6;if(free(pelvis)){pelvis.force.x+=sway*.4;pelvis.force.y-=lift*.4;}
      for(let i=0;i<support.length;i++){const f=support[i];if(free(f)){f.force.x-=sway*this.shares[i];f.force.y+=lift*this.shares[i];}}
    }
    bodyAt(point){return Query.point(this.bodies,point).reverse()[0]||null;}
    removeBody(body) {
      if(!body||body.plugin.boundary)return;
      for(const c of this.joints)if(c.bodyA===body||c.bodyB===body)Composite.remove(this.world,c);
      if(this.drag?.bodyB===body)this.endDrag();
      Composite.remove(this.world,body);
      for(const e of this.entities){if(e.bodies.includes(body))e.restTime=0;e.bodies=e.bodies.filter(b=>b!==body);e.joints=e.joints.filter(c=>c.bodyA!==body&&c.bodyB!==body);}
      this.entities=this.entities.filter(e=>e.bodies.length);
    }
    removeEntity(body){const e=this.getEntity(body);if(e)for(const b of [...e.bodies])this.removeBody(b);}
    clear(){this.endDrag();for(const b of [...this.bodies])this.removeBody(b);for(const c of this.joints)Composite.remove(this.world,c);this.entities=[];this.particles=[];this.flashes=[];this.traces=[];this.stains=[];this.damageQueue=[];this.regrowing=[];Engine.clear(this.engine);}
    freeze(body){if(!body)return;Body.setStatic(body,!body.isStatic);return body.isStatic;}
    beginDrag(body,point) {
      this.endDrag();if(!body)return;if(body.plugin.heldBy!==undefined)this.release(body); // grabbing a held thing takes it out of the hand
      this.drag=Constraint.create({pointA:{...point},bodyB:body,pointB:Vector.sub(point,body.position),length:0,stiffness:this.settings.grabStrength,damping:.15});
      this.drag.plugin={drag:true};Composite.add(this.world,this.drag);
    }
    moveDrag(point){if(this.drag)this.drag.pointA={...point};}
    translateConnected(body,delta){
      const connected=new Set([body]),queue=[body],joints=this.joints.filter(c=>c.plugin.joint||c.plugin.pierce||c.plugin.hold);
      while(queue.length){const current=queue.shift();for(const c of joints){const other=c.bodyA===current?c.bodyB:c.bodyB===current?c.bodyA:null;if(other&&!connected.has(other)){connected.add(other);queue.push(other);}}}
      for(const b of connected)Body.translate(b,delta);
    }
    endDrag(){if(this.drag){if(this.dragAngle!=null&&!this.drag.bodyB.isStatic)Body.setAngularVelocity(this.drag.bodyB,0);Composite.remove(this.world,this.drag);}this.drag=null;this.dragAngle=null;} // let go without spin, so it leaves the hand at the chosen angle
    // Rotating a held body sets a target angle that the grab keeps steering to, so it stays put when the key is released.
    rotate(body,amount,immediate=false){
      if(!body)return;const held=this.drag?.bodyB===body;
      if(immediate||body.isStatic||!held){Body.rotate(body,amount);Body.setAngularVelocity(body,0);if(held)this.dragAngle=body.angle;}
      else this.dragAngle=(this.dragAngle??body.angle)+amount;
    }
    rope(a,b,pa,pb) {
      if(a===b&&a)return null;
      const c=Constraint.create({bodyA:a||undefined,bodyB:b||undefined,pointA:a?Vector.sub(pa,a.position):{...pa},pointB:b?Vector.sub(pb,b.position):{...pb},stiffness:.8,damping:.06});
      c.plugin={rope:true};Composite.add(this.world,c);return c;
    }
    // Blood thrown by a blow. With a direction it is a cone: forward says how much of it carries on with the blow (negative = back-spatter toward the attacker,
    // which is what an entry wound does; an exit wound throws it all forward). Without a direction it is the old radial burst.
    spray(point,direction,count,speed,forward) {
      if(!direction||(!direction.x&&!direction.y)){this.burst(point.x,point.y,count,'#a4373c',speed,'blood');return;}
      const d=Vector.normalise(direction);count=Math.round(count*Math.max(1,this.settings.bloodAmount));
      for(let i=0;i<count;i++){const along=(random()<Math.abs(forward)?Math.sign(forward):-Math.sign(forward)*.4)*rnd(.4,1)*speed,side=rnd(-.45,.45)*speed;this.emit(point.x,point.y,d.x*along-d.y*side,d.y*along+d.x*side-rnd(0,1),rnd(.3,1),1,'#a4373c',rnd(1,3.2),'blood');}
    }
    // Particles are recycled: dead ones go to a free list and come back, and the live array is compacted in place, so a long bleed allocates nothing.
    emit(x,y,vx,vy,life,maxLife,color,size,type) {
      if(type==='blood'||type==='oil'){if(this.settings.bloodAmount<1&&random()>this.settings.bloodAmount)return null;}
      const list=this.particles,p=list.length>=900?list.shift():(this.spare.pop()||{});p.x=x;p.y=y;p.vx=vx;p.vy=vy;p.life=life;p.maxLife=maxLife;p.color=color;p.size=size;p.type=type;p.owner=0;list.push(p);return p;
    }
    burst(x,y,count,color,speed=5,type='spark') {
      if(type==='blood')count=Math.round(count*Math.max(1,this.settings.bloodAmount));
      for(let i=0;i<count;i++)this.emit(x,y,rnd(-speed,speed),rnd(-speed,speed),rnd(.25,1),1,color,rnd(1,3.5),type);
    }
    sever(c) {
      if(!this.joints.includes(c))return;
      for(const [b,point] of [[c.bodyA,c.pointA],[c.bodyB,c.pointB]]){
        if(!b)continue;const p=b.plugin;const local=Vector.rotate(point,-b.angle);
        p.severed??=[];p.severed.push({x:p.flip?-local.x:local.x,y:local.y,bleed:p.material==='flesh'?1.8:0,fresh:1.6});this.bleedOf(p); // the stump's bone is not marked fractured: losing an arm must not break the chest it hung from
        if(p.material==='flesh')this.burst(b.position.x+point.x,b.position.y+point.y,16,'#a32e31',4,'blood');
      }
      Composite.remove(this.world,c);const owner=this.getEntity(c.bodyA||c.bodyB);if(owner)owner.restTime=0;
    }
    // direction (optional, world space) is where the blow was travelling; cuts and sprays follow it.
    damage(body,amount,point=body?.position,type='impact',direction=null) {
      if(!body||body.plugin.boundary||!Number.isFinite(amount)||amount<=0)return;
      const p=body.plugin,set=this.settings,gone=p.hp<=0,profile=PROFILES[type]||PROFILES.impact;if(p.part)amount*=set.fragility*(p.material==='flesh'&&p.heat<0?1+Math.min(2,-p.heat/50):1); // frozen flesh is brittle
      p.hp=Math.max(0,p.hp-amount);
      const e=this.getEntity(body),hurts=(STUN_PART[p.part]??1)*profile.stun,stun=e&&amount>KNOCKDOWN&&set.stunScale>0&&hurts?clamp(amount/20,.6,5)*set.stunScale*hurts:0;if(e)e.restTime=0;
      if(e&&e.alive&&p.part)this.react(e,body,amount,direction,stun);else if(e&&stun)e.stun=Math.max(e.stun||0,stun);
      if(e)e.hitTime=this.time;
      if(e&&e.kind==='human'&&e.alive){const hurt=amount*profile.pain*(PAIN_PART[p.part]??1)*set.painSensitivity;e.pain=Math.min(100,(e.pain||0)+hurt);
        // the wound that hurts most is the one the hands go to; an older one only keeps that place while it still hurts more
        if(p.slot!==undefined&&hurt>=(e.hurtScore||0)){const local=Vector.rotate(Vector.sub(point,body.position),-body.angle);e.hurtScore=hurt;e.hurtSlot=p.slot;e.hurtX=local.x;e.hurtY=local.y;}}
      if(e&&e.alive&&type==='shock')e.shockT=Math.max(e.shockT||0,SHOCK_LOCK);
      if(p.material==='flesh'){
        const local=Vector.rotate(Vector.sub(point,body.position),-body.angle),lx=p.flip?-local.x:local.x;
        p.bone=Math.max(0,(p.bone??100)-amount*profile.bone);
        // Bleeding belongs to the wound, not the limb. A burn seals what is there; a new blow next to an old wound opens it again.
        const artery=set.arterialSpurts&&ARTERIAL.has(p.part)&&(profile.deep||(type==='cut'&&amount>25)),rate=amount*profile.bleed*(artery?ARTERY_RATE:1);
        if(type==='burn')for(const w of [...(p.wounds||[]),...(p.severed||[])])w.bleed=Math.max(0,(w.bleed||0)-amount/40);
        else for(const w of p.wounds||[])if(Math.hypot(w.x-lx,w.y-local.y)<9)w.bleed=Math.min(4,(w.bleed||0)+rate*.3);
        if(profile.wound){const dir=direction?Math.atan2(direction.y,direction.x)-body.angle:random()*6.28;
          p.wounds??=[];p.wounds.push({x:clamp(lx,-p.w/2+1,p.w/2-1),y:clamp(local.y,-p.h/2+1,p.h/2-1),radius:clamp(amount/(profile.deep?13:type==='exit'?4:10),1.5,11),type,dir:p.flip?Math.PI-dir:dir,seed:random()*6.28,t:this.time,bleed:Math.min(4,rate),artery:artery||undefined});if(p.wounds.length>14)p.wounds.shift();
          if(type!=='burn')this.spray(point,direction,Math.min(24,Math.ceil(amount/3))*(type==='bullet'&&set.extraGunshot?3:1),type==='bullet'?6:3,type==='exit'?1:type==='bullet'?-.35:.6);}
        this.bleedOf(p);
        if(e&&e.kind==='human'&&e.alive){if(set.organDamage&&(profile.deep||(type==='impact'&&amount>20)))this.organHit(e,body,lx,local.y,amount*(profile.deep?1:.4),type);
          if(e.alive&&(p.part==='head'||p.part==='chest')&&p.hp<12)this.kill(e,`massive ${p.part} trauma`);}
      }
      else{this.burst(point.x,point.y,Math.min(8,Math.ceil(amount/8)),p.material==='glass'?'#a7dbe2':'#e1bc7b',3);if(p.part&&profile.deep)p.leak=Math.min(3,(p.leak||0)+amount/70);}
      if(p.hp<=0) {
        if(defs[p.kind]?.explosive?.onBreak){if(!p.detonating){p.detonating=true;this.damageQueue.push(()=>this.detonate(body));}}
        else if(p.material==='flesh'||p.kind==='android'){
          // A bullet can incapacitate without automatically detaching the whole limb.
          if(type==='blast'||amount>85*set.jointStrength||p.bone<=0)for(const c of [...this.joints])if(c.plugin.joint&&(c.bodyA===body||c.bodyB===body))this.sever(c);
          // Limb crushing: a limb that was already destroyed and takes another heavy blow is pulped.
          if(type==='blast'&&p.part&&!p.gibbed){p.gibbed=true;const at={...body.position},v={...body.velocity},m=p.material;this.damageQueue.push(()=>this.gibs(at.x,at.y,m,v,.6));}
          if(set.limbCrush&&gone&&p.part&&!p.crushing&&amount*set.crushSensitivity/100>40){p.crushing=true;this.damageQueue.push(()=>this.crush(body));}
        }
        else if(!p.debris&&!p.destroying&&!defs[p.kind]?.indestructible){p.destroying=true;this.damageQueue.push(()=>this.shatter(body));}
      }
    }
    // Blood that lands on a body stays where it landed, in that body's own frame, so it turns with it. Oldest goes first.
    stain(body,point,r,oil) {
      const p=body.plugin,local=Vector.rotate(Vector.sub(point,body.position),-body.angle);p.stains??=[];
      for(const st of p.stains)if(Math.hypot(st.x-local.x,st.y-local.y)<st.r+2){st.r=Math.min(3.6,Math.sqrt(st.r*st.r+r*r*.4));st.wet=1;return;} // landing on a stain makes it bigger and wet again
      p.stains.push({x:local.x,y:local.y,r,wet:1,oil:oil||undefined});if(p.stains.length>BODY_STAINS)p.stains.shift();
    }
    addStain(st){const stains=this.stains;if(stains.length>=this.settings.maxStains)stains.shift();stains.push(st);return st;}
    // Blood that lands on the floor joins a pool if one is there. Pools grow by area, up to a limit, instead of stacking dots.
    pool(x,r,oil) {
      const stains=this.stains;for(let i=stains.length-1;i>=0;i--){const st=stains[i];if(st.wall||st.scorch||st.smear||st.print||!!st.oil!==!!oil||Math.abs(st.x-x)>st.r+4)continue;
        st.r=Math.min(POOL_MAX,Math.sqrt(st.r*st.r+r*r*.55));st.x+=(x-st.x)*.04;st.wet=1;st.age=0;return st;}
      return this.addStain({x,y:this.groundY-1,r,wet:1,age:0,oil:oil||undefined});
    }
    // Thirty times a second: blood dries, old stains fade out, the count is capped, and whatever drags through a wet pool smears it or tracks it away.
    stainsTick(dt,bodies) {
      const stains=this.stains,life=this.settings.stainLifetime;let keep=0;
      for(let i=0;i<stains.length;i++){const st=stains[i];if(st.wet>0)st.wet=Math.max(0,st.wet-dt/DRY_TIME);st.age=(st.age||0)+dt;if(!life||st.age<life)stains[keep++]=st;}stains.length=keep;
      // A pool that has spread over smaller floor stains swallows them.
      for(let i=0;i<stains.length;i++){const big=stains[i];if(big.r<10||big.wall||big.scorch||big.smear||big.print||big.gone)continue;for(let j=0;j<stains.length;j++){const st=stains[j];if(j===i||st.gone||st.wall||st.scorch||st.smear||st.print||st.r>=big.r||!!st.oil!==!!big.oil||Math.abs(st.x-big.x)>big.r-st.r*.5)continue;st.gone=true;big.wet=Math.max(big.wet,st.wet);}}
      keep=0;for(let i=0;i<stains.length;i++)if(!stains[i].gone)stains[keep++]=stains[i];stains.length=keep;
      const over=stains.length-this.settings.maxStains;if(over>0)stains.splice(0,over);
      for(const b of bodies){const p=b.plugin;if(p.stains)for(const st of p.stains)if(st.wet>0)st.wet=Math.max(0,st.wet-dt/DRY_TIME);
        if(b.bounds.max.y<this.groundY-2||b.isStatic)continue;const foot=p.part==='foot',x=b.position.x;
        let wetPool=null;for(let i=stains.length-1;i>=0&&!wetPool;i--){const st=stains[i];if(!st.wall&&!st.scorch&&!st.smear&&!st.print&&st.wet>.4&&st.r>7&&Math.abs(st.x-x)<st.r)wetPool=st;}
        if(wetPool){if(foot)p.wetFeet=4;if(Math.abs(b.velocity.x)>1.2&&this.settings.decals){const last=this.smears.get(b);if(last&&last.wet>.3&&Math.abs(last.x-x)<last.r+10){const from=Math.min(last.x-last.r,x-3),to=Math.max(last.x+last.r,x+3);last.x=(from+to)/2;last.r=Math.min(90,(to-from)/2);}
            else this.smears.set(b,this.addStain({x,y:this.groundY-1,r:5,wet:wetPool.wet*.8,age:0,smear:true,oil:wetPool.oil}));this.stain(b,{x,y:b.bounds.max.y-1},2.5,wetPool.oil);}}
        else if(foot&&p.wetFeet>0&&this.touching.has(b)&&Math.abs(x-(p.printX??-1e9))>16&&this.settings.decals){p.printX=x;this.addStain({x,y:this.groundY-1,r:6,wet:.5*p.wetFeet/4,age:0,print:true});p.wetFeet--;}
      }
    }
    // A part's bleeding is the sum of its wounds and stumps.
    bleedOf(p){let sum=0;for(const w of p.wounds||[])sum+=w.bleed||0;for(const w of p.severed||[])sum+=w.bleed||0;return p.bleed=Math.min(7,sum);}
    kill(e,cause){if(!e.alive)return;e.alive=false;e.upright=false;e.causeOfDeath=cause;e.consciousness='dead';e.restTime=0;e.deadFor=0;e.twitchAt=e.kind==='human'&&!/destroyed/.test(cause)?[rnd(.4,1.4),random()<.6?rnd(1.8,TWITCH_WINDOW):99]:[];}
    // Where on the part the blow landed decides whether it found an organ. Blunt force only reaches the brain (concussion).
    organHit(e,body,lx,ly,amount,type) {
      const p=body.plugin,zones=ORGANS[p.part];if(!zones)return;const fx=lx/(p.w/2),fy=ly/(p.h/2),zone=zones.find(([organ,x0,y0,x1,y1])=>fx>=x0&&fx<=x1&&fy>=y0&&fy<=y1&&(type!=='impact'||organ==='brain'));if(!zone)return;
      const [organ,,,,,scale]=zone;e.organs??={brain:100,heart:100,lungs:100,gut:100};e.organs[organ]=Math.max(0,e.organs[organ]-amount*scale);
      if(organ==='brain'){if(e.organs.brain<=0)this.kill(e,'brain destroyed');else e.stun=Math.max(e.stun||0,(100-e.organs.brain)/12);} // a long blackout
      else if(organ==='heart'){p.internal=(p.internal||0)+amount/18;if(e.organs.heart<=0)this.kill(e,'heart destroyed');}               // massive internal bleed
      else if(organ==='gut')p.internal=(p.internal||0)+amount/80;                                                                          // slow internal bleed
      // lungs: no immediate effect; vitals() runs the oxygen down while they are damaged
    }
    // Gibs: small physical chunks of what used to be a limb, and half as many bone fragments. They trail blood for a moment, and do not last.
    gibs(x,y,material,velocity,scale=1) {
      const set=this.settings,count=Math.round(set.gibCount*scale);if(!set.fragments||!count||this.bodies.length>set.maxObjects-12)return;
      const old=this.bodies.filter(b=>b.plugin.gib);for(const b of old.slice(0,Math.max(0,old.length+count*1.5-GIB_MAX)))this.removeBody(b);
      const bits=[],total=count+(material==='flesh'?Math.ceil(count/2):0);for(let i=0;i<total;i++){const bone=i>=count,w=bone?rnd(3,6):rnd(4,9),h=bone?rnd(2,3):rnd(4,8),b=Bodies.rectangle(x+rnd(-8,8),y+rnd(-8,8),w,h,{density:bone?.002:.0015,friction:.8,restitution:.15,frictionAir:.01*set.airDrag});
        this.meta(b,'gib',{material:bone?'bone':material,w,h,hp:10,maxHp:10,debris:true,gib:true,life:GIB_LIFE*rnd(.7,1.2),trail:material==='flesh'&&!bone?rnd(.8,1.8):0,seed:random()*100});
        Body.setVelocity(b,{x:velocity.x*.5+rnd(-5,5),y:velocity.y*.5+rnd(-7,-1)});Body.setAngularVelocity(b,rnd(-.4,.4));bits.push(b);}
      this.entity('debris',bits);
    }
    crush(body) {
      if(!this.bodies.includes(body))return;const p=body.plugin,{x,y}=body.position,e=this.getEntity(body),flesh=p.material==='flesh';
      this.burst(x,y,flesh?45:20,flesh?'#8d2a31':'#e1bc7b',7,flesh?'blood':'spark');if(flesh)this.burst(x,y,14,'#7a2a30',3,'smoke');
      if(e&&(p.part==='head'||p.part==='chest'))this.kill(e,`${p.part} destroyed`);this.removeBody(body);
      this.gibs(x,y,flesh?'flesh':p.material,body.velocity,1);
      this.onEffect('break',.4);
    }
    shatter(body) {
      if(!this.bodies.includes(body))return;
      const p=body.plugin,{x,y}=body.position,vel={...body.velocity};this.removeBody(body);
      if(this.bodies.length>this.settings.maxObjects-20)return;
      const fragments=[];for(let i=0;i<5;i++){
        const w=rnd(6,16),h=rnd(5,14),b=Bodies.rectangle(x+rnd(-15,15),y+rnd(-15,15),w,h,{density:.001,friction:.6});
        this.meta(b,p.kind,{material:p.material,w,h,hp:10,maxHp:10,debris:true,char:p.char});Body.setVelocity(b,{x:vel.x+rnd(-3,3),y:vel.y+rnd(-4,1)});Body.setAngularVelocity(b,rnd(-.15,.15));fragments.push(b);
      }this.entity('debris',fragments);this.onEffect('break',.3);
    }
    explode(x,y,radius=175,power=1) {
      power*=this.settings.explosionPower;
      this.flashes.push({x,y,radius,life:.6,maxLife:.6});this.burst(x,y,70,'#eabb69',13*power);this.burst(x,y,30,'#cd7050',9*power,'smoke');
      for(const b of this.bodies){const dx=b.position.x-x,dy=b.position.y-y,d=Math.hypot(dx,dy);if(d>radius)continue;const f=1-d/radius;
        if(!b.isStatic){Body.setVelocity(b,{x:b.velocity.x+(dx/(d||1))*f*20*power,y:b.velocity.y+(dy/(d||1))*f*20*power-3*f});Body.setAngularVelocity(b,rnd(-.2,.2)*f);}
        this.damage(b,f*f*170*power,b.position,'blast',{x:dx,y:dy});b.plugin.heat+=f*180;
      }this.onEffect('explosion',power);
    }
    detonate(body){if(!this.bodies.includes(body))return;const {x,y}=body.position,ex=defs[body.plugin.kind]?.explosive||{radius:170,power:1};this.removeBody(body);this.explode(x,y,ex.radius,ex.power);}
    // Bullets are rays. Each body the ray crosses is hit in order; whether the bullet stops there depends on what it is made of and the state it is in.
    // Flesh stops a first bullet. A limb that is already perforated or destroyed no longer does: the next bullet goes in one side and out the other
    // (entry and exit wound) and carries on, weaker, into whatever is behind it.
    passes(body,damage){const p=body.plugin,mat=matOf(p);if(p.boundary||body.isStatic||mat.absorb>=1)return false;if(mat.brittle)return true;if(p.material!=='flesh')return p.hp-damage<=p.maxHp*.3; // brittle things never stop a bullet; wood, plastic and rubber do until they are nearly destroyed
      return p.hp<=0||damage>=90||(p.wounds||[]).some(w=>w.type==='bullet'||w.type==='exit');} // flesh: already holed, already destroyed, or a round too powerful to stop
    shoot(from,to,ignore=null) {
      const direction=Vector.normalise(Vector.sub(to,from));if(!direction.x&&!direction.y)return;
      const end=Vector.add(from,Vector.mult(direction,2500)),rx=end.x-from.x,ry=end.y-from.y,hits=[];
      // Exact segment/polygon intersection avoids tunnelling and query-order artifacts. Entry and exit are the nearest and farthest crossing of each body.
      for(const body of [...this.bodies,...this.boundaries]){if(body===ignore||(ignore?.plugin.heldBy!==undefined&&body.collisionFilter.group===ignore.collisionFilter.group))continue; // a held pistol never shoots its own holder
        let near=Infinity,far=-Infinity;const v=body.vertices;for(let i=0;i<v.length;i++){const a=v[i],b=v[(i+1)%v.length],sx=b.x-a.x,sy=b.y-a.y,den=rx*sy-ry*sx;
          if(Math.abs(den)<1e-8)continue;const qx=a.x-from.x,qy=a.y-from.y,t=(qx*sy-qy*sx)/den,u=(qx*ry-qy*rx)/den;if(t>=0&&t<=1&&u>=0&&u<=1){near=Math.min(near,t);far=Math.max(far,t);}}
        if(near<Infinity)hits.push({body,near,far});}
      hits.sort((a,b)=>a.near-b.near);const at=t=>({x:from.x+rx*t,y:from.y+ry*t});let first=null,stop=end,power=1;
      for(const {body,near,far} of hits){first??=body;stop=at(near);if(body.plugin.boundary)break;
        const damage=this.settings.bulletDamage*power,through=this.passes(body,damage)&&far>near;
        Body.applyForce(body,stop,Vector.mult(direction,.018*this.settings.bulletForce*power*(through?.4:1)));
        const absorb=matOf(body.plugin).absorb;this.damage(body,damage*(through?.6:1),stop,'bullet',direction);if(!through)break;
        // Out the far side: a bigger, ragged wound and a spray that follows the bullet.
        const exit=at(far);if(body.plugin.material==='flesh'&&this.bodies.includes(body)){this.damage(body,damage*.25,exit,'exit',direction);for(let i=0;i<8;i++)this.emit(exit.x,exit.y,direction.x*rnd(2,7)+rnd(-1,1),direction.y*rnd(2,7)+rnd(-1.5,.5),rnd(.4,1),1,'#a4373c',rnd(1,3),'blood');}
        stop=exit;power*=1-absorb;if(power<.2)break;}
      this.traces.push({from:{...from},to:stop,life:.14,maxLife:.14});this.burst(from.x,from.y,5,'#ffe1a2',3);
      this.onEffect('shot',.3);return first;
    }
    ignite(body){if(!body)return;body.plugin.heat=Math.max(body.plugin.heat,330);if(matOf(body.plugin).flammable>0)body.plugin.burning=true;if(defs[body.plugin.kind]?.explosive?.onHeat)body.plugin.fuse=.35;this.onEffect('fire',.1);}
    // A strike takes the highest thing under it. It is a massive shock: current jumps through conductors, flesh burns, flammables catch.
    lightning(x) {
      const under=this.bodies.filter(b=>b.bounds.min.x<=x&&b.bounds.max.x>=x).sort((a,b)=>a.bounds.min.y-b.bounds.min.y)[0],y=under?under.bounds.min.y:this.groundY,top=-370;
      this.traces.push({from:{x:x+rnd(-140,140),y:top},to:{x,y},life:.55,maxLife:.55,electric:true,bolt:true});this.flashes.push({x,y,radius:90,life:.35,maxLife:.35,sky:true});
      this.burst(x,y,26,'#dff3ff',9);this.burst(x,y,10,'#8f9aa0',3,'smoke');if(this.settings.decals&&!under)this.addStain({x,y:this.groundY-1,r:rnd(14,24),scorch:true,age:0});
      if(under){this.shock(under);this.damage(under,45,{x,y},'burn');under.plugin.heat+=520;if(!under.isStatic)Body.setVelocity(under,{x:under.velocity.x,y:under.velocity.y+3});}
      this.onEffect('thunder',1);return under||null;
    }
    shock(body) {
      if(!body)return;const touched=new Set(),queue=[body];
      while(queue.length&&touched.size<30){const b=queue.shift();if(touched.has(b))continue;touched.add(b);b.plugin.charge=1;this.damage(b,(b.plugin.material==='flesh'?24:5)*Math.pow(.8,touched.size-1),b.position,'shock');if(!b.isStatic)Body.setVelocity(b,{x:b.velocity.x+rnd(-2,2),y:b.velocity.y-2});
        for(const other of this.bodies)if(!touched.has(other)&&matOf(other.plugin).conductive>0&&Vector.magnitude(Vector.sub(other.position,b.position))<65){queue.push(other);this.traces.push({from:{...b.position},to:{...other.position},life:.3,maxLife:.3,electric:true});}
      }this.onEffect('electric',.3);
    }
    heal(body){const e=this.getEntity(body);if(e&&e.blood!==undefined){e.blood=100;e.pain=0;e.oxygen=100;delete e.organs;e.hurtScore=0;e.clutching=0;e.shockT=0;e.tremor=null;}for(const b of e?e.bodies:[body]){if(!b)continue;b.plugin.hp=b.plugin.maxHp;b.plugin.heat=this.settings.ambient;b.plugin.burning=false;b.plugin.char=0;b.plugin.charge=0;b.plugin.bleed=0;b.plugin.bone=100;b.plugin.wounds=[];b.plugin.internal=0;b.plugin.bruise=0;b.plugin.stains=[];b.plugin.leak=0;for(const w of b.plugin.severed||[])w.bleed=0;delete b.plugin.fuse;}this.burst(body.position.x,body.position.y,15,'#9fcbb1',2);}
    activate(body) {
      if(!body)return '';if(body.plugin.part==='hand'&&this.held(body))return this.activate(this.held(body));const p=body.plugin;
      const def=defs[p.kind]||{},name=def.name||'Object';
      if(def.explosive?.arm==='activate'){if(!def.explosive.fuse){this.detonate(body);return `${name} detonated`;}p.fuse=def.explosive.fuse;return `Fuse lit — ${def.explosive.fuse} seconds`;}
      if(def.firearm){const aim=body.angle+(p.flip?Math.PI:0),d={x:Math.cos(aim),y:Math.sin(aim)};this.shoot(Vector.add(body.position,Vector.mult(d,def.firearm.muzzle)),Vector.add(body.position,Vector.mult(d,800)),body);Body.applyForce(body,body.position,Vector.mult(d,-def.firearm.recoil));return `${name} fired`;}
      if(def.device){p.active=!p.active;return `${name} ${p.active?'on':'off'}`;}
      return 'This object has no activation';
    }
    // ponytail: a blade in a hand shares that body's collision group, which piercing also needs, so held blades slash and do not pierce. Per-pair filtering would lift this.
    // Blades: the tip is the -y end of a sharp body. A fast, point-first hit on flesh runs it through instead of bouncing off.
    blade(sword){const h=sword.plugin.h,axis=Vector.rotate({x:0,y:-1},sword.angle);return {axis,tip:Vector.add(sword.position,Vector.mult(axis,h/2)),length:h*.76};}
    pierce(pair,sword,part) {
      const p=sword.plugin;if(!defs[p.kind]?.sharp?.tip||p.stuck||p.heldBy!==undefined||part.plugin.material!=='flesh'||part.isStatic)return false;
      const {axis,tip}=this.blade(sword),contact=pair.collision.supports[0]||part.position;if(Vector.magnitude(Vector.sub(contact,tip))>26)return false;
      const arm=Vector.sub(tip,sword.position),tipVelocity={x:sword.velocity.x-sword.angularVelocity*arm.y,y:sword.velocity.y+sword.angularVelocity*arm.x};
      const speed=Vector.dot(Vector.sub(tipVelocity,part.velocity),axis);if(speed<this.settings.pierceSpeed)return false;
      // ponytail: the blade joins the victim's no-collide group, so one sword skewers one ragdoll at a time. Per-pair filtering if kebabs matter.
      pair.isSensor=true;p.stuck=part.plugin.entityId;p.bloody=true;sword.collisionFilter.group=part.collisionFilter.group;
      this.piercing.set(sword,{part,steps:40});
      this.damage(part,clamp(20+speed*3,25,70),contact,'stab',axis);this.onEffect('impact',.4);return true;
    }
    // The blade slides for a few steps, then the flesh grips it: two pins along the blade act as a weld. Pulled hard enough, it comes out and the wound opens up.
    blades(){
      for(const [sword,slide] of this.piercing){if(!this.bodies.includes(sword)||!this.bodies.includes(slide.part)){this.piercing.delete(sword);continue;}
        // Flesh drags on the blade: each step the two trade momentum until they move together, or the guard reaches the body.
        const {axis,tip,length}=this.blade(sword),part=slide.part,ms=sword.mass,mp=part.mass,rel=Vector.sub(sword.velocity,part.velocity),ax=Vector.dot(rel,axis),depth=Vector.dot(Vector.sub(tip,part.position),axis);
        const lodged=ax<1.2||depth>length*.45||--slide.steps<=0,keep=lodged?{x:0,y:0}:Vector.add(Vector.mult(axis,ax*.78),Vector.mult(Vector.sub(rel,Vector.mult(axis,ax)),.5)),change=Vector.sub(keep,rel);
        Body.setVelocity(sword,Vector.add(sword.velocity,Vector.mult(change,mp/(ms+mp))));Body.setVelocity(part,Vector.sub(part.velocity,Vector.mult(change,ms/(ms+mp))));
        Body.setAngularVelocity(sword,lodged?part.angularVelocity:(sword.angularVelocity+part.angularVelocity)/2);
        if(!lodged)continue;this.piercing.delete(sword);
        const along=clamp(Vector.dot(Vector.sub(part.position,tip),Vector.neg(axis)),4,length-16);
        for(const offset of [0,14]){const point=Vector.add(tip,Vector.mult(axis,-(along+offset)));const c=Constraint.create({bodyA:part,bodyB:sword,pointA:Vector.sub(point,part.position),pointB:Vector.sub(point,sword.position),length:0,stiffness:.3,damping:.1});c.plugin={pierce:true};Composite.add(this.world,c);}
        // Anything else of the same body that the blade now passes through is wounded too, including the far side.
        const e=this.getEntity(part);for(let d=2;d<length;d+=10){const point=Vector.add(tip,Vector.mult(axis,-d)),other=e&&Query.point(e.bodies,point)[0];if(other&&other!==part&&!other.plugin.run){other.plugin.run=true;this.damage(other,22,point,'stab');}}
        if(e)for(const b of e.bodies)delete b.plugin.run;if(along>part.plugin.w)this.damage(part,12,tip,'stab');
      }
      for(const sword of this.bodies){const p=sword.plugin;if(p.stuck===undefined||this.piercing.has(sword))continue;
        const pins=this.joints.filter(c=>c.plugin.pierce&&c.bodyB===sword);
        // Matter's pins barely stretch, so a hand pull is measured on the grab itself: how far the cursor has drawn away from the hilt.
        const pulled=this.drag?.bodyB===sword&&Constraint.currentLength(this.drag)>this.settings.bladeGrip*4;
        // A blade in the body hurts all the time, and much more when someone moves it.
        if(pins.length){const host=this.getEntity(pins[0].bodyA);if(host&&host.kind==='human'&&host.alive){const moved=this.drag?.bodyB===sword;host.pain=Math.min(100,(host.pain||0)+(moved?14:1.6)/120*this.settings.painSensitivity);if(moved&&!(host.flinch>0)){host.flinch=FLINCH_TIME;host.flinchMag=.5;host.flinchSlot=pins[0].bodyA.plugin.slot;host.flinchDir=host.flinchDir||1;}}}
        if(pins.length&&!pulled&&pins.every(c=>Constraint.currentLength(c)<this.settings.bladeGrip))continue;
        for(const c of pins){Composite.remove(this.world,c);{const host=c.bodyA.plugin,stab=(host.wounds||[]).filter(w=>w.type==='stab').pop();if(stab)stab.bleed=Math.min(4,(stab.bleed||0)+.8);this.bleedOf(host);}const owner=this.getEntity(c.bodyA);if(owner)owner.restTime=0;}
        // Collisions come back only once the blade is clear, otherwise the solver would fire it out of the body.
        const e=this.entities.find(e=>e.id===p.stuck);if(!e||!e.bodies.some(b=>M.Bounds.overlaps(b.bounds,sword.bounds))){sword.collisionFilter.group=0;delete p.stuck;}
      }
    }
    disturb(pairs){for(const {bodyA:a,bodyB:b} of pairs)for(const [target,other] of [[a,b],[b,a]]){this.touching.add(target);if(other.isStatic||other.speed<.15)continue;const e=this.getEntity(target);if(e?.restTime&&e!==this.getEntity(other))e.restTime=0;}}
    collisions(pairs){this.disturb(pairs);for(const pair of pairs){const {bodyA:a,bodyB:b}=pair;if(this.pierce(pair,a,b)||this.pierce(pair,b,a))continue;const speed=Vector.magnitude(Vector.sub(a.velocity,b.velocity));
      if(speed>7){for(const [target,other] of [[a,b],[b,a]]){if(target.plugin.boundary)continue;const multiplier=matOf(target.plugin).brittle?3:1;const point=Vector.mult(Vector.add(target.position,other.position),.5);const blade=!!defs[other.plugin.kind]?.sharp?.edge;this.damage(target,blade?Math.min(60,(speed-7)*4.5):(speed-7)*multiplier*1.5,point,blade?'cut':'impact',other.plugin.boundary?Vector.neg(target.velocity):Vector.sub(other.velocity,target.velocity));}}
      if(speed>3)this.onEffect('impact',Math.min(.5,speed/30));
      if(a.plugin.burning&&!b.plugin.boundary)b.plugin.heat+=30;if(b.plugin.burning&&!a.plugin.boundary)a.plugin.heat+=30;
    }}
    step(dt=1000/60) {
      if(dt>1000/120+.001){this.step(dt/2);this.step(dt/2);return;}
      const seconds=dt/1000;this.time+=seconds;random=this.random;this.engine.gravity.y=this.gravity;
      const bodies=this.bodies;this.bodiesNow=bodies;if(random()<seconds*this.settings.lightning/100*.45)this.lightning(rnd(80,this.width-80));
      for(const e of this.entities){if(!['human','android'].includes(e.kind))continue;
        if(e.alive)this.vitals(e,seconds);else if(e.twitchAt?.length)this.twitch(e,seconds);
        e.shoutT=Math.max(0,(e.shoutT||0)-seconds);e.stun=Math.max(0,(e.stun||0)-seconds);e.surge=Math.max(0,(e.surge||0)-seconds);if(e.stunIn>0){e.stunIn-=seconds;if(e.stunIn<=0){e.stun=Math.max(e.stun,e.stunNext||0);e.stunNext=0;}}const locked=e.alive&&e.shockT>0&&this.settings.autoBalance; // current locks the muscles whether or not anyone is awake to use them
        if(!this.active(e)&&!locked){e.effort=0;e.rung='limp';e.rise=null;continue;}if(locked)e.effort=1;
        e.effort=Math.min(e.consciousness==='dazed'?.85:1,(e.effort??1)+seconds/this.settings.getUpTime*(1-Math.min(.7,(e.pain||0)/140))); // strength returns gradually, slower in pain, and never fully while dazed
        this.balance(e,e.rung=this.capability(e));
      }
      for(const b of bodies){const p=b.plugin;
        if(!Number.isFinite(b.position.x)||!Number.isFinite(b.position.y)||Math.abs(b.position.x)>10000||Math.abs(b.position.y)>10000){this.removeBody(b);continue;}
        if(p.fuse!==undefined){p.fuse-=seconds;if(p.fuse<=0&&!p.detonating){p.detonating=true;this.damageQueue.push(()=>this.detonate(b));}}
        // A sanity limit, not a behaviour: if solver and muscles ever gang up on a limb, it is slowed rather than fired across the room. Far above anything a throw, a blast or a fall produces.
        if(p.part&&!b.isStatic){if(b.speed>LIMB_SPEED)Body.setVelocity(b,Vector.mult(b.velocity,LIMB_SPEED/b.speed));if(b.angularSpeed>LIMB_SPIN)Body.setAngularVelocity(b,Math.sign(b.angularVelocity)*LIMB_SPIN);}
        if(p.gib){p.life-=seconds;if(p.life<=0){this.damageQueue.push(()=>this.removeBody(b));continue;}if(p.trail>0){p.trail-=seconds;if(b.speed>1&&random()<seconds*40)this.emit(b.position.x,b.position.y,b.velocity.x*.3+rnd(-.4,.4),b.velocity.y*.3+rnd(-.4,.4),2,2,BLOOD,rnd(.7,1.7),'blood');}}
        p.charge=Math.max(0,p.charge-seconds*1.5);if(p.surge){p.surge-=seconds*.7;if(p.surge<=0)delete p.surge;}if(p.grow!==undefined){p.grow+=seconds/REGROW_SWELL;if(p.grow>=1){delete p.grow;delete p.growFrom;}}
        if(p.material==='flesh'&&(p.bleed>.02||p.wounds?.length||p.severed?.length)){
          // Wounds clot: quickly on a still limb, slowly on one that keeps moving. No allocation in here: it runs for every bleeding part, every substep.
          const e=this.getEntity(b),clot=seconds*CLOT*(b.speed<.6?1:.3),blood=e?.blood??100,pulse=e?.pulse||0,amount=Math.min(2,this.settings.bleedRate);let sum=0,drop=null;
          for(let pass=0;pass<2;pass++){const list=pass?p.severed:p.wounds;if(!list)continue;for(let i=0;i<list.length;i++){const w=list[i];if(!(w.bleed>0))continue;w.bleed=Math.max(0,w.bleed-clot*(pass?.5:1));if(w.fresh)w.fresh=Math.max(0,w.fresh-seconds);sum+=w.bleed;
            if(blood<=0)continue;const gush=(w.artery||w.fresh>0)&&pulse>.55,chance=w.bleed*seconds*(gush?26:w.artery?1.2:5)*amount;if(random()>=chance)continue;
            const wx=p.flip?-w.x:w.x,cos=Math.cos(b.angle),sin=Math.sin(b.angle),px=b.position.x+wx*cos-w.y*sin,py=b.position.y+wx*sin+w.y*cos;
            // A spurt leaves along the line from the limb's centre through the wound, weaker as the blood runs out; anything else just drips.
            if(gush){const len=Math.hypot(wx,w.y)||1,ox=(wx*cos-w.y*sin)/len,oy=(wx*sin+w.y*cos)/len,force=(2+2.4*pulse)*(.35+.65*blood/100);drop=this.emit(px,py,b.velocity.x*.4+ox*force+rnd(-.5,.5),b.velocity.y*.4+oy*force-1+rnd(-.5,.5),2.5,2.5,BLOOD,rnd(1.2,2.8),'blood');}
            else drop=this.emit(px,py,b.velocity.x*.4+rnd(-1.2,1.2),b.velocity.y*.4+rnd(-.7,.8),3,3,BLOOD,rnd(.8,2.6),'blood');if(drop)drop.owner=p.entityId;}}
          p.bleed=Math.min(7,sum);
        }
        // Androids do not bleed. A holed casing leaks coolant and throws the odd spark until it runs dry.
        if(p.leak>.02){p.leak=Math.max(0,p.leak-seconds*.03);if(random()<p.leak*seconds*4)this.emit(b.position.x+rnd(-3,3),b.position.y+rnd(-3,3),b.velocity.x*.4+rnd(-.8,.8),b.velocity.y*.4+rnd(-.3,.8),3,3,OIL,rnd(1,2.4),'oil');if(random()<p.leak*seconds*1.5)this.burst(b.position.x,b.position.y,3,'#ffe7a0',4);}
        // Blood on a surface runs: while it is wet, a stain lets go of the odd drop.
        if(p.stains?.length&&random()<seconds*.5){const st=p.stains[(random()*p.stains.length)|0];if(st.wet>.45){const cos=Math.cos(b.angle),sin=Math.sin(b.angle);this.emit(b.position.x+st.x*cos-st.y*sin,b.position.y+st.x*sin+st.y*cos,b.velocity.x*.3,b.velocity.y*.3+.4,2.5,2.5,st.oil?OIL:BLOOD,rnd(.7,1.6),st.oil?'oil':'blood');}}
        if(p.heat>matOf(p).burnAt)p.burning=true;
        if(p.burning){p.heat=Math.min(700,p.heat+seconds*35);p.hp=Math.max(0,p.hp-seconds*7);p.char=Math.min(1,(p.char||0)+seconds*.06);if(p.bleed){for(const w of [...(p.wounds||[]),...(p.severed||[])])w.bleed=Math.max(0,(w.bleed||0)-seconds*.5);}
          // Embers and smoke come off the top of the body, more of both the hotter it burns.
          const hot=clamp((p.heat-150)/400,.3,1.2),wide=b.bounds.max.x-b.bounds.min.x,top=b.bounds.min.y+(b.position.y-b.bounds.min.y)*.4;
          if(random()<seconds*9*hot)this.emit(b.position.x+rnd(-.5,.5)*wide,top,rnd(-.6,.6),rnd(-2.6,-1.2),rnd(.5,1.4),1.4,'#ffcf7a',rnd(.7,1.8),'ember');
          if(random()<seconds*5*hot*clamp(wide/50,.2,1))this.emit(b.position.x+rnd(-.4,.4)*wide,top-rnd(55,95),rnd(-.3,.3),rnd(-1.5,-.8),rnd(1.4,2.6),2.6,'#1c1d1f',rnd(6,12),'smoke'); // smoke leaves from above the flame tips, and small parts make little
          if(random()<.1){for(const other of bodies)if(other!==b&&Vector.magnitude(Vector.sub(other.position,b.position))<45)other.plugin.heat+=4;}
          if(p.hp<=0)this.damage(b,.1);
        }else p.heat+=clamp(this.settings.ambient-p.heat,-seconds*8,seconds*8);
        // ponytail: rain reaches everything, roofs do not shelter. Ray test upward if that matters.
        if(this.settings.rain&&p.heat>this.settings.ambient){p.heat-=seconds*(p.burning?140:25);if(p.burning&&p.heat<150)p.burning=false;}
        {const hot=defs[p.kind]?.explosive?.onHeat;if(hot&&p.heat>hot&&p.fuse===undefined)p.fuse=.5;}
        if(p.active&&!b.isStatic){const device=defs[p.kind]?.device;if(device==='thruster'){const force=Vector.rotate({x:0,y:-.0025*b.mass},b.angle);Body.applyForce(b,b.position,force);const jet=Vector.add(b.position,Vector.rotate({x:0,y:30},b.angle));this.burst(jet.x,jet.y,2,'#f3c885',2,'fire');}
          if(device==='wheel')Body.setAngularVelocity(b,.18);
        }
        if(p.active&&defs[p.kind]?.device==='battery'&&Math.floor(this.time*3)!==p.lastPulse){p.lastPulse=Math.floor(this.time*3);this.shock(b);}
      }
      if(this.drag&&this.dragAngle!=null&&!this.drag.bodyB.isStatic)Body.setAngularVelocity(this.drag.bodyB,clamp(wrap(this.dragAngle-this.drag.bodyB.angle)*.35,-.3,.3));
      // Limits are equal-and-opposite angular impulses: momentum-neutral, so a body pinned against the floor cannot walk itself sideways.
      for(const c of this.joints){if(!c.plugin.joint||c.plugin.min===undefined)continue;const a=c.bodyA,b=c.bodyB,slack=this.fractured(a)||this.fractured(b)?FRACTURE_SLACK:0,relative=wrap(b.angle-a.angle),error=relative-clamp(relative,c.plugin.min-slack,c.plugin.max+slack);if(Math.abs(error)<.005)continue;
        const ia=a.isStatic?0:a.inverseInertia,ib=b.isStatic?0:b.inverseInertia,total=ia+ib;if(!total)continue;
        const velocity=b.angularVelocity-a.angularVelocity,target=clamp(-error*LIMIT_GAIN,-LIMIT_SPEED,LIMIT_SPEED),impulse=target-velocity;
        if(Math.sign(impulse)===Math.sign(error))continue; // already returning faster than required
        if(ia)Body.setAngularVelocity(a,a.angularVelocity-impulse*ia/total);if(ib)Body.setAngularVelocity(b,b.angularVelocity+impulse*ib/total);
      }
      this.touching.clear();Engine.update(this.engine,dt);
      // Constraint solving leaves a limp pile jittering forever, and that residue crawls sideways; Matter's own sleeping never triggers on it.
      // So ragdolls sleep as a unit: fall at full speed, then once nearly still hold the whole pose. Holding every part adds no joint tension.
      for(const e of this.entities){if(e.blood===undefined)continue;
        const held=this.gravity<=0||(this.active(e)&&e.rung!=='curl'&&!e.idle)||e.bodies.includes(this.drag?.bodyB);
        const peak=Math.max(...e.bodies.map(b=>Math.max(b.speed,b.angularSpeed*Math.max(b.plugin.w,b.plugin.h)/2)))/REST_SPEED; // spin counts as tip speed, so a small hand flicking is small
        // A single twitch only drains the timer; real motion (or anything 3x over) clears it at once.
        e.restTime=held||peak>3?0:peak<1?(e.restTime||0)+seconds:Math.max(0,(e.restTime||0)-seconds*10);
        if(e.restTime<REST_DELAY){e.pin=null;continue;}
        const contacts=e.bodies.filter(b=>this.touching.has(b)).length;
        e.pin??={contacts,gravity:this.gravity,pose:e.bodies.map(b=>({b,x:b.position.x,y:b.position.y,angle:b.angle}))};
        // Wakes: support taken away, or gravity changed. Hits, shoves and drags clear restTime where they happen.
        if(contacts<e.pin.contacts*.6||this.gravity!==e.pin.gravity){e.restTime=0;e.pin=null;continue;}
        for(const {b,x,y,angle} of e.pin.pose){if(b.isStatic)continue;Body.setPosition(b,{x,y});Body.setAngle(b,angle);Body.setVelocity(b,{x:0,y:0});Body.setAngularVelocity(b,0);}
      }
      for(const c of [...this.joints])if(c.plugin.joint&&Constraint.currentLength(c)>c.plugin.breakForce*this.settings.jointStrength)this.sever(c);
      this.blades();this.hands();
      this.regrowing=this.regrowing.filter(job=>{job.wait-=seconds;if(job.wait>0)return true;job.wait=REGROW_BEAT;return this.growNext(job);});
      const pending=this.damageQueue.splice(0);for(const fn of pending)fn();
      // Particles move every substep, but what they land on is tested 30 times a second: bounds first, exact shape only on a hit.
      const land=(this.tick=(this.tick+1)%4)===0,decals=this.settings.decals,list=this.particles;let keep=0;
      for(let i=0;i<list.length;i++){const p=list[i];p.life-=seconds;p.x+=p.vx*seconds*60;p.y+=p.vy*seconds*60;const wet=p.type==='blood'||p.type==='oil';
        if(wet||p.type==='spark')p.vy+=seconds*12;
        else if(p.type==='ember'){p.vx+=Math.sin(this.time*9+p.y*.05)*seconds*5;p.vy-=seconds*.6;}else if(p.type==='smoke'){p.vx+=seconds*.35;p.vy*=1-seconds*.5;}
        if(wet&&p.life>0){if(p.y>=this.groundY){if(decals)this.pool(p.x,rnd(2,5),p.type==='oil');p.life=0;}
          else if(p.x<=2||p.x>=this.width-2){if(decals)this.addStain({x:p.x<=2?1:this.width-1,y:p.y,r:rnd(2,5),wet:1,age:0,wall:true,oil:p.type==='oil'||undefined});p.life=0;}
          else if(land&&p.life<p.maxLife-.08){for(let j=0;j<bodies.length;j++){const b=bodies[j],q=b.bounds;if(p.x<q.min.x||p.x>q.max.x||p.y<q.min.y||p.y>q.max.y||(p.owner===b.plugin.entityId&&p.life>p.maxLife-.45)||!M.Vertices.contains(b.vertices,p))continue;if(decals&&random()<.55)this.stain(b,p,rnd(.8,2),p.type==='oil');p.life=0;break;}}}
        if(p.life>0)list[keep++]=p;else if(this.spare.length<900)this.spare.push(p);}
      list.length=keep;
      if(land)this.stainsTick(seconds*4,bodies);
      for(const list of [this.flashes,this.traces]){for(const f of list)f.life-=seconds;while(list.length&&list[0].life<=0)list.shift();}
    }
    loadPreset(name) {
      this.clear();this.scene=name;
      if(name==='workshop'){
        this.spawn('human',900,555);this.spawn('android',1050,555);
        this.spawn('crate',1350,622);this.spawn('crate',1405,622);this.spawn('crate',1377,568);this.spawn('barrel',1530,619);
        this.spawn('ball',1150,627);this.spawn('metal',1180,433).bodies.forEach(b=>Body.setStatic(b,true));this.spawn('battery',1180,399);
        this.spawn('gun',790,637);this.spawn('bomb',1630,631);
      }else if(name==='tower'){
        for(let row=0;row<6;row++)for(let col=0;col<3;col++)this.spawn('crate',1195+col*54,622-row*54);
        this.spawn('barrel',1080,619);this.spawn('human',940,555);this.spawn('bomb',1390,631);
      }else if(name==='swing'){
        const beam=this.spawn('platform',1220,270).bodies[0];const ball=this.spawn('ball',1030,400).bodies[0];
        this.rope(beam,ball,{x:1220,y:270},{...ball.position});
        this.spawn('human',1340,555);this.spawn('glass',1410,598);this.spawn('crate',1470,623);
      }
    }
    serialize() {
      const bodies=this.bodies,index=new Map(bodies.map((b,i)=>[b,i]));
      return {version:1,scene:this.scene,gravity:this.gravity,entities:this.entities.map(e=>({id:e.id,kind:e.kind,upright:e.upright,blood:e.blood,alive:e.alive,stun:e.stun,pain:e.pain,oxygen:e.oxygen,breath:e.breath,hurtSlot:e.hurtSlot,hurtX:e.hurtX,hurtY:e.hurtY,hurtScore:e.hurtScore,deadFor:e.deadFor,twitchAt:e.twitchAt&&[...e.twitchAt],organs:e.organs&&{...e.organs},consciousness:e.consciousness,causeOfDeath:e.causeOfDeath,poseNow:e.poseNow&&{angle:[...e.poseNow.angle],power:[...e.poseNow.power]}})),bodies:bodies.map(b=>({x:b.position.x,y:b.position.y,angle:b.angle,velocity:{...b.velocity},angularVelocity:b.angularVelocity,isStatic:b.isStatic,density:b._original?.density||b.density,friction:b.friction,restitution:b.restitution,group:b.collisionFilter.group,plugin:{...b.plugin}})),joints:this.joints.map(c=>({a:c.bodyA?index.get(c.bodyA):null,b:c.bodyB?index.get(c.bodyB):null,pointA:{...c.pointA},pointB:{...c.pointB},length:c.length,stiffness:c.stiffness,damping:c.damping,plugin:{...c.plugin}})),stains:this.stains.map(s=>({...s}))};
    }
    restore(data) {
      if(!data||data.version!==1||!Array.isArray(data.bodies)||!Array.isArray(data.joints)||!Array.isArray(data.entities)||data.bodies.length>600)throw new Error('Invalid scene file');
      for(const b of data.bodies){const p=b.plugin;if(!p||![b.x,b.y,b.angle].every(Number.isFinite)||(!p.r&&(!Number.isFinite(p.w)||!Number.isFinite(p.h))))throw new Error('Invalid body');}
      for(const c of data.joints)if((c.a!==null&&!data.bodies[c.a])||(c.b!==null&&!data.bodies[c.b]))throw new Error('Invalid joint');
      this.clear();this.scene=data.scene||'empty';this.gravity=Number.isFinite(data.gravity)?data.gravity:1;this.settings.gravity=clamp(this.gravity*EARTH,-40,40);
      const bodies=data.bodies.map(d=>{const p=d.plugin,opts={density:d.density||.002,friction:d.friction,restitution:d.restitution,collisionFilter:{group:d.group||0}};
        const b=p.r?Bodies.circle(d.x,d.y,p.r,opts):Bodies.rectangle(d.x,d.y,p.w,p.h,{...opts,chamfer:{radius:Math.min(3,p.w/3,p.h/3)}});
        b.plugin={...p};Body.setAngle(b,d.angle);Body.setVelocity(b,d.velocity||{x:0,y:0});Body.setAngularVelocity(b,d.angularVelocity||0);if(d.isStatic)Body.setStatic(b,true);return b;
      });Composite.add(this.world,bodies);
      // Constraint.create discards a plugin passed in its options, so it is assigned afterwards.
      const joints=data.joints.map(d=>{const a=d.a===null?null:bodies[d.a],b=d.b===null?null:bodies[d.b];const c=Constraint.create({bodyA:a,bodyB:b,angleA:a?.angle||0,angleB:b?.angle||0,pointA:{...d.pointA},pointB:{...d.pointB},length:d.length,stiffness:d.stiffness,damping:d.damping});c.plugin={...d.plugin};return c;});Composite.add(this.world,joints);
      this.entities=data.entities.map(e=>({...e,bodies:bodies.filter(b=>b.plugin.entityId===e.id),joints:joints.filter(c=>c.plugin.joint&&c.bodyA?.plugin.entityId===e.id)}));
      for(const b of bodies)b.frictionAir=this.drag_(b); // bodies are rebuilt without their drag, so give it back
      this.nextId=Math.max(0,...this.entities.map(e=>e.id))+1;this.stains=Array.isArray(data.stains)?data.stains.filter(st=>st&&Number.isFinite(st.x)&&Number.isFinite(st.r)).slice(-600):[];
      // Keep new ragdolls' collision groups distinct from restored groups.
      Body._nextNonCollidingGroup=Math.min(Body._nextNonCollidingGroup,...bodies.map(b=>b.collisionFilter.group-1));
    }
  }
  return {Simulation,CATALOG,CATEGORIES,MATERIALS,SETTINGS,defaults,sanitize,defs,clamp,ANATOMY};
});
