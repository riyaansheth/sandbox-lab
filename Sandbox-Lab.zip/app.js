/* Sandbox Lab — canvas renderer and interaction layer. */
(() => {
  'use strict';
  const {Simulation,CATALOG,clamp}=Sandbox;
  const {Body,Constraint,Vector}=Matter;
  const $=s=>document.querySelector(s);
  const sim=window.__sim=new Simulation(),/* exposed for the console and for browser tests */canvas=$('#world'),ctx=canvas.getContext('2d'),stage=$('#stage');
  const camera={x:1220,y:400,zoom:1};
  const state={tool:'grab',spawn:null,selected:null,paused:false,speed:1,category:'all',sub:'all',pointer:{x:0,y:0},worldPointer:{x:0,y:0},inside:false,down:false,pan:null,ropeStart:null,ropeKind:'rope',shift:false,rotation:0,sound:false};
  const TOOLS=[
    {id:'grab',name:'Grab',symbol:'↖',key:'1',title:'Grab & move',desc:'Drag anything. See what happens.'},
    {id:'rope',name:'Rope',symbol:'⌁',key:'2',title:'Connect objects',desc:'Click two objects, or an object and empty space.'},
    {id:'freeze',name:'Lock',symbol:'⚲',key:'3',title:'Lock in place',desc:'Click a body to lock it in place. Click again to release.'},
    {id:'shoot',name:'Shoot',symbol:'⌖',key:'4',title:'Take your shot',desc:'Click or hold. Fires from close range, left to right, into whatever is under the cursor. Bullets wound; they never take a limb off.'},
    {id:'fire',name:'Fire',symbol:'♨',key:'5',title:'Turn up the heat',desc:'Hold and sweep. A flame at the cursor heats whatever is near it: a pass singes, holding it sets wood and flesh alight, metal only glows.'},
    {id:'water',name:'Water',symbol:'💧',key:'h',title:'Hose it down',desc:'Hold and sweep. Puts out anything burning, cools what is hot, and washes the blood off the floor, the walls, objects and bodies.'},
    {id:'cold',name:'Cold',symbol:'❄',key:'c',title:'Bring the temperature down',desc:'Hold and sweep. Draws the heat out of whatever is near: puts fires out, stiffens and then freezes flesh solid - and what is frozen shatters.'},
    {id:'shock',name:'Shock',symbol:'ϟ',key:'6',title:'A little electricity',desc:'Hold and sweep. Arcs jump from the cursor to the nearest conductors and spread from there.'},
    {id:'blast',name:'Blast',symbol:'✳',key:'7',title:'Make an impact',desc:'Click anywhere to create an explosion.'},
    {id:'heal',name:'Heal',symbol:'✚',key:'8',title:'Patch it up',desc:'Hold and sweep. Mends tissue and bone, closes wounds one by one, stops bleeding, puts out fire. It does not bring anyone back; broken joints stay broken. Option/Alt + click heals the whole ragdoll at once.'},
    {id:'revive',name:'Revive',symbol:'♥',key:'9',title:'Back on your feet',desc:'Click a dead or collapsed ragdoll to bring it back to life and standing.'},
    {id:'wake',name:'Wake up',symbol:'☀',key:'w',title:'Rise and shine',desc:'Click an unconscious or dazed ragdoll: it comes round at once and stays up for 30 s, whatever put it down.'},
    {id:'painless',name:'Painkiller',symbol:'℞',key:'p',title:'Feel nothing',desc:'Click a ragdoll to switch its pain off: wounds no longer slow it, shake it or knock it out. Click again to switch it back on.'},
    {id:'knockout',name:'Knock out',symbol:'☾',key:'o',title:'Lights out',desc:'Click a ragdoll to knock it out cold for 20 s (6 s with super endurance). Wake up brings it round early.'},
    {id:'partial',name:'Partial revive',symbol:'♡',key:'\\',title:'Alive, not mended',desc:'Click a dead ragdoll to bring it back as it is: every wound, fracture and missing limb stays.'},
    {id:'clot',name:'Stop bleeding',symbol:'◍',key:';',title:'Stem the flow',desc:'Click a ragdoll to stop all its bleeding, inside and out. The wounds stay.'},
    {id:'bandage',name:'Bandage',symbol:'▤',key:"'",title:'Dress the wound',desc:'Click a wounded part to bandage its cuts, bullet holes and stumps. Dressed wounds stop bleeding and stay shut.'},
    {id:'tourniquet',name:'Tourniquet',symbol:'⊘',key:'t',title:'Tie it off',desc:'Click an arm or a leg: everything below it stops bleeding. It goes numb in 20 s and dies after 2 minutes. Click again to take it off.'},
    {id:'stitch',name:'Stitch',symbol:'✂︎',key:'k',title:'Close the wound',desc:'Click a wound: it is stitched shut for good, and a round left in it is taken out. One wound per click.'},
    {id:'regrow',name:'Regrow',symbol:'❋',key:'-',title:'Grow it back',desc:'Click a ragdoll to regrow every missing limb. The torn-off pieces stay where they fell.'},
    {id:'reattach',name:'Reattach',symbol:'⚭',key:'=',title:'Put it back',desc:'Click a severed limb to return it to its own body, or click the body to collect all its pieces.'},
    {id:'graft',name:'Graft',symbol:'⚡',key:'[',title:'Build a better body',desc:'Click the body part to build on, then any loose limb — human or android, either side. It locks on with a surge of power.'},
    {id:'undress',name:'Undress',symbol:'👕',key:'u',title:'Take it off',desc:'Click a clothed part: that garment comes off the whole ragdoll and drops beside it as a fresh item. Hat before mask, top before trousers.'},
    {id:'dismember',name:'Dismember',symbol:'✂',key:']',title:'Take it off',desc:'Click a limb to cut it off at the joint nearest the body.'},
    {id:'delete',name:'Delete',symbol:'⌫',key:'0',title:'Clean up',desc:'Click an object to remove it and its connections.'}
  ];
  let width=0,height=0,dpr=1,toastTimer,lastShot=0,lastAction=0,lastTime=0,accumulator=0,frameCount=0,fpsTime=0,uiTime=0;
  let audio=null,lastImpact=0;
  function sound(type,volume=.2,kind){const set=sim.settings;if(!set.sound||!set.volume)return;try{audio??=new (window.AudioContext||window.webkitAudioContext)();if(audio.state==='suspended')audio.resume();const now=audio.currentTime,level=set.volume/60;if(type==='impact'&&now-lastImpact<.12)return;if(type==='impact')lastImpact=now;
    if(type==='electric'){if(now-(lastHit.electric||0)<.07)return;lastHit.electric=now;}
    if(type==='thud'||type==='slice'||type==='wet'||type==='crack'||type==='sizzle'||type==='cloth'||type==='ricochet'||type==='armour'||type==='metal'||type==='clink'){if(now-(lastHit[type]||0)<(type==='sizzle'?.35:.07))return;lastHit[type]=now;flesh(type,now,level*Math.min(1.4,volume));return;}
    if(type==='shot'){gunshot(kind||'gun',now,level);return;}
    if(type==='laser'){const o=audio.createOscillator(),g=audio.createGain(),f=audio.createBiquadFilter();o.type='sawtooth';o.frequency.setValueAtTime(900,now);o.frequency.exponentialRampToValueAtTime(420,now+.35);f.type='bandpass';f.frequency.value=1200;f.Q.value=3;g.gain.setValueAtTime(Math.min(.2,.1*level),now);g.gain.exponentialRampToValueAtTime(.001,now+.4);o.connect(f);f.connect(g);g.connect(audio.destination);o.start(now);o.stop(now+.42);return;}
    if(type==='thunder'){thunder(now,level);return;}
    if(type==='grunt'){const o=audio.createOscillator(),g=audio.createGain(),f=audio.createBiquadFilter();o.type='sawtooth';o.frequency.setValueAtTime(125+volume*40,now);o.frequency.exponentialRampToValueAtTime(78,now+.16);f.type='lowpass';f.frequency.value=520;g.gain.setValueAtTime(Math.min(.12,.06*volume*level),now);g.gain.exponentialRampToValueAtTime(.001,now+.2);o.connect(f);f.connect(g);g.connect(audio.destination);o.start(now);o.stop(now+.22);return;}
    if(type==='grow'||type==='surge'){const rise=audio.createOscillator(),g=audio.createGain(),long=type==='surge'?.7:.22;rise.type=type==='surge'?'sawtooth':'sine';rise.frequency.setValueAtTime(type==='surge'?90:220+volume*260,now);rise.frequency.exponentialRampToValueAtTime(type==='surge'?1400:520+volume*400,now+long);g.gain.setValueAtTime(.001,now);g.gain.exponentialRampToValueAtTime(Math.min(.2,.09*level),now+long*.6);g.gain.exponentialRampToValueAtTime(.001,now+long);rise.connect(g);g.connect(audio.destination);rise.start(now);rise.stop(now+long+.02);if(type==='surge')shake=7*set.shake;return;}
    const gain=audio.createGain();gain.connect(audio.destination);gain.gain.setValueAtTime(Math.min(.2,volume*.15*level),now);gain.gain.exponentialRampToValueAtTime(.001,now+.18);
    const oscillator=audio.createOscillator();oscillator.type=type==='electric'?'sawtooth':'triangle';oscillator.frequency.setValueAtTime(type==='explosion'?70:type==='shot'?210:type==='electric'?650:160,now);oscillator.frequency.exponentialRampToValueAtTime(30,now+.2);oscillator.connect(gain);oscillator.start(now);oscillator.stop(now+.22);
  }catch(err){console.warn('sound failed:',type,err);applySettings({sound:false});$('#sound-btn').textContent='Sound unavailable';}}
  // What a blow sounds like on a body. All of it is filtered noise, from one shared second of it: a thud is low and round with a sine under it, a slice is a wet hiss that falls, a round going in is a short dull smack,
  // a breaking bone is two dry clicks over a knock, a burn is a long thin hiss.
  const lastHit={};let noiseBuffer;
  function flesh(type,now,level){noiseBuffer??=(()=>{const b=audio.createBuffer(1,audio.sampleRate,audio.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;return b;})();
    const burst=(at,length,kind,f0,f1,q,peak)=>{const src=audio.createBufferSource(),f=audio.createBiquadFilter(),g=audio.createGain();src.buffer=noiseBuffer;src.loop=true;f.type=kind;f.Q.value=q;f.frequency.setValueAtTime(f0,at);f.frequency.exponentialRampToValueAtTime(f1,at+length);g.gain.setValueAtTime(Math.min(.5,peak*level),at);g.gain.exponentialRampToValueAtTime(.001,at+length);src.connect(f);f.connect(g);g.connect(audio.destination);src.start(at,Math.random()*.8);src.stop(at+length+.02);};
    const tone=(at,length,f0,f1,peak)=>{const o=audio.createOscillator(),g=audio.createGain();o.type='sine';o.frequency.setValueAtTime(f0,at);o.frequency.exponentialRampToValueAtTime(f1,at+length);g.gain.setValueAtTime(Math.min(.5,peak*level),at);g.gain.exponentialRampToValueAtTime(.001,at+length);o.connect(g);g.connect(audio.destination);o.start(at);o.stop(at+length+.02);};
    if(type==='thud'){tone(now,.14,95,42,.5);burst(now,.09,'lowpass',420,140,.7,.35);}
    else if(type==='slice'){burst(now,.13,'bandpass',3400,900,1.2,.3);burst(now+.02,.1,'lowpass',700,260,.8,.22);}
    else if(type==='wet'){burst(now,.07,'lowpass',900,220,.9,.4);tone(now,.06,140,70,.2);}
    else if(type==='crack'){burst(now,.03,'bandpass',2600,1900,4,.6);burst(now+.035,.04,'bandpass',1700,1200,4,.5);tone(now,.08,190,90,.3);}
    else if(type==='sizzle'){burst(now,.4,'highpass',4200,3000,.6,.12);}
    else if(type==='metal'){tone(now,.18,1900+Math.random()*600,1400,.25);burst(now,.04,'highpass',3000,2500,1,.3);} /* a round into steel: a ping */
    else if(type==='clink'){tone(now,.07,3800+Math.random()*1500,3000,.12);tone(now+.05,.05,4600,3600,.06);} /* a brass case bouncing */
    else if(type==='armour'){tone(now,.12,120,60,.45);burst(now,.05,'bandpass',1800,900,2,.35);} /* a round stopped by armour: a dull blow and a flat crack */
    else if(type==='ricochet'){const o=audio.createOscillator(),g=audio.createGain(),f0=2400+Math.random()*900;o.type='sine';o.frequency.setValueAtTime(f0,now);o.frequency.exponentialRampToValueAtTime(f0*.35,now+.32);g.gain.setValueAtTime(Math.min(.3,.14*level),now);g.gain.exponentialRampToValueAtTime(.001,now+.34);o.connect(g);g.connect(audio.destination);o.start(now);o.stop(now+.36);burst(now,.03,'bandpass',3000,2000,3,.3);} /* a spark and a falling whine */
    else if(type==='cloth'){burst(now,.16,'lowpass',1100,300,.5,.16);burst(now+.05,.12,'bandpass',1600,700,.7,.07);}} /* a soft rustle */
  // The sound of a held power: one loop per kind, faded in when the power appears and out when it goes. Each is a second or two of shaped noise (or, for heal, two soft tones) built once.
  // fire: a low roar with sharp random pops - crackle; cold: a thin band of wind that swells and sinks; shock: a harsh mains buzz; heal: a gentle hum.
  const loops={};let loopNow=null;
  function loopBuffer(kind){const rate=audio.sampleRate,n=rate*2,buffer=audio.createBuffer(1,n,rate),d=buffer.getChannelData(0);let brown=0,seed=kind.length*7.3;const rand=()=>{seed=(seed*16807+.5)%2147483647;return seed/2147483647;};
    for(let i=0;i<n;i++){const t=i/rate,white=rand()*2-1;brown=(brown+white*.04)*.985;
      d[i]=kind==='fire'?brown*2.2+(rand()<.0009?white*1.6:0)+white*.03:kind==='cold'?white*(.35+.25*Math.sin(t*Math.PI*1)+.12*Math.sin(t*Math.PI*5)):kind==='water'?white*(.5+.15*Math.sin(t*Math.PI*3))+(rand()<.004?white*.8:0):kind==='shock'?(((t*100)%1<.5?1:-1)*.35+white*.25)*(.7+.3*Math.sin(t*Math.PI*37)):0;}
    for(let i=0;i<2000;i++){const k=i/2000;d[i]*=k;d[n-1-i]*=k;}return buffer;}
  function powerSound(kind){const set=sim.settings;if(!set.sound||!set.volume)kind=null;if(kind===loopNow)return;
    try{if(loopNow&&loops[loopNow]){const old=loops[loopNow],now=audio.currentTime;old.gain.gain.cancelScheduledValues(now);old.gain.gain.setValueAtTime(old.gain.gain.value,now);old.gain.gain.linearRampToValueAtTime(0,now+.3);for(const node of old.nodes)node.stop(now+.35);delete loops[loopNow];}
      loopNow=kind;if(!kind)return;audio??=new (window.AudioContext||window.webkitAudioContext)();if(audio.state==='suspended')audio.resume();const now=audio.currentTime,gain=audio.createGain(),level=set.volume/60,nodes=[];gain.gain.setValueAtTime(0,now);gain.connect(audio.destination);
      if(kind==='heal'){for(const [f,g] of [[196,.5],[294,.3],[392,.15]]){const o=audio.createOscillator(),og=audio.createGain();o.type='sine';o.frequency.value=f;og.gain.value=g;o.connect(og);og.connect(gain);o.start(now);nodes.push(o);}const trem=audio.createOscillator(),tg=audio.createGain();trem.frequency.value=2.2;tg.gain.value=.012*level;trem.connect(tg);tg.connect(gain.gain);trem.start(now);nodes.push(trem);gain.gain.linearRampToValueAtTime(.05*level,now+.15);}
      else{const src=audio.createBufferSource(),filter=audio.createBiquadFilter();src.buffer=loopBuffer(kind);src.loop=true;filter.type=kind==='fire'?'lowpass':kind==='cold'||kind==='water'?'bandpass':'highpass';filter.frequency.value=kind==='fire'?1800:kind==='cold'?2200:kind==='water'?1200:180;filter.Q.value=kind==='cold'?.8:.5;src.connect(filter);filter.connect(gain);src.start(now,Math.random());nodes.push(src);gain.gain.linearRampToValueAtTime((kind==='fire'?.5:kind==='cold'||kind==='water'?.16:.12)*level,now+.12);}
      loops[kind]={gain,nodes};}catch{loopNow=null;}}
  // Gunshots. Each gun is the same four layers in its own proportions: the crack of the round leaving (a very short band of noise, higher for a fast rifle round), the blast (noise through a low-pass, longer and lower for a bigger charge),
  // the thump of the gas (a falling sine), and the room answering (a long dark tail and one echo off the far wall). A .50 is all blast and room; a submachine gun a short sharp pop; a shotgun a low boom; a crossbow no gunshot at all, only the string.
  const GUN_SOUND={gun:[3200,900,120,.16,.35,1],revolver:[2400,650,85,.26,.65,1.3],smg:[3600,1200,140,.08,.16,.8],rifle:[4400,1500,105,.11,.5,1.1],ak:[3300,950,82,.15,.55,1.2],lmg:[3000,850,76,.14,.6,1.25],minigun:[3800,1150,110,.05,.12,.65],shotgun:[1700,480,58,.32,.85,1.5],hunting:[3700,1050,70,.2,1,1.4],sniper:[2500,560,44,.38,1.7,1.9]};
  function gunshot(kind,now,level){noiseBuffer??=(()=>{const b=audio.createBuffer(1,audio.sampleRate,audio.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;return b;})();
    const noise=(at,length,type,f0,f1,q,peak)=>{const src=audio.createBufferSource(),f=audio.createBiquadFilter(),g=audio.createGain();src.buffer=noiseBuffer;src.loop=true;f.type=type;f.Q.value=q;f.frequency.setValueAtTime(f0,at);f.frequency.exponentialRampToValueAtTime(f1,at+length);g.gain.setValueAtTime(Math.min(.8,peak*level),at);g.gain.exponentialRampToValueAtTime(.0008,at+length);src.connect(f);f.connect(g);g.connect(audio.destination);src.start(at,Math.random()*.9);src.stop(at+length+.02);};
    if(kind==='crossbow'){const o=audio.createOscillator(),g=audio.createGain();o.type='triangle';o.frequency.setValueAtTime(210,now);o.frequency.exponentialRampToValueAtTime(120,now+.25);g.gain.setValueAtTime(Math.min(.4,.25*level),now);g.gain.exponentialRampToValueAtTime(.001,now+.3);o.connect(g);g.connect(audio.destination);o.start(now);o.stop(now+.32);noise(now,.08,'bandpass',2500,900,1.5,.25);return;} /* the string and the bolt leaving */
    const [crack,blast,thump,length,room,loud]=GUN_SOUND[kind]||GUN_SOUND.gun,l=loud*.55;
    noise(now,.025,'bandpass',crack,crack*.7,1.4,.7*l);noise(now,length,'lowpass',blast*2.4,blast*.35,.7,.9*l);
    {const o=audio.createOscillator(),g=audio.createGain();o.type='sine';o.frequency.setValueAtTime(thump*2.2,now);o.frequency.exponentialRampToValueAtTime(thump*.6,now+length*.8);g.gain.setValueAtTime(Math.min(.8,.8*l*level),now);g.gain.exponentialRampToValueAtTime(.001,now+length);o.connect(g);g.connect(audio.destination);o.start(now);o.stop(now+length+.02);}
    noise(now+.01,room,'lowpass',900,160,.5,.18*l);noise(now+.11+room*.08,room*.6,'lowpass',700,150,.5,.08*l);}
  // Thunder: a sharp crack, then low-passed noise that rolls off over a couple of seconds.
  function thunder(now,level){const length=2.6,buffer=audio.createBuffer(1,audio.sampleRate*length,audio.sampleRate),data=buffer.getChannelData(0);
    for(let i=0;i<data.length;i++){const t=i/audio.sampleRate;data[i]=(Math.random()*2-1)*(Math.exp(-t*30)+.55*Math.exp(-t*1.6)*(.6+.4*Math.sin(t*9)));}
    const source=audio.createBufferSource(),filter=audio.createBiquadFilter(),gain=audio.createGain();source.buffer=buffer;filter.type='lowpass';filter.frequency.setValueAtTime(2400,now);filter.frequency.exponentialRampToValueAtTime(120,now+.5);
    gain.gain.value=Math.min(.5,.35*level);source.connect(filter);filter.connect(gain);gain.connect(audio.destination);source.start(now);}
  sim.onDress=name=>toast(`Put on: ${name.toLowerCase()}`);
  sim.onEffect=(type,volume,kind)=>{sound(type,volume,kind);if(type==='explosion'||type==='thunder')shake=Math.min(14,volume*8)*sim.settings.shake;};
  let shake=0;
  function toast(message){$('#toast').textContent=message;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),2400);}
  function resize(){const r=stage.getBoundingClientRect();width=r.width;height=r.height;dpr=Math.min(window.devicePixelRatio||1,2);canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);}
  function fit(){camera.x=1220;camera.y=390;camera.zoom=Math.min(width/1040,height/660);camera.zoom=clamp(camera.zoom,.25,1.6);updateZoom();}
  function updateZoom(){$('#zoom-reset').textContent=Math.round(camera.zoom*100)+'%';}
  function toWorld(point){return {x:(point.x-width/2)/camera.zoom+camera.x,y:(point.y-height/2)/camera.zoom+camera.y};}
  function setTool(id){state.tool=id;state.ropeStart=null;state.graftStump=null;sim.power=null;sim.endDrag();document.querySelectorAll('.tool').forEach(b=>{b.classList.toggle('active',b.dataset.tool===id);b.setAttribute('aria-pressed',String(b.dataset.tool===id));});const t=TOOLS.find(t=>t.id===id);$('#tool-caption-icon').textContent=t.symbol;$('#tool-caption-name').textContent=t.title;if(id==='rope')ropeName();else $('#tool-caption-desc').textContent=t.desc;canvas.style.cursor=id==='grab'?'grab':'crosshair';}
  function chooseSpawn(id){state.spawn=state.spawn===id?null:id;state.rotation=0;document.querySelectorAll('.object-card').forEach(b=>b.classList.toggle('active',b.dataset.object===state.spawn));if(state.spawn)toast(CATALOG.find(c=>c.id===id).name+(Sandbox.defs[id].power?' ready — click a ragdoll to grant it, or one that has it to take it away':' ready — Q / E places it at the cursor, facing left / right'));}
  // A power armed in the library goes to the ragdoll under the cursor instead of being placed. True if a power was armed, whether or not it took.
  function grantAt(point){const power=Sandbox.defs[state.spawn]?.power;if(!power)return false;const e=sim.getEntity(sim.bodyAt(point)),name=CATALOG.find(c=>c.id===state.spawn).name;if(!e){toast('Click a ragdoll to grant it '+name+'.');return true;}if(e[power]){sim.revoke(e,power);toast(name+' taken away');updateSelection();return true;} /* a second click on a ragdoll that has it takes it back */toast(sim.grant(e,power)?name+' granted':'Only a human can take '+name+'.');if(e.kind==='human')sound('impact',.1);updateSelection();return true;}
  function temperature(c){const unit=sim.settings.tempUnit;return unit==='Fahrenheit'?Math.round(c*9/5+32)+'°F':unit==='Kelvin'?Math.round(c+273)+' K':Math.round(c)+'°C';}
  function select(body){state.selected=body;if(body?.plugin.part==='hand'){const picked=sim.equip(body);if(picked)toast(picked);}updateSelection();}
  function updateSelection(){const b=state.selected;if(!b||!sim.bodies.includes(b)){state.selected=null;$('#selection-panel').hidden=true;return;}$('#selection-panel').hidden=false;const p=b.plugin,c=CATALOG.find(c=>c.id===p.kind);$('#selection-name').textContent=(c?.name||'Fragment')+(p.part?' · '+p.part:'');$('#selection-info').innerHTML=`<div class="stat-row"><span>Integrity</span><b>${Math.round(p.hp/p.maxHp*100)}%</b></div><div class="health-bar"><i style="width:${clamp(p.hp/p.maxHp*100,0,100)}%"></i></div><div class="stat-row"><span>Temperature</span><b>${temperature(p.heat)}</b></div><div class="stat-row"><span>State</span><b>${b.isStatic?'Locked':p.burning?'Burning':p.heat<=-30?'Frozen solid':p.heat<0?'Freezing':p.charge>.1?'Electrified':p.hp<=0?'Broken':p.active?'Active':'Dynamic'}</b></div>`;$('#freeze-selection').textContent=b.isStatic?'Unlock':'Lock';$('#activate-selection').disabled=!['barrel','bomb','gun','thruster','wheel','battery'].includes(p.kind);}
  // Every wound on the selected part: what made it, how deep it goes, what state it is in, and what it hit on the way.
  const CAUSE={bullet:'Bullet entry',exit:'Bullet exit',cut:'Cut',stab:'Stab',impact:'Blunt',blast:'Shrapnel',burn:'Burn',shock:'Electrical burn'},DEPTH=['surface','skin','to muscle','to bone'],HIT={artery:'artery',joint:'joint',spine:'spine',brain:'brain',heart:'heart',lungs:'lung',gut:'gut'};
  function woundRows(p){const rows=(p.wounds||[]).map(w=>{const age=sim.time-(w.wet??w.t??0),state=w.stitched?'stitched':w.sealed?'bandaged':w.bleed>.05?(w.artery?'spurting':w.bleed>1.5?'bleeding heavily':'bleeding'):w.type==='impact'&&!w.depth?'bruise':w.type==='burn'?((w.force??99)<15?'reddened':(w.force??99)<40?'blistered':'charred'):w.type==='shock'?'burn marks':age<Sandbox.CLOT_AT?'wet':age<Sandbox.SCAB_AT?'clotted':'scabbed';
      return `<div class="stat-row"><span>${CAUSE[w.type]||w.type}${w.hits>1?' ×'+w.hits:''}</span><b>${w.type==='burn'||w.type==='shock'?'':DEPTH[w.depth??3]+' · '}${state}${w.hit?' · hit '+HIT[w.hit]:''}</b></div>`;});
    if(p.tourniquet)rows.push(`<div class="stat-row"><span>Tourniquet</span><b>on ${Math.round(sim.time-p.tourniquet.at)} s</b></div>`);if(p.necrotic)rows.push('<div class="stat-row"><span>Limb</span><b>dead</b></div>');else if(p.numb>.3)rows.push('<div class="stat-row"><span>Limb</span><b>numb</b></div>');
    for(const r of p.lodged||[])rows.push(`<div class="stat-row"><span>Lodged round</span><b>${+r.calibre.toFixed(2)} mm</b></div>`);
    for(const end of p.severed||[])rows.push(`<div class="stat-row"><span>Stump</span><b>${end.sealed?'bandaged':end.bleed>.05?'bleeding':'closed'}</b></div>`);return rows.length?`<div class="stat-row"><span>Wounds</span><b>${rows.length}</b></div>`+rows.join(''):'';}
  function chargeRow(e){return (e?.conduit?`<div class="stat-row"><span>Charge</span><b>${Math.round(e.power||0)}%${e.power>100?' overcharged':''}</b></div>`:'')+(e?.immortal?'<div class="stat-row"><span>Immortal</span><b>cannot die</b></div>':'')+(e?.strong?'<div class="stat-row"><span>Super strength</span><b>×2 muscle</b></div>':'')+(e?.healer?'<div class="stat-row"><span>Super healing</span><b>regenerating</b></div>':'')+(e?.tough?`<div class="stat-row"><span>Super endurance</span><b>${Math.round(e.grit??100)} / ${Math.round(e.gritMax??100)} grit</b></div>`:'');}
  function heartStatus(e){const heart=e.organs?e.organs.heart:100;return heart<=0?'Destroyed':!e.alive?'Stopped':heart<100?`Damaged · ${Math.round(e.heartRate||0)} bpm`:`${Math.round(e.heartRate||70)} bpm`;}
  function brainStatus(e){const brain=e.organs?e.organs.brain:100;return brain<=0?'Destroyed':brain<100?`Damaged · ${Math.round(brain)}%`:!e.alive?'No activity':e.consciousness==='unconscious'?'Unconscious':'Normal';}
  function updateAnatomyInfo(){const b=state.selected;if(!b||b.plugin.material!=='flesh'||!b.plugin.part)return;const e=sim.getEntity(b),p=b.plugin,whole=!!e?.bodies.some(x=>x.plugin.slot===2);/* a loose limb is remains: it has no vitals of its own */$('#selection-info').insertAdjacentHTML('beforeend',(whole?`<div class="stat-row"><span>Blood volume</span><b>${Math.round(e?.blood??100)}%</b></div>`:'')+`<div class="stat-row"><span>Bone integrity</span><b>${Math.round(p.bone??100)}%</b></div><div class="stat-row"><span>Condition</span><b>${!whole?'Severed':e?.alive===false?'Dead':e?.consciousness==='unconscious'?'Unconscious':e?.stun>0?'Knocked down':e?.consciousness==='dazed'?'Dazed':p.bleed>.05?'Bleeding':'Stable'}</b></div>`+(p.splint?`<div class="stat-row"><span>Limb</span><b>Splinted, knitting (${Math.round(p.bone)}%)</b></div>`:p.bone<=50?`<div class="stat-row"><span>Limb</span><b>Fractured</b></div>`:'')+woundRows(p)+(p.internal>.02?`<div class="stat-row"><span>Internal bleeding</span><b>${p.internal>1?'Massive':p.internal>.3?'Heavy':'Slow'}</b></div>`:'')
    +(whole?chargeRow(e):'')+(whole&&e.kind==='human'?`<div class="stat-row"><span>Heart</span><b>${heartStatus(e)}</b></div><div class="stat-row"><span>Brain</span><b>${brainStatus(e)}</b></div><div class="stat-row"><span>Pain</span><b>${e.painless?'switched off':Math.round(e.pain||0)+'%'}</b></div><div class="stat-row"><span>Oxygen</span><b>${Math.round(e.oxygen??100)}%</b></div>`+(e.organs?Object.entries(e.organs).filter(([k,v])=>v<100&&k!=='heart'&&k!=='brain').map(([k,v])=>`<div class="stat-row"><span>${k[0].toUpperCase()+k.slice(1)}</span><b>${v<=0?'Destroyed':Math.round(v)+'%'}</b></div>`).join(''):'')+(e.causeOfDeath?`<div class="stat-row"><span>Cause of death</span><b>${e.causeOfDeath}</b></div>`:''):''));}
  function roundRect(c,x,y,w,h,r=2){c.beginPath();c.roundRect(x,y,w,h,r);}
  const ANATOMY_SLOT=Object.fromEntries(Sandbox.ANATOMY.map(([part],slot)=>[part,slot]).reverse());
  function drawObject(c,kind,p={},time=0){
    const d=Sandbox.defs[kind]||{},w=p.w||d.w||25,h=p.h||d.h||35,r=p.r||d.r;
    const item=CATALOG.find(i=>i.id===kind);c.fillStyle=item?.color||'#b5bdb8';c.strokeStyle='#141c21';c.lineWidth=1.5;
    if(p.gib){const bone=p.material==='bone',plain=sim.settings.noGore;c.fillStyle=bone?'#ece3cb':plain?'#8d8a84':p.material==='flesh'?'#8a2a31':'#8f9a9e';c.strokeStyle=bone?'#b8ab8a':plain?'#6f6c66':'#5a161c';c.lineWidth=.6;c.beginPath();
      for(let i=0;i<7;i++){const a=i/7*6.283,r=(i%2?.62:1)*(bone?.55:.5)*(.8+hash(p.seed+i)*.4);(i?c.lineTo:c.moveTo).call(c,Math.cos(a)*w*r,Math.sin(a)*h*r);}c.closePath();c.fill();c.stroke();if(!bone&&!plain){c.fillStyle='#c0565a';c.beginPath();c.arc(-w*.12,-h*.1,Math.min(w,h)*.16,0,7);c.fill();}return;}
    if(p.casing){c.fillStyle=p.colour||'#c9a24a';c.fillRect(-w/2,-h/2,w,h);c.fillStyle='#6e5320';c.fillRect(-w/2,-h/2,Math.max(.8,w*.18),h);c.fillStyle='#fff3c0';c.globalAlpha=.6;c.fillRect(-w/2+w*.25,-h/2,w*.5,Math.max(.5,h*.3));c.globalAlpha=1;return;} /* a brass case, its rim, a glint */
    if(p.debris){if(p.material==='flesh')c.fillStyle=sim.settings.noGore?'#8d8a84':'#7d2f33';c.fillRect(-w/2,-h/2,w,h);return;}
    if(ItemArt.has(kind)){if(!p.w&&!p.r){p={...d,...p};}p.noGore=sim.settings.noGore;ItemArt.draw(c,kind,p,time);return;} // every catalogue item is a cached sprite from art.js; what follows is the fallback for things without a painter
    const dressed=Sandbox.defs[kind]?.ragdoll;if(dressed){BodyArt.preview(c,p.part,p.slot??ANATOMY_SLOT[p.part],p.w,p.h,Sandbox.defs[kind].outfit);return;}
    if(kind==='human'||kind==='android'){
      if(kind==='human'){BodyArt.preview(c,p.part,p.slot??ANATOMY_SLOT[p.part],p.w,p.h);return;} // previews only; live humans are drawn by BodyArt.draw with their damage state
      const robot=kind==='android';c.fillStyle=robot?'#8ba8a4':p.part==='chest'?'#99a9a0':p.part==='hip'?'#727f7b':'#c9c3b6';
      if(p.hp<=0)c.fillStyle=robot?'#637777':'#aa9289';
      if(p.part==='head'){roundRect(c,-w/2,-h/2,w,h,robot?3:7);c.fill();c.stroke();c.fillStyle=robot?'#d3cd83':'#394746';c.fillRect(5,-4,4,robot?3:2);if(robot){c.fillStyle='#506763';c.fillRect(-7,-9,12,3);}}
      else {roundRect(c,-w/2,-h/2,w,h,3);c.fill();c.stroke();c.fillStyle=robot?'#bacac2':'#b3c1b3';if(p.part==='chest'){c.fillRect(-w/2+4,-h/2+5,4,h-12);c.fillStyle='#667d76';c.fillRect(-6,0,12,5);}if(robot){c.strokeStyle='#476962';c.beginPath();c.moveTo(-w/2+3,0);c.lineTo(w/2-3,0);c.stroke();}}
      return;
    }
    if(r){c.beginPath();c.arc(0,0,r,0,Math.PI*2);c.fill();c.stroke();}else{roundRect(c,-w/2,-h/2,w,h,2);c.fill();c.stroke();}
  }
  function drawMini(c,kind){c.clearRect(0,0,160,114);c.save();c.translate(80,55);if(kind==='human'||kind==='android'||Sandbox.defs[kind]?.ragdoll){
    c.scale(.45,.45);c.translate(0,12);Sandbox.ANATOMY.map((row,slot)=>[...row,slot]).sort((a,b)=>BodyArt.layer({part:a[0],slot:a[5]})-BodyArt.layer({part:b[0],slot:b[5]})).forEach(([part,x,y,w,h,slot])=>{c.save();c.translate(x,y);drawObject(c,kind,{part,slot,w,h,r:0,hp:100});c.restore();});
  }else{const d=Sandbox.defs[kind],s=Math.min(d.garment?2.6:1.3,120/(d.w||d.r*2),78/(d.h||d.r*2)); /* garments are small things: shown larger on their cards */c.scale(s,s);drawObject(c,kind,d);}c.restore();}
  // Clothes are grouped by what they are worn as: the kind on the garment row, with anything that stops a round under Armour.
  const CLOTHES_SUB={top:'Tops',pants:'Trousers',hat:'Headwear',shoes:'Shoes',gloves:'Gloves',mask:'Masks'},subOf=c=>c.armour?'Armour':CLOTHES_SUB[c.garment?.kind]||'Other';
  function renderSubcategories(){const bar=$('#subcategories'),subs=state.category==='Clothes'?[...new Set(CATALOG.filter(c=>c.category==='Clothes').map(subOf))]:[];bar.hidden=!subs.length;bar.replaceChildren();if(!subs.length){state.sub='all';return;}
    if(!subs.includes(state.sub))state.sub='all';
    for(const name of ['all',...subs]){const b=document.createElement('button');b.textContent=name==='all'?'All kinds':name;b.classList.toggle('active',name===state.sub);b.onclick=()=>{state.sub=name;renderSubcategories();renderCatalog();};bar.append(b);}}
  function renderCatalog(){const query=$('#search').value.trim().toLowerCase();const list=CATALOG.filter(c=>(state.category==='all'||c.category===state.category)&&(state.sub==='all'||state.category!=='Clothes'||subOf(c)===state.sub)&&`${c.name} ${c.description}`.toLowerCase().includes(query));$('#catalog-count').textContent=list.length+' objects';$('#catalog').replaceChildren();for(const item of list){const button=document.createElement('button');button.className='object-card'+(state.spawn===item.id?' active':'');button.dataset.object=item.id;button.title=item.description;button.setAttribute('aria-label','Spawn '+item.name);const preview=document.createElement('canvas');preview.width=160;preview.height=114;preview.setAttribute('aria-hidden','true');button.appendChild(preview);const name=document.createElement('span');name.className='name';name.textContent=item.name;button.appendChild(name);if(item.id==='human'){const tag=document.createElement('span');tag.className='tag';tag.textContent='Start here';button.appendChild(tag);}button.addEventListener('click',()=>chooseSpawn(item.id));$('#catalog').appendChild(button);drawMini(preview.getContext('2d'),item.id);}if(!list.length){const p=document.createElement('p');p.className='no-results';p.textContent='No objects match your search.';$('#catalog').appendChild(p);}}
  for(const tool of TOOLS){const b=document.createElement('button');b.className='tool'+(tool.id==='grab'?' active':'');b.dataset.tool=tool.id;if(tool.id==='rope')b.dataset.menu='rope';b.title=`${tool.title} (${tool.key})`;b.setAttribute('aria-label',tool.title);b.setAttribute('aria-pressed',String(tool.id==='grab'));b.innerHTML=`<span class="shortcut">${tool.key}</span><span class="symbol">${tool.symbol}</span><span class="tool-name">${tool.name}</span>`+(tool.id==='rope'?'<span class="caret">▾</span>':'');b.addEventListener('click',()=>{setTool(tool.id);if(tool.id==='rope')ropeMenu(b);});$('#tools').appendChild(b);}
  // The Rope tool holds two kinds of tie: plain rope, and wire that carries current from whatever is shocked at one end to everything on the other.
  const ROPE_KINDS=[{id:'rope',name:'Rope',desc:'A plain tie. Holds two things together.'},{id:'wire',name:'Electrical wire',desc:'Carries current from end to end, however far.'}];
  function ropeMenu(button){const open=document.querySelector('.tool-menu');if(open){open.remove();if(open.dataset.for==='rope')return;}
    const menu=document.createElement('div');menu.className='tool-menu';menu.dataset.for='rope';
    for(const kind of ROPE_KINDS){const b=document.createElement('button');b.className=kind.id===state.ropeKind?'active':'';b.innerHTML=`${kind.name}<small>${kind.desc}</small>`;b.onclick=e=>{e.stopPropagation();state.ropeKind=kind.id;state.ropeStart=null;ropeName();menu.remove();};menu.append(b);}
    button.append(menu);const close=e=>{if(!menu.contains(e.target)&&e.target!==button){menu.remove();document.removeEventListener('pointerdown',close);}};setTimeout(()=>document.addEventListener('pointerdown',close),0);}
  function ropeName(){const kind=ROPE_KINDS.find(k=>k.id===state.ropeKind),b=document.querySelector('[data-menu="rope"]');if(!b)return;b.querySelector('.tool-name').textContent=kind.name==='Electrical wire'?'Wire':kind.name;if(state.tool==='rope'){$('#tool-caption-name').textContent=kind.name;$('#tool-caption-desc').textContent=kind.desc;}}
  const hash=n=>{const x=Math.sin(n*127.1)*43758.5453;return x-Math.floor(x);};
  // Fire. A flame is hundreds of soft blobs drawn additively: each is born somewhere on the burning body, accelerates upward, wanders in the turbulence,
  // shrinks and cools from white-yellow through orange to red. Overlapping blobs add up into one continuous, flickering flame body, so a burning ragdoll
  // is wrapped in a single fire rather than wearing seventeen small ones. Visual only, so it lives here and not in the engine.
  const smooth=t=>{const i=Math.floor(t),f=t-i,u=f*f*(3-2*f);return hash(i)*(1-u)+hash(i+1)*u;};
  const FLAMES=1600,flame={x:new Float32Array(FLAMES),y:new Float32Array(FLAMES),vx:new Float32Array(FLAMES),vy:new Float32Array(FLAMES),age:new Float32Array(FLAMES),life:new Float32Array(FLAMES),size:new Float32Array(FLAMES),next:0,alive:0};
  function emitFlames(b,dt){const p=b.plugin,w=p.w||p.r*2||20,h=p.h||p.r*2||20,power=clamp((p.heat-150)/380,.5,1.3),rate=clamp(w*h/34,8,115)*power*(flame.alive>1200?.35:1); // by surface area: a crate burns with many more blobs than a hand
    let count=rate*dt;count=Math.floor(count)+(Math.random()<count%1?1:0);const cos=Math.cos(b.angle),sin=Math.sin(b.angle),base=clamp(Math.min(w,h)*.5,5,15);
    for(;count>0;count--){const i=flame.next=(flame.next+1)%FLAMES;let x=0,y=1e9;
      // Fire climbs: of two random points on the body, the higher one burns. That keeps the base of the flame on the object and its bulk above it.
      for(let tries=0;tries<2;tries++){const lx=(Math.random()-.5)*w,ly=(Math.random()-.5)*h,wy=b.position.y+lx*sin+ly*cos;if(wy<y){y=wy;x=b.position.x+lx*cos-ly*sin;}}
      flame.x[i]=x;flame.y[i]=y;flame.vx[i]=b.velocity.x*30+(Math.random()-.5)*22;flame.vy[i]=b.velocity.y*18-45-Math.random()*55;
      flame.age[i]=0;flame.life[i]=(.55+Math.random()*.65)*(.8+power*.3);flame.size[i]=base*(.75+Math.random()*.6)*(.85+power*.25);}}
  // The flame of the fire power: the same blobs, born at the cursor and thrown back along the way it is moving, so the flame leans away from the motion.
  function emitFlamesAt(x,y,vx,vy,dt){let count=70*dt*(flame.alive>1200?.35:1);count=Math.floor(count)+(Math.random()<count%1?1:0);
    for(;count>0;count--){const i=flame.next=(flame.next+1)%FLAMES;flame.x[i]=x+(Math.random()-.5)*12;flame.y[i]=y+(Math.random()-.5)*8;flame.vx[i]=-vx*.35+(Math.random()-.5)*20;flame.vy[i]=-vy*.2-50-Math.random()*55;flame.age[i]=0;flame.life[i]=.45+Math.random()*.5;flame.size[i]=9+Math.random()*7;}}
  function drawFire(dt,left,right){
    if(dt>0)for(const b of sim.bodies)if(b.plugin.burning&&b.bounds.max.x>left-80&&b.bounds.min.x<right+80)emitFlames(b,dt);
    const hot=glowSprite('flameHot','255,236,170',1),mid=glowSprite('flameMid','255,138,32',1),cool=glowSprite('flameCool','205,44,12',1),t=sim.time;let alive=0;
    for(let i=0;i<FLAMES;i++){if(flame.age[i]>=flame.life[i])continue;alive++;
      if(dt>0){flame.age[i]+=dt;flame.vy[i]-=230*dt;flame.vx[i]+=((smooth(flame.y[i]*.035+t*2.2+i%7)-.5)*260-flame.vx[i]*2.2)*dt;flame.x[i]+=flame.vx[i]*dt;flame.y[i]+=flame.vy[i]*dt;}
      const k=flame.age[i]/flame.life[i];if(k>=1)continue;const r=flame.size[i]*(1.2-k*1.02),x=flame.x[i],y=flame.y[i],stretch=1+k*.9; // blobs stretch upward as they rise, which reads as licking tongues
      // red outer haze the whole way up, orange through the middle of its life, yellow-white only while young. Alphas are low because the blobs add up.
      ctx.globalAlpha=.2*(1-k);ctx.drawImage(cool,x-r*1.45,y-r*1.45*stretch,r*2.9,r*2.9*stretch);
      if(k<.7){ctx.globalAlpha=.3*(1-k/.7);ctx.drawImage(mid,x-r,y-r*stretch,r*2,r*2*stretch);}
      if(k<.28){ctx.globalAlpha=.32*(1-k/.28);ctx.drawImage(hot,x-r*.5,y-r*.5,r,r);}}
    flame.alive=alive;ctx.globalAlpha=1;}
  // Performance: nothing here builds a gradient or blurs per frame. Flame tongues, glows and smoke are painted once into small sprites and stamped with drawImage.
  const sprites={};
  function sprite(name,w,h,paint){if(!sprites[name]){const c=document.createElement('canvas');c.width=w;c.height=h;paint(c.getContext('2d'),w,h);sprites[name]=c;}return sprites[name];}
  const glowSprite=(name,rgb,alpha)=>sprite(name,128,128,c=>{const g=c.createRadialGradient(64,64,0,64,64,64);g.addColorStop(0,`rgba(${rgb},${alpha})`);g.addColorStop(1,`rgba(${rgb},0)`);c.fillStyle=g;c.fillRect(0,0,128,128);});
  const view={a:1,e:0,f:0}; // the world transform (uniform scale + offset)
  function fireGlow(b){const wide=b.bounds.max.x-b.bounds.min.x,reach=wide*.8+55;ctx.globalAlpha=clamp(wide/80,.1,1);ctx.drawImage(glowSprite('fireGlow','255,130,40',.2),b.position.x-reach,b.position.y-reach,reach*2,reach*2);ctx.globalAlpha=1;}
  // Lightning. A channel is a midpoint-displaced path that forks on the way down. The channel keeps its shape for the whole strike;
  // what changes is the light: a first return stroke, then one or two dimmer restrikes down the same path, each decaying fast. Forks only show on the first.
  function jagged(from,to,roughness,depth,seed){let points=[from,to];for(let d=0;d<depth;d++){const next=[points[0]];for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],len=Math.hypot(b.x-a.x,b.y-a.y),nx=-(b.y-a.y)/(len||1),ny=(b.x-a.x)/(len||1),offset=(hash(seed+=1.7)-.5)*len*roughness;next.push({x:(a.x+b.x)/2+nx*offset,y:(a.y+b.y)/2+ny*offset},b);}points=next;}return points;}
  function boltShape(t){const seed=t.from.x*.37+t.to.y,main=jagged(t.from,t.to,.34,6,seed),forks=[],drop=t.to.y-t.from.y;
    for(let i=0;i<5;i++){const at=main[Math.floor((.12+hash(seed+i*9.1)*.6)*main.length)],side=hash(seed+i*3.3)<.5?-1:1,reach=drop*(.12+hash(seed+i*5.7)*.2),end={x:at.x+side*reach*(.45+hash(seed+i)*.5),y:at.y+reach};
      const fork=jagged(at,end,.4,4,seed+i*31);forks.push(fork);if(hash(seed+i*7.7)<.5){const twigFrom=fork[Math.floor(fork.length*.55)];forks.push(jagged(twigFrom,{x:twigFrom.x-side*reach*.3,y:twigFrom.y+reach*.4},.45,3,seed+i*57));}}
    return {main,forks};}
  function strokeLight(t){const age=t.maxLife-t.life;return Math.max(...[[0,1],[.13,.6],[.27,.38]].map(([start,power])=>age>=start?power*Math.exp(-(age-start)*17):0));}
  const pathOf=list=>{const path=new Path2D();for(const points of list)points.forEach((p,i)=>i?path.lineTo(p.x,p.y):path.moveTo(p.x,p.y));return path;};
  function stroke(path,width,color){ctx.lineWidth=width;ctx.strokeStyle=color;ctx.stroke(path);}
  function drawElectric(t){ctx.lineJoin='round';ctx.lineCap='round';
    if(t.bolt){if(!t.shape){const shape=boltShape(t);t.shape={main:pathOf([shape.main]),forks:pathOf(shape.forks)};}const light=strokeLight(t),first=t.maxLife-t.life<.12,z=1/Math.max(.5,camera.zoom);if(light<.02)return;
      stroke(t.shape.main,26*z,`rgba(110,150,255,${.07*light})`);stroke(t.shape.main,12*z,`rgba(140,175,255,${.16*light})`);stroke(t.shape.main,5*z,`rgba(185,210,255,${.45*light})`);stroke(t.shape.main,2*z,`rgba(255,255,255,${Math.min(1,light*1.25)})`);
      if(first){stroke(t.shape.forks,4*z,`rgba(150,185,255,${.22*light})`);stroke(t.shape.forks,1.1*z,`rgba(240,246,255,${.85*light})`);}ctx.lineCap='butt';return;}
    // Arcs are restless: a new path thirty times a second, flickering in brightness, drawn as light (additive) - a wide blue halo, a bright channel, a white core, a fainter second strand wandering beside it and a twig or two leaving it.
    const fade=t.life/t.maxLife,tick=Math.floor(sim.time*30),flick=.55+.45*hash(tick*1.3+t.from.x);ctx.globalCompositeOperation='lighter';
    if(t.contact){const r=(26*fade+8),rays=[]; // where current enters: a flash and a star of short arcs that shrinks as it dies
      ctx.globalAlpha=fade;ctx.drawImage(glowSprite('arcGlow','150,215,255',.6),t.to.x-r*1.7,t.to.y-r*1.7,r*3.4,r*3.4);ctx.globalAlpha=1;
      for(let i=0;i<6;i++){const a=hash(tick+i*7.3)*6.28,len=(10+hash(tick*2+i)*24)*(.4+.6*fade);rays.push(jagged(t.to,{x:t.to.x+Math.cos(a)*len,y:t.to.y+Math.sin(a)*len},.5,2,tick+i*13));}
      const star=pathOf(rays);stroke(star,3.5,`rgba(120,200,255,${.32*fade})`);stroke(star,1.1,`rgba(240,252,255,${fade})`);}
    else{const main=jagged(t.from,t.to,.38,4,tick+t.from.x),strand=jagged(t.from,t.to,.62,3,tick*1.7+t.to.y),twigs=[];
      for(let k=0;k<2;k++){const at=main[2+Math.floor(hash(tick+k*3.1)*(main.length-4))],a=hash(tick*1.1+k)*6.28,len=8+hash(tick+k*9)*16;twigs.push(jagged(at,{x:at.x+Math.cos(a)*len,y:at.y+Math.sin(a)*len},.5,2,tick+k*21));}
      const arc=pathOf([main]);stroke(arc,8,`rgba(90,165,255,${.16*fade*flick})`);stroke(arc,3.2,`rgba(140,210,255,${.42*fade*flick})`);stroke(arc,1.2,`rgba(245,252,255,${fade*flick})`);
      stroke(pathOf([strand]),.8,`rgba(190,230,255,${.45*fade*flick})`);stroke(pathOf(twigs),.8,`rgba(215,240,255,${.7*fade*flick})`);
      for(const end of [t.from,t.to]){ctx.globalAlpha=.7*fade*flick;ctx.drawImage(glowSprite('arcGlow','150,215,255',.6),end.x-11,end.y-11,22,22);}ctx.globalAlpha=1;}
    ctx.globalCompositeOperation='source-over';ctx.lineCap='butt';}
  const POWER_RING={water:'#6fb6ff99',fire:'#f0a05a99',cold:'#a9dcff99',shock:'#9fd0ff99',heal:'#8ff0a899'},POWER_LIGHT={fire:[190,1],cold:[100,.4],shock:[170,.9],heal:[110,.55]},powerWas={x:0,y:0,vx:0,vy:0};
  function drawPower(w,dt){if(w.kind==='water')return; /* the drops are the picture */const R=sim.powerRadius(w.kind),tick=Math.floor(performance.now()/33);if(dt>0){powerWas.vx+=((w.x-powerWas.x)/dt-powerWas.vx)*.35;powerWas.vy+=((w.y-powerWas.y)/dt-powerWas.vy)*.35;}powerWas.x=w.x;powerWas.y=w.y;
    ctx.globalCompositeOperation='lighter';
    if(w.kind==='fire'){if(dt>0)emitFlamesAt(w.x,w.y,clamp(powerWas.vx,-900,900),clamp(powerWas.vy,-900,900),dt);const f=.8+.2*hash(tick);ctx.globalAlpha=.5*f;ctx.drawImage(glowSprite('fireGlow','255,130,40',.2),w.x-R*2.2,w.y-R*2.2,R*4.4,R*4.4);ctx.globalAlpha=.9;ctx.drawImage(glowSprite('flameHot','255,236,170',1),w.x-9,w.y-9,18,18);}
    else if(w.kind==='cold'){const f=.85+.15*hash(tick);ctx.globalAlpha=.55*f;ctx.drawImage(glowSprite('coldGlow','150,210,255',.5),w.x-R*1.5,w.y-R*1.3,R*3,R*3);ctx.globalAlpha=.8;ctx.drawImage(glowSprite('coldCore','235,248,255',.9),w.x-8,w.y-8,16,16);}
    else if(w.kind==='heal'){const f=.8+.2*Math.sin(performance.now()/260);ctx.globalAlpha=.5*f;ctx.drawImage(glowSprite('healGlow','120,240,160',.5),w.x-R*1.5,w.y-R*1.5,R*3,R*3);ctx.globalAlpha=.75;ctx.drawImage(glowSprite('healCore','215,255,225',.9),w.x-7,w.y-7,14,14);}
    else{ctx.lineJoin='round';ctx.lineCap='round';const arcs=[],n=state.paused?0:w.n||0; // a bright core, and arcs to whatever the engine struck on its last tick; with nothing in reach, short ones that fizzle out
      for(let j=0;j<n;j++)arcs.push(jagged(w,w.hits[j],.4,4,tick+j*17));if(!n)for(let j=0;j<3;j++){const a=hash(tick*1.3+j*5.1)*6.28,len=(14+hash(tick+j*9)*30)*(R/120);arcs.push(jagged(w,{x:w.x+Math.cos(a)*len,y:w.y+Math.sin(a)*len},.55,3,tick+j*23));}
      const path=pathOf(arcs),f=.6+.4*hash(tick*1.7);stroke(path,7,`rgba(90,165,255,${.18*f})`);stroke(path,3,`rgba(140,210,255,${.45*f})`);stroke(path,1.2,`rgba(245,252,255,${f})`);ctx.globalAlpha=.9*f;ctx.drawImage(glowSprite('arcGlow','150,215,255',.6),w.x-20,w.y-20,40,40);ctx.globalAlpha=1;ctx.drawImage(glowSprite('coldCore','235,248,255',.9),w.x-6,w.y-6,12,12);ctx.lineCap='butt';}
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';}
  // With the floodlights off the chamber is dark, and anything that burns, flashes or arcs cuts a hole in the dark.
  let shade=null;
  function darkness(){shade??=document.createElement('canvas');if(shade.width!==canvas.width||shade.height!==canvas.height){shade.width=canvas.width;shade.height=canvas.height;}
    const d=shade.getContext('2d'),toScreen=p=>({x:(p.x-camera.x)*camera.zoom+width/2,y:(p.y-camera.y)*camera.zoom+height/2});d.setTransform(dpr,0,0,dpr,0,0);d.globalCompositeOperation='source-over';d.clearRect(0,0,width,height);d.fillStyle='rgba(4,7,10,.86)';d.fillRect(0,0,width,height);d.globalCompositeOperation='destination-out';
    const hole=glowSprite('hole','0,0,0',1),light=(point,radius,power=1)=>{const p=toScreen(point),r=radius*camera.zoom;d.globalAlpha=Math.min(1,power);d.drawImage(hole,p.x-r,p.y-r,r*2,r*2);};
    for(const b of sim.bodies){const p=b.plugin;if(p.burning)light(b.position,150+Math.sin(sim.time*23+b.id)*12);else if(p.charge>.1)light(b.position,70,p.charge);else if(p.active&&p.kind==='thruster')light(b.position,110);}
    for(const f of sim.flashes)light(f,f.radius*2.2,f.life/f.maxLife);for(const t of sim.traces)if(t.bolt){const power=Math.min(1,strokeLight(t)*1.4);if(power>.02){light(t.to,520,power);light({x:(t.from.x+t.to.x)/2,y:(t.from.y+t.to.y)/2},620,power*.8);}}else if(t.electric)light(t.to,60,t.life/t.maxLife);
    if(sim.power&&POWER_LIGHT[sim.power.kind]){const [reach,power]=POWER_LIGHT[sim.power.kind];light(sim.power,reach*(.92+.08*hash(Math.floor(performance.now()/40))),power);} /* a held power lights the dark: fire and arcs brightly, heal softly, cold faintly */
    if(state.inside)light(state.worldPointer,95,.55); // a little working light at the cursor, or the room is unusable
    d.globalAlpha=1;ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.drawImage(shade,0,0);ctx.restore();}
  // Rain, snow and fog are stateless: every streak's position is a function of its index and the clock.
  function weather(){const set=sim.settings,time=sim.time;
    if(set.fog){const fog=ctx.createLinearGradient(0,height*.25,0,height);fog.addColorStop(0,'rgba(168,182,188,.05)');fog.addColorStop(1,'rgba(168,182,188,.4)');ctx.fillStyle=fog;ctx.fillRect(0,0,width,height);
      for(let i=0;i<6;i++){const x=((hash(i+3)*width*1.6+time*(9+i*3))%(width*1.6))-width*.3,y=height*(.55+hash(i+11)*.35),r=190+hash(i+5)*160,g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,'rgba(190,202,206,.13)');g.addColorStop(1,'rgba(190,202,206,0)');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2);}}
    if(set.rain){ctx.strokeStyle='rgba(170,195,215,.34)';ctx.lineWidth=1;ctx.beginPath();for(let i=0;i<170;i++){const speed=900+hash(i)*500,x=(hash(i+.5)*(width+200)+time*120)%(width+200)-100,y=(hash(i+.25)*height+time*speed)%height,len=13+hash(i+.75)*12;ctx.moveTo(x,y);ctx.lineTo(x-len*.16,y-len);}ctx.stroke();}
    if(set.snow){ctx.fillStyle='rgba(235,242,246,.8)';for(let i=0;i<120;i++){const fall=32+hash(i)*45,x=(hash(i+.5)*width+Math.sin(time*.9+i)*22+time*8)%width,y=(hash(i+.25)*height+time*fall)%height,r=.9+hash(i+.75)*1.9;ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();}}
  }
  // Blood dries from bright red to a dark brown over about half a minute; android coolant from teal to near black.
  const STAIN_RAMP=[[155,31,42],[72,26,28]],OIL_RAMP=[[47,84,90],[24,34,36]];
  function stainColor(wet,oil){const [a,b]=oil?OIL_RAMP:STAIN_RAMP;return `rgb(${Math.round(b[0]+(a[0]-b[0])*wet)},${Math.round(b[1]+(a[1]-b[1])*wet)},${Math.round(b[2]+(a[2]-b[2])*wet)})`;}
  const fillers=new Map(),drawList=[];
  const LIVOR_AFTER=12,LIVOR_TIME=40; // the dead go pale over the first seconds; then the blood settles into whatever side is down
  const REMAINS={view:0,livor:0,pale:0,face:'dead',faceId:13,gaze:0,dead:true,noGore:false,time:0,char:0,breath:0}; // parts whose owner is gone
  const looks=new Map(); // entity id -> how that ragdoll looks this frame: pallor, face, dead. Filled once per frame, shared by its 17 parts.
  function render(){
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,width,height);ctx.fillStyle='#20282d';ctx.fillRect(0,0,width,height);
    ctx.save();ctx.translate(width/2+(Math.random()-.5)*shake,height/2+(Math.random()-.5)*shake);ctx.scale(camera.zoom,camera.zoom);ctx.translate(-camera.x,-camera.y);shake*=.88;{const m=ctx.getTransform();view.a=m.a;view.e=m.e;view.f=m.f;}
    const left=camera.x-width/2/camera.zoom,right=camera.x+width/2/camera.zoom,top=camera.y-height/2/camera.zoom,bottom=camera.y+height/2/camera.zoom;
    ctx.lineWidth=1/camera.zoom;
    const set=sim.settings;looks.clear();for(const e of sim.entities){if(e.kind!=='human')continue;const face=!set.faces?'neutral':!e.alive?'dead':e.consciousness==='unconscious'?'closed':e.shoutT>0?'shout':(sim.time-(e.hitTime??-9)<.6||e.pain>65)?'tense':e.consciousness==='dazed'?'dazed':'neutral';
      const iris=e.immortal?'gold':e.conduit?(e.power>2&&e.alive?'storm':'stormDim'):null,irisN=iris==='gold'?1:iris==='storm'?2:iris==='stormDim'?3:0;
      looks.set(e.id,{iris,view:state.view,organs:e.organs,livor:e.alive||e.diedAt===undefined?0:clamp((sim.time-e.diedAt-LIVOR_AFTER)/LIVOR_TIME,0,1),pale:Math.max(e.blood<75?clamp((75-e.blood)/50,0,1):0,e.alive||e.diedAt===undefined?0:clamp((sim.time-e.diedAt)/LIVOR_AFTER,0,1)*.5),face,faceId:BodyArt.FACES.indexOf(face)*3+((set.faces&&e.alive?e.gaze:0)||0)+1+irisN*1000,gaze:(set.faces&&e.alive?e.gaze:0)||0,dead:!e.alive,noGore:set.noGore,time:sim.time,char:0,breath:e.alive&&set.breathing?Math.sin((e.breath||0)*Math.PI*2)*(.018+Math.min(.03,(e.pain||0)/2500)):0});}
    if(set.grid)for(let x=Math.floor(left/32)*32;x<right;x+=32){ctx.strokeStyle=x%160===0?'#39464e':'#2c383f';ctx.beginPath();ctx.moveTo(x,top);ctx.lineTo(x,Math.min(bottom,sim.groundY));ctx.stroke();}
    if(set.grid)for(let y=Math.floor(top/32)*32;y<Math.min(bottom,sim.groundY);y+=32){ctx.strokeStyle=y%160===0?'#39464e':'#2c383f';ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(right,y);ctx.stroke();}
    // Far wall measurement ticks and subtle workshop fixtures.
    ctx.strokeStyle='#56626a';ctx.fillStyle='#54646d';ctx.font='10px Barlow, Arial';ctx.textAlign='left';
    for(let x=0;x<2600;x+=160){ctx.beginPath();ctx.moveTo(x,sim.groundY-9);ctx.lineTo(x,sim.groundY);ctx.stroke();ctx.fillText(String(x/100).padStart(2,'0'),x+5,sim.groundY-11);}
    ctx.fillStyle='#303a3f';ctx.fillRect(left,sim.groundY,right-left,bottom-sim.groundY+100);ctx.fillStyle='#85928f';ctx.fillRect(left,sim.groundY,right-left,3);ctx.fillStyle='#414c50';ctx.fillRect(left,sim.groundY+3,right-left,11);
    ctx.strokeStyle='#222d34';ctx.lineWidth=2;for(let x=Math.floor(left/35)*35;x<right;x+=35){ctx.beginPath();ctx.moveTo(x,sim.groundY+15);ctx.lineTo(x+22,sim.groundY+37);ctx.stroke();}
    ctx.strokeStyle='#465357';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,sim.groundY+38);ctx.lineTo(right,sim.groundY+38);ctx.stroke();
    for(const x of [0,2600]){ctx.fillStyle='#3d494e';ctx.fillRect(x-8,-7450,16,8100);} /* the walls go up as far as the chamber does: there is no ceiling */
    if(set.decals)for(const st of sim.stains){if(st.x+st.r<left||st.x-st.r>right)continue;
      if(st.hole){ctx.fillStyle='#16191b';ctx.beginPath();ctx.arc(st.x,st.y,1.6,0,7);ctx.fill();ctx.strokeStyle='#6c7275';ctx.lineWidth=.6;ctx.beginPath();ctx.arc(st.x,st.y,2.6,0,7);ctx.stroke();continue;} /* a pock in the floor or a wall */
      if(st.puddle){const f=clamp((14-st.age)/5,0,1),r=st.r*(.6+.4*f);ctx.globalAlpha=f;ctx.fillStyle='rgba(120,168,210,.22)';ctx.beginPath();ctx.ellipse(st.x,st.y+.6,r,1.3,0,0,7);ctx.fill();ctx.strokeStyle='rgba(225,242,255,.35)';ctx.lineWidth=.6;ctx.beginPath();ctx.moveTo(st.x-r*.7,st.y-.2);ctx.lineTo(st.x+r*.4,st.y-.2);ctx.stroke();ctx.globalAlpha=1;continue;} /* a thin sheet of water catching the light along its top; it shrinks and fades as it dries */
      if(st.scorch||st.frost){const img=st.frost?glowSprite('frost','214,238,255',1):glowSprite('scorch','11,13,14',1);ctx.globalAlpha=(st.frost?.75*clamp(1-(st.age||0)/10,0,1):.8)*(st.a??1);if(st.wall)ctx.drawImage(img,st.x-3.5,st.y-st.r,7,st.r*2);else ctx.drawImage(img,st.x-st.r,st.y-(st.frost?2.5:3.5),st.r*2,st.frost?5:7);ctx.globalAlpha=1;continue;} /* a scorch darkens as it builds (a); frost fades over ten seconds */
      if(set.noGore&&!st.oil)continue;const wet=st.wet||0,fade=set.stainLifetime?clamp((set.stainLifetime-(st.age||0))/8,0,1):1;ctx.globalAlpha=.9*fade;ctx.fillStyle=stainColor(wet,st.oil);ctx.beginPath();
      if(st.smear){const len=st.to-st.from,t=st.thick||2; /* a wiped streak: a flat band with ragged, thinning ends and a few dry drag lines through it */ ctx.ellipse(st.x,st.y,len/2+2,t,0,0,7);ctx.fill();ctx.globalAlpha*=.55;ctx.strokeStyle=stainColor(Math.max(0,wet-.35),st.oil);ctx.lineWidth=.6;for(let k=0;k<3;k++){const a=st.from+len*hash(st.from+k*3.3)*.4,b2=st.to-len*hash(st.to+k*1.7)*.4,yy=st.y-t*.6+k*t*.55;ctx.beginPath();ctx.moveTo(a,yy);ctx.lineTo(b2,yy);ctx.stroke();}continue;}
      if(st.wall){ctx.ellipse(st.x,st.y,2.6,st.r,0,0,7);ctx.fill();ctx.fillRect(st.x-.8,st.y,1.6,st.r*(2.2-wet)*1.4);} // a run down the wall that lengthens as it dries
      else{const ry=Math.min(4.2,1.4+st.r*.07);ctx.ellipse(st.x,st.y,st.r,ry,0,0,7);ctx.fill();}
    }ctx.globalAlpha=1;
    fillers.clear();for(const c of sim.joints){if(c.plugin.joint){fillers.set(c.bodyB,c);continue;}if(c.plugin.pierce||c.plugin.hold)continue;const a=Constraint.pointAWorld(c),b=Constraint.pointBWorld(c),wire=c.plugin.wire,live=wire&&sim.time-(c.plugin.liveAt??-9)<.25;
      ctx.strokeStyle=wire?'#2e3a42':'#c8b889';ctx.lineWidth=wire?2.5:2;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();
      if(live){ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle='rgba(120,200,255,.5)';ctx.lineWidth=5;ctx.stroke();ctx.strokeStyle='rgba(240,250,255,.95)';ctx.lineWidth=1.2;ctx.stroke();ctx.restore();} /* current in it: the insulation glows from inside */
      ctx.fillStyle=wire?(live?'#dff3ff':'#b4762f'):'#d0c6aa';for(const p of [a,b]){ctx.beginPath();ctx.arc(p.x,p.y,3,0,7);ctx.fill();}}
    // A lodged blade is drawn first, so the body hides the part inside it and the point shows out the far side.
    // Profile bodies are layered: lodged blades, far arm and leg, objects, trunk and head, near leg and arm, things in the near hand. The sort is stable, so parts keep their order within a layer.
    drawList.length=0;for(const b of sim.bodies)drawList.push(b);drawList.sort((a,b)=>BodyArt.layer(a.plugin)-BodyArt.layer(b.plugin));
    for(const b of drawList){const p=b.plugin;if(b.bounds.max.x<left||b.bounds.min.x>right||b.bounds.max.y<top||b.bounds.min.y>bottom)continue;
      // Contact shadow anchors objects in the chamber.
      if(set.shadows&&b.position.y>520){ctx.fillStyle='#10191d30';ctx.beginPath();ctx.ellipse(b.position.x,sim.groundY-1,Math.max(5,(p.w||p.r*2||20)*.5),3,0,0,7);ctx.fill();}
      {const c=fillers.get(b);if(c)BodyArt.filler(ctx,c,Constraint.pointAWorld(c),Constraint.pointBWorld(c));}
      ctx.save();ctx.translate(b.position.x,b.position.y);ctx.rotate(b.angle);if(p.flip)ctx.scale(-1,1);const growing=p.grow!==undefined;
      if(growing){const g=1-Math.pow(1-clamp(p.grow/(p.kind==='human'?.3:1),.02,1),3),/* a human part is full size a third of the way in: the rest of the time is flesh, then skin, closing over the bone */ax=p.flip?-p.growFrom.x:p.growFrom.x;ctx.translate(ax,p.growFrom.y);ctx.scale(g,g);ctx.translate(-ax,-p.growFrom.y);}
      if(p.kind==='human'&&p.part){const look=looks.get(p.entityId)||REMAINS;look.noGore=set.noGore;look.time=sim.time;look.char=p.char||0;if(look.breath&&(p.slot===2||p.slot===3)){ctx.save();ctx.scale(1+look.breath,1+look.breath*.5);BodyArt.draw(ctx,b,look);ctx.restore();}else BodyArt.draw(ctx,b,look);
        // for a second or two after a limb comes off, strands hang and swing from the stump
        if(!set.noGore)for(const end of p.severed||[])if(end.fresh>0){ctx.strokeStyle='#8a2830';ctx.lineWidth=.9;ctx.globalAlpha=Math.min(1,end.fresh);for(let i=-1;i<=1;i++){ctx.beginPath();ctx.moveTo(end.x+i*2.2,end.y);ctx.quadraticCurveTo(end.x+i*3+Math.sin(sim.time*9+i)*2.5,end.y+4,end.x+i*2.6+Math.sin(sim.time*7+i*2)*3.5,end.y+7+i);ctx.stroke();}ctx.globalAlpha=1;}}
      else drawObject(ctx,p.kind,p,sim.time);
      // A growing part starts raw and wet and settles into skin; a grafted body glows while the surge runs through it.
      if(growing){ctx.beginPath();ctx.roundRect(-p.w/2,-p.h/2,p.w,p.h,4);if(p.kind!=='human'){ctx.globalAlpha=(1-p.grow)*.7;ctx.fillStyle='#7fe3ff';ctx.fill();ctx.globalAlpha=1;}ctx.strokeStyle=`rgba(150,255,210,${(1-p.grow)*.3})`;ctx.lineWidth=6;ctx.stroke();ctx.strokeStyle=`rgba(190,255,230,${1-p.grow})`;ctx.lineWidth=1.5;ctx.stroke();}
      if(p.surge){const pulse=p.surge*(.65+.35*Math.sin(sim.time*40));ctx.beginPath();ctx.roundRect(-(p.w||20)/2-1,-(p.h||20)/2-1,(p.w||20)+2,(p.h||20)+2,4);ctx.strokeStyle=`rgba(120,230,255,${Math.min(.35,pulse*.35)})`;ctx.lineWidth=8;ctx.stroke();ctx.strokeStyle=`rgba(200,250,255,${Math.min(1,pulse)})`;ctx.lineWidth=2;ctx.stroke();}
      if(p.part&&p.material==='flesh'&&set.decals&&!set.noGore&&(p.wounds?.length||p.severed?.length)){let open=false; /* runs of blood down the skin from each wound, stopping at the body's edge */
        for(const list of [p.wounds,p.severed])if(list)for(const w of list){if(!(w.run>1)||w.sealed)continue;if(!open){open=true;ctx.save();if(p.flip)ctx.scale(-1,1);BodyArt.trace(ctx,p);ctx.clip();ctx.lineCap='round';}
          const wet=clamp(1-(sim.time-(w.wet??w.t??0))/30,0,1),ex=w.x+Math.cos(w.runDir)*w.run,ey=w.y+Math.sin(w.runDir)*w.run;ctx.globalAlpha=.85;ctx.strokeStyle=ctx.fillStyle=stainColor(wet);ctx.lineWidth=1.3;ctx.beginPath();ctx.moveTo(w.x,w.y);ctx.lineTo(ex,ey);ctx.stroke();if(wet>.3){ctx.beginPath();ctx.arc(ex,ey,1.1,0,7);ctx.fill();}}
        if(open){ctx.lineCap='butt';ctx.globalAlpha=1;ctx.restore();}}
      if(p.holes?.length&&set.decals){ctx.save();if(p.flip)ctx.scale(-1,1);for(const h of p.holes){ /* bullet holes: a bright dent in metal, a splintered hole in wood, a chipped pock in stone, a star in glass */
          if(h.kind==='dent'){ctx.fillStyle='#e8ecee';ctx.beginPath();ctx.arc(h.x,h.y,2.2,0,7);ctx.fill();ctx.fillStyle='#3b4246';ctx.beginPath();ctx.arc(h.x,h.y,1.1,0,7);ctx.fill();}
          else if(h.kind==='crack'){ctx.strokeStyle='#f4fbff';ctx.lineWidth=.5;ctx.beginPath();for(let k=0;k<6;k++){const an=k*1.05+hash(h.x+k),l=3+hash(h.y+k)*4;ctx.moveTo(h.x,h.y);ctx.lineTo(h.x+Math.cos(an)*l,h.y+Math.sin(an)*l);}ctx.stroke();ctx.fillStyle='#1a1f22';ctx.beginPath();ctx.arc(h.x,h.y,.9,0,7);ctx.fill();}
          else if(h.kind==='chip'){ctx.fillStyle='#8a8d8f';ctx.beginPath();ctx.arc(h.x,h.y,2.4,0,7);ctx.fill();ctx.fillStyle='#2d3033';ctx.beginPath();ctx.arc(h.x,h.y,1.2,0,7);ctx.fill();}
          else{ctx.fillStyle='#1b1410';ctx.beginPath();ctx.arc(h.x,h.y,h.exit?1.8:1.2,0,7);ctx.fill();ctx.strokeStyle='#e0c28e';ctx.lineWidth=.5;ctx.beginPath();for(let k=0;k<4;k++){const an=k*1.57+hash(h.x*2+k)*.8;ctx.moveTo(h.x+Math.cos(an)*1.2,h.y+Math.sin(an)*1.2);ctx.lineTo(h.x+Math.cos(an)*3,h.y+Math.sin(an)*3);}ctx.stroke();}}ctx.restore();}
      if(p.stains?.length&&set.decals){ctx.save();if(p.flip)ctx.scale(-1,1);if(p.part&&p.material==='flesh')BodyArt.trace(ctx,p);else{ctx.beginPath();if(p.r)ctx.arc(0,0,p.r,0,7);else ctx.roundRect(-(p.w||24)/2,-(p.h||24)/2,p.w||24,p.h||24,3);}ctx.clip(); /* blood on skin stops at the skin's edge */
        for(const st of p.stains){if(set.noGore&&!st.oil)continue;ctx.globalAlpha=p.part?.7:.88;ctx.fillStyle=stainColor(st.wet||0,st.oil);ctx.beginPath();ctx.ellipse(st.x,st.y,st.r*(.75+hash(st.x*3.1+st.y)*.5),st.r*(1+(1-(st.wet||0))*.6),-b.angle,0,7);ctx.fill();
          // a splat, not a dot: a couple of satellite droplets thrown off it, placed by where it landed
          for(let k=0;k<2;k++){const a=hash(st.x+st.y*2.3+k)*6.28,d=st.r*(1.5+hash(st.y+k*5)*1.2);ctx.beginPath();ctx.arc(st.x+Math.cos(a)*d,st.y+Math.sin(a)*d,st.r*.28,0,7);ctx.fill();}}ctx.restore();} // they sag downward as they dry: the long axis stays vertical in the world
      {const soak=1-(sim.time-(p.soakedAt??-99))/8;if(soak>0){ctx.save();if(p.part&&p.material==='flesh'){if(p.flip)ctx.scale(-1,1);BodyArt.trace(ctx,p);}else{ctx.beginPath();if(p.r)ctx.arc(0,0,p.r,0,7);else ctx.roundRect(-(p.w||24)/2,-(p.h||24)/2,p.w||24,p.h||24,3);}ctx.clip();ctx.fillStyle=`rgba(20,40,60,${.16*soak})`;ctx.fillRect(-80,-80,160,160);ctx.restore();}} /* wet: a shade darker, drying over eight seconds */
      if(p.splint){ctx.save();if(p.flip)ctx.scale(-1,1);const w=(p.w||10)+1.2,h=Math.min(p.h*.55,22);ctx.fillStyle='#ebe5d6';ctx.fillRect(-w/2,-h/2,w,h);ctx.strokeStyle='rgba(120,108,88,.55)';ctx.lineWidth=.5;ctx.beginPath();for(let y=-h/2+2.5;y<h/2;y+=3){ctx.moveTo(-w/2,y);ctx.lineTo(w/2,y-1.2);}ctx.stroke();ctx.restore();} /* a splint: a wrap of bandage round the middle of the broken limb until the bone has knit */
      if(p.heat<0){const frost=Math.min(1,p.heat/-30);ctx.save();if(p.part&&p.material==='flesh'){if(p.flip)ctx.scale(-1,1);BodyArt.trace(ctx,p);}else{ctx.beginPath();if(p.r)ctx.arc(0,0,p.r,0,7);else ctx.roundRect(-(p.w||24)/2,-(p.h||24)/2,p.w||24,p.h||24,3);}ctx.clip();ctx.fillStyle=`rgba(186,224,255,${.2+.4*frost})`;ctx.fillRect(-60,-60,120,120);
        if(frost>=1){ctx.strokeStyle='rgba(240,250,255,.8)';ctx.lineWidth=.6;ctx.beginPath();for(let k=0;k<4;k++){const fx=(hash(b.id+k*3.1)-.5)*(p.w||20)*.7,fy=(hash(b.id*1.7+k)-.5)*(p.h||20)*.7;for(let a=0;a<3;a++){const ang=a*Math.PI/3+hash(b.id+k);ctx.moveTo(fx-Math.cos(ang)*2.4,fy-Math.sin(ang)*2.4);ctx.lineTo(fx+Math.cos(ang)*2.4,fy+Math.sin(ang)*2.4);}}ctx.stroke();}ctx.restore();} /* frozen solid, ice crystals stand on it */
      if(p.char&&p.kind!=='human'){ctx.fillStyle=`rgba(14,11,9,${Math.min(.8,p.char*.85)})`;ctx.beginPath();if(p.r)ctx.arc(0,0,p.r,0,7);else ctx.roundRect(-(p.w||24)/2,-(p.h||24)/2,p.w||24,p.h||24,2);ctx.fill();}
      if(p.heat>100&&p.kind!=='human'){ctx.fillStyle=`rgba(219,99,49,${Math.min(.55,(p.heat-100)/1000)})`;ctx.fillRect(-(p.w||24)/2,-(p.h||24)/2,p.w||24,p.h||24);}
      if(b.isStatic){ctx.fillStyle='#acd4e9';ctx.fillRect(-2,-2,4,4);}
      if(p.charge>.05){ /* a charged body crawls with arcs: two or three that run from one point on its edge to another, new ones thirty times a second, dying away with the charge */
        const tick=Math.floor(sim.time*30),hw=(p.w||p.r*2||20)/2,hh=(p.h||p.r*2||20)/2,edge=k=>{const u=hash(tick*1.9+b.id*.37+k*5.1)*4,v=(u%1)*2-1;return u<1?{x:v*hw,y:-hh}:u<2?{x:hw,y:v*hh}:u<3?{x:v*hw,y:hh}:{x:-hw,y:v*hh};},arcs=[];
        for(let k=0;k<(p.part?(p.charge>.6?2:1):(p.charge>.5?3:2));k++)arcs.push(jagged(edge(k),edge(k+9),.5,3,tick+k*17+b.id));const crawl=pathOf(arcs),reach=Math.max(hw,hh)+14;ctx.lineJoin='round';ctx.lineCap='round';ctx.globalCompositeOperation='lighter';
        ctx.globalAlpha=(p.part?.06:.28)*Math.min(1,p.charge);/* a ragdoll is seventeen parts, and light adds up */ctx.drawImage(glowSprite('arcGlow','150,215,255',.6),-reach,-reach,reach*2,reach*2);ctx.globalAlpha=1;stroke(crawl,p.part?2.4:3.2,`rgba(110,190,255,${(p.part?.2:.32)*Math.min(1,p.charge)})`);stroke(crawl,1,`rgba(238,250,255,${Math.min(1,p.charge*1.3)})`);ctx.globalCompositeOperation='source-over';ctx.lineCap='butt';}
      ctx.restore();
    }
    ctx.globalCompositeOperation='lighter';for(const b of sim.bodies)if(b.plugin.burning&&b.bounds.max.x>left&&b.bounds.min.x<right)fireGlow(b);drawFire(state.paused?0:frameDt*state.speed,left,right);ctx.globalCompositeOperation='source-over';
    let water=false;if(set.particles!=='Off')for(let i=0;i<sim.particles.length;i++){const p=sim.particles[i];if((set.particles==='Low'&&i%2)||(set.noGore&&p.type==='blood'))continue;const age=1-clamp(p.life/p.maxLife,0,1);
      if(p.type==='smoke'){const r=p.size*(1+2.2*age);ctx.globalAlpha=1-age;ctx.drawImage(glowSprite('smoke','38,38,40',.36),p.x-r,p.y-r,r*2,r*2);ctx.globalAlpha=1;continue;}
      if(p.type==='mist'){const r=p.size*(1+1.4*age);ctx.globalAlpha=(1-age)*.5;ctx.drawImage(glowSprite('mist','205,232,255',.4),p.x-r,p.y-r,r*2,r*2);ctx.globalAlpha=1;continue;}
      if(p.type==='ice'){ctx.globalAlpha=1-age*age;ctx.fillStyle='#f2fbff';ctx.beginPath();ctx.moveTo(p.x,p.y-p.size);ctx.lineTo(p.x+p.size*.6,p.y);ctx.lineTo(p.x,p.y+p.size);ctx.lineTo(p.x-p.size*.6,p.y);ctx.closePath();ctx.fill();ctx.globalAlpha=1;continue;}
      if(p.type==='plus'){ctx.globalAlpha=(1-age)*.9;ctx.fillStyle=p.color;const a=p.size,t=p.size*.34;ctx.fillRect(p.x-a,p.y-t,a*2,t*2);ctx.fillRect(p.x-t,p.y-a,t*2,a*2);ctx.globalAlpha=1;continue;}
      if(p.type==='water'||p.type==='splash'){water=true;continue;} /* drawn together below, in one stroke */
      if(p.type==='ember'){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=1-age*age;ctx.fillStyle=age<.5?'#ffd98a':'#ff8a3c';ctx.fillRect(p.x-p.size/2,p.y-p.size/2,p.size,p.size);ctx.globalCompositeOperation='source-over';ctx.globalAlpha=1;continue;}
      ctx.globalAlpha=1-age;ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(p.x,p.y,p.size*.8,0,7);ctx.fill();}ctx.globalAlpha=1;
    if(water){ /* every falling drop is a short streak along its path, all of them one path and one stroke; splash droplets are dots */ctx.strokeStyle='rgba(140,196,245,.72)';ctx.lineWidth=1.8;ctx.lineCap='round';ctx.beginPath();ctx.fillStyle='rgba(190,225,252,.8)';
      for(let i=0;i<sim.particles.length;i++){const p=sim.particles[i];if(set.particles==='Low'&&i%2)continue;if(p.type==='water'){const sp=Math.hypot(p.vx,p.vy)||1,l=Math.min(11,2+sp*1.1);ctx.moveTo(p.x-p.vx/sp*l,p.y-p.vy/sp*l);ctx.lineTo(p.x,p.y);}else if(p.type==='splash')ctx.fillRect(p.x-p.size/2,p.y-p.size/2,p.size,p.size);}ctx.stroke();ctx.strokeStyle='rgba(150,205,250,.14)';ctx.lineWidth=5;ctx.stroke();ctx.lineCap='butt';} /* and once more, wide and faint: the drops read as water, not wire */
    for(const f of sim.flashes){const t=1-f.life/f.maxLife;if(f.muzzle){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=1-t;ctx.drawImage(glowSprite('muzzle','255,210,130',.9),f.x-f.radius,f.y-f.radius,f.radius*2,f.radius*2);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';continue;} /* a muzzle flash: a hot bloom, no ring */if(f.grow||f.surge){const tint=f.grow?'150,255,205':'130,235,255';for(const lag of f.surge?[]:[0]){ // the graft surge has no ring: just the core flash, arcs and sparks
      const k=clamp(t-lag,0,1);if(!k)continue;ctx.strokeStyle=`rgba(${tint},${(1-k)*.9})`;ctx.lineWidth=(f.surge?7:3)*(1-k)+1;ctx.beginPath();ctx.arc(f.x,f.y,f.radius*(1-Math.pow(1-k,3)),0,7);ctx.stroke();ctx.strokeStyle=`rgba(${tint},${(1-k)*.18})`;ctx.lineWidth*=3.5;ctx.stroke();}const core=ctx.createRadialGradient(f.x,f.y,0,f.x,f.y,f.radius*.6);core.addColorStop(0,`rgba(255,255,255,${(1-t)*(f.surge?.7:.35)})`);core.addColorStop(1,`rgba(${tint},0)`);ctx.fillStyle=core;ctx.beginPath();ctx.arc(f.x,f.y,f.radius*.6,0,7);ctx.fill();continue;}ctx.strokeStyle=`rgba(236,192,116,${1-t})`;ctx.lineWidth=5*(1-t)+1;ctx.beginPath();ctx.arc(f.x,f.y,f.radius*t,0,7);ctx.stroke();const gradient=ctx.createRadialGradient(f.x,f.y,0,f.x,f.y,Math.max(1,f.radius*t));gradient.addColorStop(0,`rgba(255,220,156,${(1-t)*.55})`);gradient.addColorStop(1,'rgba(226,133,62,0)');ctx.fillStyle=gradient;ctx.fill();}
    for(const t of sim.traces){if(t.laser){const k=t.life/t.maxLife;ctx.globalCompositeOperation='lighter';ctx.lineCap='round';ctx.strokeStyle=`rgba(255,40,30,${.35*k})`;ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(t.from.x,t.from.y);ctx.lineTo(t.to.x,t.to.y);ctx.stroke();ctx.strokeStyle=`rgba(255,120,100,${.8*k})`;ctx.lineWidth=1.8;ctx.stroke();ctx.strokeStyle=`rgba(255,245,240,${k})`;ctx.lineWidth=.7;ctx.stroke();ctx.lineCap='butt';ctx.globalCompositeOperation='source-over';continue;} /* an eye beam: a red glow, a hot core */
      if(t.bolt)continue;if(t.electric){drawElectric(t);continue;}if(!set.tracers)continue;ctx.globalAlpha=t.life/t.maxLife;ctx.strokeStyle='#f0cd84';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(t.from.x,t.from.y);ctx.lineTo(t.to.x,t.to.y);ctx.stroke();}ctx.globalAlpha=1;
    if(sim.drag){ctx.strokeStyle='#cbb78588';ctx.lineWidth=1;const p=Constraint.pointBWorld(sim.drag);ctx.beginPath();ctx.moveTo(sim.drag.pointA.x,sim.drag.pointA.y);ctx.lineTo(p.x,p.y);ctx.stroke();}
    if(state.graftStump&&sim.bodies.includes(state.graftStump)){const g=state.graftStump.position,pulse=10+Math.sin(sim.time*9)*3;ctx.strokeStyle='#8fe9ff';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(g.x,g.y,pulse+8,0,7);ctx.stroke();ctx.setLineDash([5,5]);ctx.beginPath();ctx.moveTo(g.x,g.y);ctx.lineTo(state.worldPointer.x,state.worldPointer.y);ctx.stroke();ctx.setLineDash([]);}
    if(state.ropeStart){ctx.strokeStyle='#dec58e';ctx.lineWidth=2;ctx.setLineDash([5,5]);ctx.beginPath();ctx.moveTo(state.ropeStart.point.x,state.ropeStart.point.y);ctx.lineTo(state.worldPointer.x,state.worldPointer.y);ctx.stroke();ctx.setLineDash([]);}
    if(state.inside&&state.spawn&&!state.down&&!Sandbox.defs[state.spawn]?.power){ctx.save();ctx.globalAlpha=.3;ctx.translate(state.worldPointer.x,state.worldPointer.y);ctx.rotate(state.rotation);if(state.spawn==='human'||state.spawn==='android'||Sandbox.defs[state.spawn]?.ragdoll){Sandbox.ANATOMY.map((row,slot)=>[...row,slot]).sort((a,b)=>BodyArt.layer({part:a[0],slot:a[5]})-BodyArt.layer({part:b[0],slot:b[5]})).forEach(([part,x,y,w,h,slot])=>{ctx.save();ctx.translate(x,y);drawObject(ctx,state.spawn,{part,slot,w,h,hp:100});ctx.restore();});}else drawObject(ctx,state.spawn);ctx.restore();}
    if(state.inside&&['blast','fire','water','cold','shock','heal','revive','wake','painless','knockout','partial','regrow','reattach','graft','undress','dismember'].includes(state.tool)){const power=POWERS.includes(state.tool);ctx.strokeStyle=state.tool==='blast'?'#e3b07966':power?POWER_RING[state.tool]:'#c6d9d977';ctx.lineWidth=1/camera.zoom;ctx.setLineDash([4,5]);ctx.beginPath();ctx.arc(state.worldPointer.x,state.worldPointer.y,state.tool==='blast'?175:power?sim.powerRadius(state.tool):24,0,7);ctx.stroke();ctx.setLineDash([]);} /* for a power the ring is its real reach */
    if(sim.power)drawPower(sim.power,state.paused?0:frameDt*state.speed);
    for(const e of sim.entities){if(!e.conduit||!e.alive||!(e.power>2))continue;const head=e.bodies.find(b=>b.plugin.slot===0);if(!head)continue;const p=head.plugin,face=p.flip?-1:1,eye=Vector.add(head.position,Vector.rotate({x:face*p.w*.25,y:-p.h*.05},head.angle)),firing=sim.time-(e.laserAt??-9)<.1,over=Math.min(1,Math.max(0,e.power-100)/400),k=Math.min(1,e.power/60),r=(firing?20:8+k*10+over*9)*(0.9+.1*hash(Math.floor(sim.time*20)));
      ctx.globalCompositeOperation='lighter';ctx.globalAlpha=firing?1:.35+.65*k;ctx.drawImage(glowSprite(firing?'eyeRed':'eyeBlue',firing?'255,70,50':'120,220,255',.9),eye.x-r,eye.y-r,r*2,r*2);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';} /* his eyes glow with the charge he carries, red when they fire */
    if(!set.floodlights)darkness();
    ctx.restore();weather();
    // Gentle edge falloff adds depth without obscuring the simulation.
    if(set.vignette){const vignette=ctx.createRadialGradient(width/2,height/2,Math.min(width,height)*.25,width/2,height/2,Math.max(width,height)*.7);vignette.addColorStop(0,'#101a2000');vignette.addColorStop(1,'#101a2044');ctx.fillStyle=vignette;ctx.fillRect(0,0,width,height);}
    // A strike lights the sky, brightest around the channel, and the channel itself is drawn last so rain, fog and the dark never bury it.
    for(const t of sim.traces){if(!t.bolt)continue;const light=strokeLight(t);if(light<.02)continue;const x=(t.to.x-camera.x)*camera.zoom+width/2,reach=Math.max(width,height)*1.3;ctx.globalAlpha=Math.min(1,light);ctx.drawImage(glowSprite('sky','195,215,255',.55),x-reach,height*.3-reach,reach*2,reach*2);ctx.globalAlpha=Math.min(.12,light*.1);ctx.fillStyle='#b4c8ff';ctx.fillRect(0,0,width,height);ctx.globalAlpha=1;
      ctx.save();ctx.translate(width/2,height/2);ctx.scale(camera.zoom,camera.zoom);ctx.translate(-camera.x,-camera.y);drawElectric(t);ctx.restore();}
  }
  const spawned=[];
  function place(point,flip=false){if(grantAt(point))return;const e=sim.spawn(state.spawn,point.x,point.y,flip);if(!e){toast('Chamber is full — delete some objects first.');return;}if(state.rotation){const center={x:point.x,y:point.y};for(const b of e.bodies)Body.rotate(b,state.rotation,center);}spawned.push(e);if(spawned.length>50)spawned.shift();sound('impact',.1);}
  // Powers. While the button is held the power is in the world at the cursor: sim.power = {kind,x,y,px,py}. This file only puts it there, moves it and draws it; the engine applies it in its step (so not while paused).
  const POWERS=['fire','water','cold','shock','heal'];
  function startPower(point,e){const body=sim.bodyAt(point);
    if(state.tool==='heal'){if(body?.plugin.part)select(body);if(e.altKey&&body){sim.heal(body);toast('Fully healed');return;}} /* Option/Alt + click: the old one-click heal of the whole ragdoll. Shift is taken - it pans */
    sim.power={kind:state.tool,x:point.x,y:point.y,px:point.x,py:point.y};}
  function perform(point,continuous=false){const body=sim.bodyAt(point);
    switch(state.tool){case'grab':if(!continuous){select(body);if(body){sim.beginDrag(body,point);canvas.style.cursor='grabbing';}}break;
      case'rope':if(!continuous){if(!state.ropeStart){state.ropeStart={body,point:{...point}};toast(state.ropeKind==='wire'?'Choose the other end of the wire.':'Choose the other end of the rope.');}else{const a=state.ropeStart;if(!a.body&&!body){toast('At least one end must attach to an object.');}else{const c=sim.rope(a.body,body,a.point,point,state.ropeKind==='wire');if(c)spawned.push({rope:c});toast(state.ropeKind==='wire'?'Wire connected':'Rope connected');}state.ropeStart=null;}}break;
      case'freeze':if(!continuous&&body){select(body);toast(sim.freeze(body)?'Body locked':'Body released');}break;
      // Point blank: the shot starts just outside whatever is under the cursor, so it hits that and not the first thing on a long line from the left.
      case'shoot':if(performance.now()-lastShot>120){const from={x:(body?body.bounds.min.x:point.x)-8,y:point.y-1};sim.shoot(from,{x:from.x+100,y:point.y+.5});lastShot=performance.now();}break;
      case'blast':if(!continuous)sim.explode(point.x,point.y);break;
      case'revive':if(body&&!continuous){toast(sim.revive(body)?'Revived':'Only humans and androids can be revived');select(body);}break;
      case'clot':if(body&&!continuous){const n=sim.stopBleeding(body);toast(n?'Bleeding stopped':'Nothing is bleeding');select(body);}break;
      case'bandage':if(body&&!continuous){const had=!!body.plugin.splint,n=sim.bandage(body),splint=!had&&!!body.plugin.splint,w=n-(splint?1:0);toast(splint?(w?`Splinted the fracture and bandaged ${w} wound${w>1?'s':''}`:'Splinted the fracture: the bone knits within a minute'):n?`Bandaged ${n} wound${n>1?'s':''}`:'No open wound or fracture on that part');select(body);}break;
      case'tourniquet':if(body&&!continuous){toast(sim.tourniquet(body));select(body);}break;
      case'stitch':if(body&&!continuous){toast(sim.stitch(body,point));select(body);}break;
      case'wake':if(body&&!continuous){toast(sim.wake(body)?'Awake':'Only a living human can be woken');select(body);}break;
      case'painless':if(body&&!continuous){const on=sim.painkill(body);toast(on===null?'Only a human feels pain':on?'Pain switched off':'Pain switched back on');select(body);}break;
      case'knockout':if(body&&!continuous){toast(sim.knockOut(body)?'Knocked out':'Only a living human can be knocked out');select(body);}break;
      case'partial':if(body&&!continuous){toast(sim.partialRevive(body)?'Revived, wounds and all':'Only humans and androids can be revived');select(body);}break;
      case'regrow':if(body&&!continuous){const n=sim.regenerate(body);toast(n?`Regrowing ${n} part${n>1?'s':''}…`:body.plugin.part?'Nothing is missing':'Only ragdolls regrow');}break;
      case'reattach':if(body&&!continuous){const n=sim.reattach(body);toast(n?`Reattached ${n} piece${n>1?'s':''}`:body.plugin.part?'Nothing to reattach here — the place may already be taken':'Only ragdoll parts reattach');}break;
      case'graft':if(!continuous){if(!body?.plugin.part){state.graftStump=null;toast('Click a ragdoll part to build on.');}else if(!state.graftStump||!sim.bodies.includes(state.graftStump)){state.graftStump=body;toast('Now click the loose limb to graft on.');}
        else{const problem=sim.graft(state.graftStump,body);toast(problem||'Grafted. Power surge!');state.graftStump=null;}}break;
      case'undress':if(body&&!continuous)toast(sim.undress(body,point));break;
      case'dismember':if(body&&!continuous){const cut=sim.dismember(body);toast(cut?`Severed at the ${cut}`:body.plugin.part?'Nothing left to cut there':'Only ragdoll limbs come off');}break;
      case'delete':if(body){sim.removeEntity(body);select(null);}break;
    }
  }
  const trail=[]; // the last few cursor positions with their times, for the throw
  function throwVelocity(){const now=performance.now(),recent=trail.filter(t=>now-t.t<90);if(recent.length<2)return null;const a=recent[0],b=recent[recent.length-1],ms=Math.max(8,b.t-a.t);return {x:(b.x-a.x)/ms*16.67,y:(b.y-a.y)/ms*16.67};}
  function pointer(e){const r=canvas.getBoundingClientRect();state.pointer={x:e.clientX-r.left,y:e.clientY-r.top};state.worldPointer=toWorld(state.pointer);$('#coordinates').textContent=`x ${Math.round(state.worldPointer.x)} : y ${Math.round(state.worldPointer.y)}`;trail.push({x:state.worldPointer.x,y:state.worldPointer.y,t:performance.now()});if(trail.length>8)trail.shift();return state.worldPointer;}
  canvas.addEventListener('pointerdown',e=>{if(e.button!==0&&e.button!==1&&e.button!==2)return;canvas.focus();canvas.setPointerCapture(e.pointerId);pointer(e);state.inside=true;if(e.button===2||e.button===1||state.shift){state.pan={x:e.clientX,y:e.clientY,cx:camera.x,cy:camera.y};canvas.style.cursor='grabbing';return;}if(e.button===0&&grantAt(state.worldPointer))return;state.down=true;if(POWERS.includes(state.tool))startPower(state.worldPointer,e);else perform(state.worldPointer);});
  canvas.addEventListener('pointermove',e=>{pointer(e);state.inside=true;if(sim.power){sim.power.x=state.worldPointer.x;sim.power.y=state.worldPointer.y;}if(state.pan){camera.x=state.pan.cx-(e.clientX-state.pan.x)/camera.zoom;camera.y=state.pan.cy-(e.clientY-state.pan.y)/camera.zoom;return;}if(sim.drag){const body=sim.drag.bodyB,target=Vector.sub(state.worldPointer,sim.drag.pointB);if(state.paused)sim.translateConnected(body,Vector.sub(target,body.position));else if(body.isStatic)Body.setPosition(body,target);sim.moveDrag(state.worldPointer);}});
  function release(){state.down=false;state.pan=null;sim.power=null;sim.endDrag(); /* no throw is computed: what is let go keeps the velocity the pull gave it */canvas.style.cursor=state.tool!=='grab'?'crosshair':'grab';}
  canvas.addEventListener('pointerup',release);canvas.addEventListener('pointercancel',release);canvas.addEventListener('lostpointercapture',release);canvas.addEventListener('pointerleave',()=>state.inside=false);window.addEventListener('blur',()=>{release();state.shift=false;held.clear();});
  canvas.addEventListener('contextmenu',e=>e.preventDefault());canvas.addEventListener('dblclick',e=>{const b=sim.bodyAt(pointer(e));if(b&&state.tool==='grab')toast(sim.activate(b));});
  function zoom(factor,p={x:width/2,y:height/2}){const before=toWorld(p);camera.zoom=clamp(camera.zoom*factor,.2,3);const after=toWorld(p);camera.x+=before.x-after.x;camera.y+=before.y-after.y;updateZoom();}
  canvas.addEventListener('wheel',e=>{e.preventDefault();pointer(e);zoom(Math.exp(-e.deltaY*.0015*sim.settings.zoomSensitivity),state.pointer);},{passive:false});
  function setPaused(value){state.paused=value;$('#play-btn').textContent=value?'▶':'Ⅱ';$('#play-btn').setAttribute('aria-label',value?'Play simulation':'Pause simulation');$('#pause-overlay').hidden=!value;$('#simulation-badge').innerHTML=`<i style="background:${value?'#cfb27c':'#91bba6'}"></i> ${value?'Simulation paused':'Simulation live'}`;$('#step-btn').disabled=!value;}
  function loadPreset(name){sim.loadPreset(name);state.selected=null;state.ropeStart=null;$('#scene-name').textContent=$('#scene-select').selectedOptions[0].textContent;reflectSettings();setPaused(false);fit();updateSelection();}
  $('#play-btn').onclick=()=>setPaused(!state.paused);$('#step-btn').onclick=()=>{if(state.paused)sim.step();};
  document.querySelectorAll('[data-speed]').forEach(b=>b.onclick=()=>setSpeed(Number(b.dataset.speed)));
  $('#gravity').onchange=e=>{if(e.target.value==='custom')return;applySettings({gravity:Number(e.target.value)*9.81});toast(e.target.selectedOptions[0].textContent+' gravity');};
  $('#sound-btn').onclick=()=>{applySettings({sound:!sim.settings.sound});if(sim.settings.sound)sound('impact',.2);};
  $('#zoom-in').onclick=()=>zoom(1.2);$('#zoom-out').onclick=()=>zoom(1/1.2);$('#zoom-reset').onclick=fit;
  $('#scene-select').onchange=e=>loadPreset(e.target.value);$('#reset-btn').onclick=()=>{loadPreset($('#scene-select').value);toast('Scene reset');};$('#clear-btn').onclick=()=>{sim.clear();select(null);state.ropeStart=null;toast('Chamber cleared');};
  $('#clear-fire-btn').onclick=()=>{const n=sim.clearFire();toast(n?`Put out ${n} fire${n>1?'s':''}`:'Nothing is burning');};
  $('#clear-dead-btn').onclick=()=>{const n=sim.clearDead();select(null);toast(n?'Cleared the dead and the debris':'Nothing dead to clear');};
  $('#clear-objects-btn').onclick=()=>{const n=sim.clearObjects();select(null);toast(n?`Cleared ${n} object${n>1?'s':''}; ragdolls stay`:'No objects to clear');};
  $('#save-btn').onclick=()=>{try{const data=sim.serialize();localStorage.setItem('sandbox-lab-scene',JSON.stringify({...data,camera:{...camera},savedAt:new Date().toISOString()}));toast('Scene saved on this device');}catch{toast('Could not save. Browser storage may be full or disabled.');}};
  $('#load-btn').onclick=()=>{try{const raw=localStorage.getItem('sandbox-lab-scene');if(!raw){toast('No saved scene yet. Build something and save it first.');return;}const data=JSON.parse(raw);sim.restore(data);state.selected=null;state.ropeStart=null;if(data.camera&&[data.camera.x,data.camera.y,data.camera.zoom].every(Number.isFinite))Object.assign(camera,data.camera);$('#scene-select').value=sim.scene;$('#scene-name').textContent='Saved experiment';applySettings({});setPaused(true);updateZoom();toast('Scene loaded — paused so you can pick up where you left off.');}catch{toast('Could not load this saved scene. Your current scene was kept if validation failed.');}};
  // ---- Settings. The page is generated from the engine's SETTINGS table, so adding a row there adds a control here.
  const {SETTINGS}=Sandbox,STORE='sandbox-lab-settings',DEFAULTS=Sandbox.defaults(),GAMEPLAY=['World','Ragdolls','Gore','Weapons','Physics'];
  const PRESETS=[
    {name:'Default',note:'Everything as shipped',values:{}},
    {name:'Realistic',note:'Fragile bodies, long knockdowns, slow healing',values:{fragility:1.6,bleedRate:1.5,stunScale:1.8,getUpTime:2.4,brainDamage:true,slowHealing:true,limbCrush:true,jointStrength:.8,bulletDamage:80}},
    {name:'Glass dolls',note:'A stiff breeze takes a limb off',values:{fragility:6,jointStrength:.3,limbCrush:true,crushSensitivity:300,extraGunshot:true,stunScale:2}},
    {name:'Invincible',note:'Nearly unbreakable, never bleeds out',values:{fragility:.1,jointStrength:5,bleedRate:0,stunScale:.3,getUpTime:.4,legStrength:3.5}},
    {name:'Moon base',note:'Low gravity, no air',values:{gravity:1.62,airDrag:0}},
    {name:'Thunderstorm',note:'Dark, wet and dangerous',values:{rain:true,fog:true,floodlights:false,lightning:45,ambient:8}},
    {name:'Blizzard',note:'Frozen, brittle and slippery',values:{snow:true,fog:true,ambient:-60}},
    {name:'Overkill',note:'Everything hits four times harder',values:{bulletDamage:220,bulletForce:4,explosionPower:3,pierceSpeed:2,limbCrush:true,extraGunshot:true}}
  ];
  const format=(item,value)=>item.type!=='range'?String(value):(+value.toFixed(item.step<.1?2:item.step<1?1:0))+item.unit;
  function applySettings(values){sim.configure(values);try{localStorage.setItem(STORE,JSON.stringify({version:2,...Object.fromEntries(SETTINGS.filter(i=>sim.settings[i.id]!==i.def).map(i=>[i.id,sim.settings[i.id]]))}));}catch{/* private mode: settings last for this visit only */}reflectSettings();}
  // Everything outside the canvas that mirrors a setting.
  function reflectSettings(){const set=sim.settings;$('#fps').hidden=!set.showFps;$('#tool-caption').hidden=!set.hints;$('#sound-btn').textContent=set.sound?'Sound on':'Sound off';$('#sound-btn').setAttribute('aria-pressed',String(set.sound));
    const preset=[...$('#gravity').options].find(o=>o.value!=='custom'&&Math.abs(Number(o.value)*9.81-set.gravity)<.02);$('#gravity').value=preset?preset.value:'custom';$('#gravity-custom').textContent=`Custom (${format(SETTINGS[0],set.gravity).trim()})`;
    for(const row of document.querySelectorAll('.set-row')){const item=SETTINGS.find(i=>i.id===row.dataset.id),value=set[item.id],input=row.querySelector('.set-input');
      if(item.type==='toggle')input.setAttribute('aria-checked',String(value));else input.value=value;if(item.type==='range')row.querySelector('output').textContent=format(item,value);
      row.querySelector('.set-reset').hidden=value===item.def;row.classList.toggle('changed',value!==item.def);}
    const changed=SETTINGS.filter(i=>set[i.id]!==i.def).length;$('#settings-changed').textContent=changed?`${changed} changed from default`:'All defaults';
    for(const b of document.querySelectorAll('.preset'))b.classList.toggle('active',GAMEPLAY.every(sec=>SETTINGS.filter(i=>i.section===sec).every(i=>set[i.id]===(PRESETS[b.dataset.preset].values[i.id]??i.def))));}
  function buildSettings(){const nav=$('#settings-nav'),body=$('#settings-body'),sections=[...new Set(SETTINGS.map(i=>i.section))];
    PRESETS.forEach((preset,index)=>{const b=document.createElement('button');b.className='preset';b.dataset.preset=index;b.innerHTML=`<strong></strong><span></span>`;b.children[0].textContent=preset.name;b.children[1].textContent=preset.note;
      // A preset replaces the gameplay sections and leaves how the game looks, sounds and handles alone.
      b.onclick=()=>{applySettings({...Object.fromEntries(SETTINGS.filter(i=>GAMEPLAY.includes(i.section)).map(i=>[i.id,i.def])),...preset.values});toast(preset.name+' preset applied');};$('#settings-presets').appendChild(b);});
    for(const section of sections){const link=document.createElement('button');link.textContent=section;link.dataset.section=section;link.onclick=()=>document.getElementById('set-'+section).scrollIntoView({behavior:'smooth',block:'start'});nav.appendChild(link);
      const group=document.createElement('section');group.id='set-'+section;group.innerHTML=`<header><h3></h3><button class="section-reset">Reset section</button></header>`;group.querySelector('h3').textContent=section;
      group.querySelector('.section-reset').onclick=()=>applySettings(Object.fromEntries(SETTINGS.filter(i=>i.section===section).map(i=>[i.id,i.def])));
      for(const item of SETTINGS.filter(i=>i.section===section)){const row=document.createElement('div');row.className='set-row';row.dataset.id=item.id;row.dataset.search=(item.label+' '+item.help+' '+section).toLowerCase();
        const control=item.type==='range'?`<input class="set-input" id="s-${item.id}" type="range" min="${item.min}" max="${item.max}" step="${item.step}"><output for="s-${item.id}"></output>`:item.type==='toggle'?`<button class="set-input switch" id="s-${item.id}" role="switch" aria-checked="false"><i></i></button>`:`<select class="set-input" id="s-${item.id}">${item.options.map(o=>`<option>${o}</option>`).join('')}</select>`;
        row.innerHTML=`<div class="set-text"><label for="s-${item.id}"></label><p></p></div><div class="set-control">${control}<button class="set-reset" title="Reset to default" aria-label="Reset to default" hidden>↺</button></div>`;row.querySelector('label').textContent=item.label;row.querySelector('p').textContent=item.help;
        const input=row.querySelector('.set-input');if(item.type==='range'){input.oninput=()=>applySettings({[item.id]:Number(input.value)});input.ondblclick=()=>applySettings({[item.id]:item.def});}
        else if(item.type==='toggle')input.onclick=()=>applySettings({[item.id]:!sim.settings[item.id]});else input.onchange=()=>applySettings({[item.id]:input.value});
        row.querySelector('.set-reset').onclick=()=>applySettings({[item.id]:item.def});group.appendChild(row);}
      body.appendChild(group);}
    $('#settings-search').oninput=e=>{const query=e.target.value.trim().toLowerCase();let shown=0;for(const group of body.children){let any=false;for(const row of group.querySelectorAll('.set-row')){row.hidden=!row.dataset.search.includes(query);any||=!row.hidden;shown+=!row.hidden;}group.hidden=!any;}$('#settings-empty').hidden=shown>0;};
    body.onscroll=()=>{const current=[...body.children].filter(g=>!g.hidden&&g.offsetTop-body.scrollTop<=40).pop();for(const b of nav.children)b.classList.toggle('active',b.dataset.section===current?.id.slice(4));};
    const dialog=$('#settings-dialog');$('#settings-btn').onclick=()=>{dialog.showModal();body.onscroll();};$('#close-settings').onclick=()=>dialog.close();dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close();});
    $('#settings-reset').onclick=()=>{applySettings(DEFAULTS);toast('All settings reset');};
    $('#settings-export').onclick=()=>{const link=document.createElement('a');link.href=URL.createObjectURL(new Blob([JSON.stringify(sim.settings,null,2)],{type:'application/json'}));link.download='sandbox-lab-settings.json';link.click();URL.revokeObjectURL(link.href);};
    // An imported file is untrusted: configure() keeps only known ids with values inside their ranges.
    $('#settings-import').onchange=async e=>{const file=e.target.files[0];e.target.value='';if(!file)return;try{if(file.size>100000)throw 0;const values=JSON.parse(await file.text());if(!values||typeof values!=='object')throw 0;const kept=Object.keys(Sandbox.sanitize(values)).length;applySettings(values);toast(`Imported ${kept} settings`);}catch{toast('That file is not a settings export.');}};
  }
  buildSettings();try{const saved=JSON.parse(localStorage.getItem(STORE)||'{}');if(saved.version!==2)for(const id of ['pierceSpeed','bladeGrip','shadows'])delete saved[id]; /* version 1 stored every value, so old defaults would otherwise stick for ever */ sim.configure(saved);}catch{/* corrupt or unavailable storage: defaults */}reflectSettings();
  const help=$('#help-dialog');function showHelp(){if(!help.open)help.showModal();}$('#help-btn').onclick=showHelp;$('#more-help').onclick=showHelp;$('#close-help').onclick=()=>help.close();$('#start-btn').onclick=()=>help.close();help.addEventListener('click',e=>{if(e.target===help){const r=help.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)help.close();}});
  $('#deselect-btn').onclick=()=>select(null);$('#freeze-selection').onclick=()=>{sim.freeze(state.selected);updateSelection();};$('#activate-selection').onclick=()=>{toast(sim.activate(state.selected));updateSelection();};$('#delete-selection').onclick=()=>{sim.removeEntity(state.selected);select(null);};
  $('#search').addEventListener('input',renderCatalog);
  // Category tabs come from the item table; one with nothing in it yet is left out.
  for(const name of ['all',...Sandbox.CATEGORIES.filter(cat=>CATALOG.some(i=>i.category===cat))]){const b=document.createElement('button');b.dataset.category=name;b.textContent=name==='all'?'All':name;b.classList.toggle('active',name==='all');b.onclick=()=>{state.category=name;document.querySelectorAll('[data-category]').forEach(x=>x.classList.toggle('active',x===b));renderSubcategories();renderCatalog();};$('#categories').appendChild(b);}
  // Keys follow People Playground's defaults: A/D rotate (Q/E too while something is held), Q/E spawn facing left/right, F activate, G slow motion, S detail, Space pause, Backspace delete, Tab hides the UI, arrows pan, Z undoes a spawn.
  const held=new Set();let rotateTime=0;
  const target=()=>sim.drag?.bodyB||(state.inside&&sim.bodyAt(state.worldPointer))||state.selected;
  function setSpeed(value){state.speed=value;document.querySelectorAll('[data-speed]').forEach(el=>el.classList.toggle('active',Number(el.dataset.speed)===value));}
  window.addEventListener('keydown',e=>{
    if(e.key==='Shift')state.shift=true;if(help.open||$('#settings-dialog').open||e.ctrlKey||e.metaKey||e.altKey)return;if(['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName))return;
    const key=e.key.length===1?e.key.toLowerCase():e.key;
    if(['a','d','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(key)||(sim.drag&&(key==='q'||key==='e'))){e.preventDefault();held.add(key);return;}
    if(e.code==='Space'||key==='Tab'||key==='Backspace')e.preventDefault();if(e.repeat)return;
    const t=TOOLS.find(t=>t.key===key);if(t){setTool(t.id);return;}
    if(e.code==='Space')setPaused(!state.paused);
    else if(key==='Tab')document.body.classList.toggle('ui-hidden');
    else if(key==='Escape'){if(state.spawn)chooseSpawn(state.spawn);setTool('grab');select(null);}
    else if(key==='g'){setSpeed(state.speed===1?sim.settings.slowMotion/100:1);toast(state.speed===1?'Normal speed':'Slow motion');}
    else if(key==='f'){const b=target();if(b){const said=sim.activate(b);if(said)toast(said);held.add('f');}} /* kept down, an automatic weapon keeps firing: see heldKeys */
    else if(key==='x'){state.view=((state.view||0)+1)%3;toast(['Skin','X-ray: muscle layer, organs and fractures','X-ray: skeleton, organs and fractures'][state.view]);}
    else if(key==='s'){const b=state.inside&&sim.bodyAt(state.worldPointer);select(b&&b!==state.selected?b:null);}
    else if(key==='q'||key==='e'){if(state.spawn&&state.inside)place(state.worldPointer,key==='q');else if(!state.spawn)toast('Pick an object from the library first.');}
    else if(key==='r'){const b=target();if(b&&sim.flip(b))toast(b.plugin.part?'Turned round':'Flipped');}
    else if(key==='z'){let e;while((e=spawned.pop())&&!(e.rope?sim.joints.includes(e.rope):sim.entities.includes(e)));if(e?.rope){sim.unrope(e.rope);toast('Rope undone');}else if(e){sim.removeEntity(e.bodies[0]);select(null);toast('Spawn undone');}}
    else if(key==='Delete'||key==='Backspace'){if(state.selected){sim.removeEntity(state.selected);select(null);}}
  });window.addEventListener('keyup',e=>{if(e.key==='Shift')state.shift=false;held.delete(e.key.length===1?e.key.toLowerCase():e.key);});
  // Held keys act every frame: rotation accelerates the longer A/D is down (faster with Shift), and the grab keeps the angle on release.
  function heldKeys(seconds){if(held.has('f')&&!state.paused){const b=target();if(b)sim.activate(b,true);}
    if(!sim.drag){held.delete('q');held.delete('e');}
    const turn=(held.has('d')||held.has('e')?1:0)-(held.has('a')||held.has('q')?1:0);rotateTime=turn?rotateTime+seconds:0;
    // What turns: the held body first, then the spawn preview, then the selection.
    if(turn){const amount=turn*seconds*Math.min(6,1.2+rotateTime*3)*(state.shift?2.5:1);if(sim.drag)sim.rotate(sim.drag.bodyB,amount,state.paused);else if(state.spawn)state.rotation+=amount;else if(state.selected)sim.rotate(state.selected,amount,state.paused);}
    const px=(held.has('ArrowRight')?1:0)-(held.has('ArrowLeft')?1:0),py=(held.has('ArrowDown')?1:0)-(held.has('ArrowUp')?1:0),pace=700*seconds/camera.zoom*(state.shift?2.5:1)*sim.settings.panSpeed;camera.x+=px*pace;camera.y+=py*pace;
  }
  let frameDt=0;
  function frame(now){const elapsed=Math.min(50,now-(lastTime||now));lastTime=now;frameDt=elapsed/1000;heldKeys(elapsed/1000);
    if(!state.paused&&!document.hidden){accumulator+=elapsed*state.speed;let steps=0;while(accumulator>=1000/60&&steps<8){sim.step();accumulator-=1000/60;steps++;}}else accumulator=0;
    if(state.down&&!state.pan&&state.tool==='shoot')perform(state.worldPointer,true);
    powerSound(sim.power&&!state.paused?sim.power.kind:null);
    render();frameCount++;if(now-fpsTime>=1000){$('#fps').textContent=Math.min(240,Math.round(frameCount*1000/(now-fpsTime)))+' fps';frameCount=0;fpsTime=now;}
    if(now-uiTime>180){$('#object-count').textContent=sim.entities.length+' objects';$('#joint-count').textContent=sim.joints.length+' joints';updateSelection();updateAnatomyInfo();uiTime=now;}
    requestAnimationFrame(frame);
  }
  new ResizeObserver(()=>{const initial=!width;resize();if(initial)fit();}).observe(stage);
  resize();fit();renderCatalog();sim.loadPreset('empty');setPaused(false);setTool('grab');requestAnimationFrame(frame);
})();
